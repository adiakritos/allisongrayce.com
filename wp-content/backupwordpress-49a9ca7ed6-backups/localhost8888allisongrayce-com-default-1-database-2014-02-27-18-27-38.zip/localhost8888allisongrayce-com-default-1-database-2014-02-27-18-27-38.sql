# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_commentmeta`
#

DROP TABLE IF EXISTS `wpWPP_commentmeta`;


#
# Table structure of table `wpWPP_commentmeta`
#

CREATE TABLE `wpWPP_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_commentmeta (0 records)
#

#
# End of data contents of table wpWPP_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_comments`
#

DROP TABLE IF EXISTS `wpWPP_comments`;


#
# Table structure of table `wpWPP_comments`
#

CREATE TABLE `wpWPP_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_comments (2 records)
#
 
INSERT INTO `wpWPP_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2014-01-14 15:53:51', '2014-01-14 15:53:51', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wpWPP_comments` VALUES (2, 18, 'nick', 'adiakritos@gmail.com', '', '::1', '2014-01-20 16:08:43', '2014-01-20 16:08:43', 'This is badass.', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.77 Safari/537.36', '', 0, 1) ;
#
# End of data contents of table wpWPP_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_links`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_links`
#

DROP TABLE IF EXISTS `wpWPP_links`;


#
# Table structure of table `wpWPP_links`
#

CREATE TABLE `wpWPP_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_links (0 records)
#

#
# End of data contents of table wpWPP_links
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_options`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_options`
#

DROP TABLE IF EXISTS `wpWPP_options`;


#
# Table structure of table `wpWPP_options`
#

CREATE TABLE `wpWPP_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=636 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_options (252 records)
#
 
INSERT INTO `wpWPP_options` VALUES (1, 'siteurl', 'http://localhost:8888/allisongrayce.com', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (2, 'blogname', 'Allison Grayce', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (3, 'blogdescription', 'Web Designer, Teacher, &amp; Writer', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (5, 'admin_email', 'adiakritos@gmail.com', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (20, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (25, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (26, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (27, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (28, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (29, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (30, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (31, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (32, 'hack_file', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (33, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (34, 'moderation_keys', '', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (35, 'active_plugins', 'a:9:{i:0;s:34:"WP-Dribbble-master/wp-dribbble.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:26:"ag-custom-admin/plugin.php";i:3;s:35:"backupwordpress/backupwordpress.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:71:"official-treehouse-badges-widgets-and-shortcodes/wptreehouse-badges.php";i:6;s:55:"super-simple-contact-form/super-simple-contact-form.php";i:7;s:17:"twiget/twiget.php";i:8;s:24:"wordpress-seo/wp-seo.php";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (36, 'home', 'http://localhost:8888/allisongrayce.com', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (37, 'category_base', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (39, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (40, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (41, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (42, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (43, 'recently_edited', 'a:2:{i:0;s:83:"/Applications/MAMP/htdocs/allisongrayce.com/wp-content/themes/wpportfolio/style.css";i:1;s:0:"";}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (44, 'template', 'wpportfolio', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (45, 'stylesheet', 'wpportfolio', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (46, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (47, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (48, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (49, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (50, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (51, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (52, 'db_version', '26691', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (53, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (54, 'upload_path', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (55, 'blog_public', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (56, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (57, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (58, 'tag_base', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (59, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (60, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (61, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (62, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (63, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (64, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (65, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (66, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (67, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (68, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (69, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (70, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (71, 'image_default_size', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (72, 'image_default_align', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (73, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (74, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (75, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (76, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (77, 'page_comments', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (78, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (79, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (80, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (81, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (82, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (83, 'widget_text', 'a:2:{i:2;a:3:{s:5:"title";s:5:"Hello";s:4:"text";s:14:"Test Container";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (84, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (85, 'uninstall_plugins', 'a:1:{s:17:"twiget/twiget.php";s:28:"twiget_delete_plugin_options";}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (86, 'timezone_string', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (87, 'page_for_posts', '8', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (88, 'page_on_front', '4', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (89, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (90, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (91, 'initial_db_version', '26691', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (92, 'wpWPP_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (98, 'sidebars_widgets', 'a:7:{s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:18:"unique_widget_name";a:1:{i:0;s:6:"text-2";}s:19:"wp_inactive_widgets";a:0:{}s:11:"footer_left";a:1:{i:0;s:15:"twiget-widget-2";}s:13:"footer_middle";a:1:{i:0;s:8:"dribbble";}s:12:"footer_right";a:1:{i:0;s:27:"wptreehouse_badges_widget-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (99, 'cron', 'a:8:{i:1390777200;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1390830974;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1390830980;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1390834850;a:1:{s:14:"yoast_tracking";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1393530060;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1393542000;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1393559643;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (106, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1393525656;s:7:"checked";a:4:{s:14:"twentyfourteen";s:3:"1.0";s:14:"twentythirteen";s:3:"1.1";s:12:"twentytwelve";s:3:"1.3";s:11:"wpportfolio";s:3:"1.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (109, '_site_transient_timeout_browser_e5cb6a6276a8822c8b03a27bac3cfc6c', '1390319654', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (110, '_site_transient_browser_e5cb6a6276a8822c8b03a27bac3cfc6c', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.63";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (111, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (158, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (162, '_transient_timeout_feed_c809918297b2c893fd8504c06adcaf00', '1389838000', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (163, '_transient_feed_c809918297b2c893fd8504c06adcaf00', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"WebDevStudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:24:"http://webdevstudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:40:"WordPress Website Development and Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Jan 2014 19:57:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:27:"http://wordpress.org/?v=3.8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"WebDevStudios sponsors WordCamp Phoenix 2014!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://webdevstudios.com/2014/01/14/webdevstudios-sponsors-wordcamp-phoenix-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:90:"http://webdevstudios.com/2014/01/14/webdevstudios-sponsors-wordcamp-phoenix-2014/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Jan 2014 19:57:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:18:"Community Projects";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:16:"WordPress Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=8011";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:408:"WebDevStudios loves getting involved in the WordPress community. One of the ways we like to show support for WordPress and the people who surround it, is to sponsor WordCamps as often as we can. WordCamp Phoenix has always been one &#8230; <a class="more-link" href="http://webdevstudios.com/2014/01/14/webdevstudios-sponsors-wordcamp-phoenix-2014/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:782:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/01/Screenshot_on_1.14.2014_at_10.50.48_AM.png"><img class="aligncenter size-full wp-image-8012" alt="Screenshot_on_1.14.2014_at_10.50.48_AM" src="http://webdevstudios.com/wp-content/uploads/2014/01/Screenshot_on_1.14.2014_at_10.50.48_AM.png" width="946" height="246" /></a>WebDevStudios loves getting involved in the WordPress community. One of the ways we like to show support for WordPress and the people who surround it, is to sponsor WordCamps as often as we can.</p>
<p>WordCamp Phoenix has always been one of our favorite WordCamps to attend and speak at, so we thought it was only right to sponsor the event! We are looking forward to seeing all of you and spending way too much time at SanTan! See you there!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:86:"http://webdevstudios.com/2014/01/14/webdevstudios-sponsors-wordcamp-phoenix-2014/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"50% Off WordPress Ebooks by Brad Williams &amp; Lisa Sabin-Wilson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://webdevstudios.com/2014/01/10/50-off-wordpress-ebooks-by-brad-williams-lisa-sabin-wilson/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:104:"http://webdevstudios.com/2014/01/10/50-off-wordpress-ebooks-by-brad-williams-lisa-sabin-wilson/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Jan 2014 16:47:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"ebooks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"oreilly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7993";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:413:"As many of you know, WDS has a lot of WordPress related books under our belt. Well, for today and tomorrow ONLY, O&#8217;Reilly has a 50% discount offer on Ebooks by Lisa Sabin Wilson and Brad Williams, and other WordPress &#8230; <a class="more-link" href="http://webdevstudios.com/2014/01/10/50-off-wordpress-ebooks-by-brad-williams-lisa-sabin-wilson/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4461:"<p><a href="http://shop.oreilly.com/category/deals/wordpress.do?code=DEAL&amp;imm_mid=0b5cb9&amp;cmp=em-prog-books-videos-lp-dod_wordpress_elist_deal"><img class="alignright size-full wp-image-8005" alt="WordPress Books Lisa Sabin-Wilson Brad Williams" src="http://webdevstudios.com/wp-content/uploads/2014/01/wordpress-fan-308.png" width="308" height="209" /></a>As many of you know, WDS has a lot of <a title="WordPress Books" href="http://webdevstudios.com/wordpress/books/">WordPress related books</a> under our belt. Well, for today and tomorrow ONLY, <a href="http://shop.oreilly.com/home.do">O&#8217;Reilly</a> has a 50% discount offer on Ebooks by <a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin Wilson</a> and <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a>, and other WordPress authors, with their <a title="WordPress Ebook Deal of the Day" href="http://shop.oreilly.com/category/deals/wordpress.do?code=DEAL&amp;imm_mid=0b5cb9&amp;cmp=em-prog-books-videos-lp-dod_wordpress_elist_deal">Ebook Deal of the Day</a>!</p>
<p><strong>Use discount code <span style="color: #993300">DEAL</span> &#8211; Deal expires January 11, 2014 at 5:00am PT, and cannot be combined with other offers. Offer does not apply to Print, or &#8220;Print &amp; Ebook&#8221; bundle pricing.</strong></p>
<blockquote><p>WordPress powers everything from blogs and simple websites, to complex portals, enterprise websites, and even applications. It&#8217;s powerful yet simple features make it a delight to use for content management and audiences love its easy-to-interact with design. Whether you&#8217;re a WordPress expert or just starting out, get everything you need to make your WordPress sites exceptional at <a href="http://shop.oreilly.com/category/deals/wordpress.do?code=DEAL&amp;imm_mid=0b5cb9&amp;cmp=em-prog-books-videos-lp-dod_wordpress_elist_deal">shop.oreilly.com</a>.</p></blockquote>
<p>Here&#8217;s a list of the books from Lisa Sabin-Wilson you can purchase these Ebooks for a 50% discount:</p>
<p><a href="http://shop.oreilly.com/product/9781118383346.do?code=DEAL"><img class="alignleft size-full wp-image-8000" alt="WordPress All In One For Dummies by Lisa Sabin-Wilson" src="http://webdevstudios.com/wp-content/uploads/2014/01/wpaio.gif" width="96" height="120" /></a><a href="http://shop.oreilly.com/product/9781118383186.do?code=DEAL"><img class="alignleft size-full wp-image-8001" alt="WordPress For Dummies by Lisa Sabin-Wilson" src="http://webdevstudios.com/wp-content/uploads/2014/01/wpfd.gif" width="95" height="120" /></a><a href="http://shop.oreilly.com/product/9781118546611.do?code=DEAL"><img class="alignleft size-full wp-image-8002" alt="WordPress Web Design For Dummies by Lisa Sabin-Wilson" src="http://webdevstudios.com/wp-content/uploads/2014/01/wpwdfd.gif" width="97" height="120" /></a><a href="http://shop.oreilly.com/product/9781118379813.do?code=DEAL"><img class="alignleft size-full wp-image-8003" alt="Launch a WordPress.com Blog in A Day by Lisa Sabin-Wilson" src="http://webdevstudios.com/wp-content/uploads/2014/01/wpcom.gif" width="78" height="120" /></a></p>
<div style="clear: both"></div>
<p><strong><a href="http://shop.oreilly.com/product/9781118383346.do?code=DEAL">WordPress All-in-One For Dummies</a></strong><br />
<strong><a href="http://shop.oreilly.com/product/9781118383186.do?code=DEAL">WordPress For Dummies</a></strong><br />
<strong><a href="http://shop.oreilly.com/product/9781118546611.do?code=DEAL">WordPress Web Design For Dummies</a></strong><br />
<strong><a href="http://shop.oreilly.com/product/9781118379813.do?code=DEAL">Launch a WordPress.com Blog In A Day For Dummies</a></strong></p>
<p><a href="http://shop.oreilly.com/product/9781118442272.do?code=DEAL"><img class="alignleft size-full wp-image-8004" alt="Professional WordPress by Brad Williams, et al" src="http://webdevstudios.com/wp-content/uploads/2014/01/prowp.gif" width="96" height="120" /></a>And from Brad Williams, you can purchase the Professional WordPress Ebook for 50% off: <strong><a href="http://shop.oreilly.com/product/9781118442272.do?code=DEAL"> Professional WordPress</a></strong></p>
<div style="clear: both"></div>
<p>This deal is only available until <strong>January 11, 2014 at 5:00am PT</strong>. Remember to use the discount code <span style="color: #993300"><strong>DEAL</strong></span> when you get to the check out!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:100:"http://webdevstudios.com/2014/01/10/50-off-wordpress-ebooks-by-brad-williams-lisa-sabin-wilson/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:63:"
		
		
		
		
		
				
		
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"AppPresser Available for Purchase!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2014/01/08/apppresser-available-for-purchase/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:79:"http://webdevstudios.com/2014/01/08/apppresser-available-for-purchase/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Jan 2014 14:00:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:8:{i:0;a:5:{s:4:"data";s:18:"Community Projects";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:13:"Final Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:16:"Products We Love";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:27:"Social Network Applications";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7967";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:399:"WDS is happy to announce that AppPresser is out of beta and now available for purchase! This mobile application framework will make you see WordPress in a whole new light. AppPresser has been in beta for the past month, but starting &#8230; <a class="more-link" href="http://webdevstudios.com/2014/01/08/apppresser-available-for-purchase/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3967:"<p><a href="http://webdevstudios.com/wp-content/uploads/2014/01/Screenshot_on_1.6.2014_at_2.23.56_PM.png"><img class="alignleft size-full wp-image-7984" alt="Screenshot_on_1.6.2014_at_2.23.56_PM" src="http://webdevstudios.com/wp-content/uploads/2014/01/Screenshot_on_1.6.2014_at_2.23.56_PM.png" width="70" height="74" /></a>WDS is happy to announce that <a href="http://apppresser.com/">AppPresser</a> is out of beta and now available for purchase! This mobile application framework will make you see WordPress in a whole new light. AppPresser has been in beta for the past month, but starting today it is available to the public for purchase!</p>
<p><a href="http://apppresser.com/">AppPresser</a> is the first mobile app framework for WordPress. It allows you to create and customize an app just like you would create a WordPress site with either iOS or Android. You can create your app completely in WordPress, using themes, plugins, and all the stuff you already know. You don&#8217;t need objective C, Java or SDK knowledge to use AppPresser. It&#8217;s as easy as 1, 2, 3!</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/12/UTF-8Screenshot_on_12.30.2013_at_12.54.21_PM.png"><img class="aligncenter size-full wp-image-7972" alt="UTF-8\'\'Screenshot_on_12.30.2013_at_12.54.21_PM" src="http://webdevstudios.com/wp-content/uploads/2013/12/UTF-8Screenshot_on_12.30.2013_at_12.54.21_PM.png" width="1181" height="323" /></a><a href="http://webdevstudios.com/wp-content/uploads/2014/01/Screenshot_on_1.6.2014_at_1.36.28_PM.png"><img class="aligncenter size-full wp-image-7980" alt="Screenshot_on_1.6.2014_at_1.36.28_PM" src="http://webdevstudios.com/wp-content/uploads/2014/01/Screenshot_on_1.6.2014_at_1.36.28_PM.png" width="1198" height="335" /></a><a href="http://apppresser.com/">AppPresser</a> also allows you to integrate native device features such as your camera, geolocation, contacts, notifications and more. You have the tools to build any app you want! When you are done creating your awesome app completely in WordPress, you have the option to release it onto the iOS app store, Google Play, and more. The app will be packaged up for you to make it available for sale and available to people all over the globe. Selling your app is just an option, you can also just use it for your own site on the web.</p>
<p>You can also create a <a href="http://www.woothemes.com/woocommerce/">WooCommerce</a> powered e-commerce app. With the <a href="http://apppresser.com/extensions/ecommerce-bundle">AppPresser E-Commerce bundle</a>, you will have all the tools you need. The bundle includes <a title="AppPresser Theme" href="http://apppresser.com/extensions/apppresser-theme/">AppPresser Theme</a>, <a title="AppWoo" href="http://apppresser.com/extensions/appwoo/">AppWoo</a>, <a title="AppSwiper" href="http://apppresser.com/extensions/appswiper/">AppSwiper</a> and the <a title="AppCamera" href="http://apppresser.com/extensions/appcamera/">AppCamera</a> extensions.</p>
<blockquote><p>Add the AppPresser plugin + our E-Commerce bundle to your WordPress + WooCommerce store to create a native application that you can distribute in the Apple Store (iOS) and/or Google Play (Android).</p></blockquote>
<p><a href="http://webdevstudios.com/wp-content/uploads/2014/01/Screenshot_on_1.6.2014_at_2.21.37_PM.png"><img class="aligncenter size-large wp-image-7983" alt="Screenshot_on_1.6.2014_at_2.21.37_PM" src="http://webdevstudios.com/wp-content/uploads/2014/01/Screenshot_on_1.6.2014_at_2.21.37_PM-1024x504.png" width="640" height="315" /></a></p>
<p>We are extremely proud to be a part of the team that has developed <a href="http://apppresser.com/">AppPresser</a> along with <a href="https://twitter.com/scottbolinger">Scott Bolinger</a>. Scott&#8217;s vision for AppPresser and awesome design skills have helped create this new product for WordPress. We are excited to see where AppPresser will go in the future!</p>
<p style="text-align: left">
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:75:"http://webdevstudios.com/2014/01/08/apppresser-available-for-purchase/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Sharing Sidebars Across a Multisite Network";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://webdevstudios.com/2013/12/17/sharing-sidebars-across-a-multisite-network/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:89:"http://webdevstudios.com/2013/12/17/sharing-sidebars-across-a-multisite-network/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Dec 2013 16:28:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"How To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"Snippets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"Tutorial";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:19:"WordPress Multisite";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7940";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:405:"Sidebars are great.  Multisite is great.  Doing something once so that it can be shared across an entire network is great, too. So, it should stand to reason that sharing a specific sidebar, or set of sidebars, across an entire &#8230; <a class="more-link" href="http://webdevstudios.com/2013/12/17/sharing-sidebars-across-a-multisite-network/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Corey Collins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:7492:"<p>Sidebars are great.  Multisite is great.  Doing something once so that it can be shared across an entire network is great, too.</p>
<p>So, it should stand to reason that sharing a specific sidebar, or set of sidebars, across an entire multisite network should be just as great (and easy), right?</p>
<p>Well, if it were, we wouldn’t be here right now.</p>
<p>I know what you may be thinking&#8230;</p>
<blockquote><p>Just use switch_to_blog(), ya dingus!</p></blockquote>
<p>Oh, how I wish it were that easy!  That was our first guess as well, but it unfortunately didn&#8217;t do the trick.  Apparently, switch_to_blog() is a trick that does not work when attempting to share a sidebar across a network.  Total bummer.</p>
<p>In our situation, though, we had a set of sidebars in our footer that we wanted the client to be able to manage but also share across every site within their network.  So, hardcoding the widgets in place wouldn&#8217;t have been a proper solution; neither would have been telling the client that they would need to manage three sidebars on 300+ sites.  Ouch.</p>
<p>We had our task: allow a set of sidebars to be displayed across the sites in a multisite network.</p>
<p>We had our problem: switch_to_blog() doesn&#8217;t work for this, so we needed to figure out another way to accomplish our goal.</p>
<p>Now we have our solution.</p>
<p>The first thing we want to do is build the output of our sidebars. That seems kind of important, right? Can&#8217;t see some sidebars if we&#8217;re not telling the sidebars to display. We don&#8217;t want to just display the sidebars and be done with it, though. What we want to do is store our sidebars in a transient. This transient will be deleted whenever a widget is updated in one of our three sidebars (you&#8217;ll see this later, be patient!). In order to store our set of sidebars as a variable, we need to wrap everything in an output buffer.</p>
<pre class="prettyprint linenums">/**
 * Generate sidebar for footer across all sites
 */
add_action( \'init\', \'wds_footer_widgets_all_sites\' );
function wds_footer_widgets_all_sites() {

    if ( ! is_main_site() )
        return;

    if ( ! ( $wds_footer_widgets = get_site_transient( \'wds_footer_widgets\' ) ) ) {
        // start output buffer
        ob_start();

        // Display our footer sidebars
        if ( ! dynamic_sidebar( \'sidebar-footer-1\' ) ) :
                endif; // end sidebar widget area

        if ( ! dynamic_sidebar( \'sidebar-footer-2\' ) ) :
        endif; // end sidebar widget area

        if ( ! dynamic_sidebar( \'sidebar-footer-3\' ) ) :
        endif; // end sidebar widget area

        // grab the data from the output buffer and put it in our variable
        $wds_footer_widgets = ob_get_contents();
        ob_end_clean();

        // Put sidebar into a transient for 4 hours
        set_site_transient( \'wds_footer_widgets\', $wds_footer_widgets, 4*60*60 );
    }
}</pre>
<p>Next comes our theme&#8217;s footer. This is a bit more straight forward &#8211; we want to get the site transient that we established in our functions file above, then display its contents.</p>
<pre class="prettyprint linenums">// Display our stored footer widgets
$show_footer_sidebar = get_site_transient( \'wds_footer_widgets\' );
echo $show_footer_sidebar;</pre>
<p>Now we should have our sidebars displaying, but we also want some additional magic to happen. We need to clear our transient when a widget is updated or saved in one of our three footer sidebars.  The first step of this process is to enqueue some scripts that we&#8217;re going to be using. I&#8217;m doing this in a separate file housing all of our AJAX-related commands, ajax-functions.php in our theme&#8217;s /inc/ directory.</p>
<pre class="prettyprint linenums">/**
 * Enqueue and localize our scripts
 */
add_action( \'admin_enqueue_scripts\', \'wds_enqueue_ajax_scripts\' );
function wds_enqueue_ajax_scripts() {
    global $current_screen;

    // Only register these scripts if we\'re on the widgets page
    if ( $current_screen-&gt;id == \'widgets\' ) {
        wp_enqueue_script( \'wds_ajax_scripts\', get_stylesheet_directory_uri() . \'/js/admin-widgets.js\', array( \'jquery\' ), 1, true );
        wp_localize_script( \'wds_ajax_scripts\', \'wds_AJAX\', array( \'wds_widget_nonce\' =&gt; wp_create_nonce( \'widget-update-nonce\' ) ) );
    }
}</pre>
<p>In the same file, we want to create the AJAX function that runs when updating our sidebars. This function checks to make sure our nonce is present; if it is, it deletes the site transient.</p>
<pre class="prettyprint linenums">/**
 * Register our AJAX call
 */
add_action( \'wp_ajax_wds-reset-transient\', \'wds_ajax_wds_reset_transient\', 1 );

/**
 * AJAX Helper to delete our transient when a widget is saved
 */
function wds_ajax_wds_reset_transient() {

    // Delete our footer transient.  This runs when a widget is saved or updated.  Only do this if our nonce is passed.
    if ( ! empty( $_REQUEST[\'wds-widget-nonce\'] ) )
        delete_site_transient( \'wds_footer_widgets\' );
}</pre>
<p>We&#8217;ll need a JavaScript file to handle some back-end functionality, and we&#8217;ll need to localize the script so we can interact with that file.  We&#8217;re passing a nonce in our script as well; this will ensure that our widget form is being updated properly.</p>
<p>Finally, we want to create the AJAX that is going to listen for an updated widget. With jQuery first, we&#8217;re listening for a click on the remove, close, or save links on individual widgets within one of our three specific sidebars. If one of those links is clicked and we&#8217;re in one of our specified sidebars, we want to run our AJAX function.</p>
<pre class="prettyprint linenums">jQuery(document).ready(function($){

    function wds_reset_footer_transient() {

        // Run our AJAX call to delete our site transient
        $.ajax({
            type : \'post\',
            dataType : \'json\',
            url : ajaxurl,
            data : {
                \'action\' : \'wds-reset-transient\',
                \'wds-widget-nonce\' : wds_AJAX.wds_widget_nonce
            },
            error: function ( xhr, ajaxOptions, thrownError ) {
                console.log( thrownError );
                console.log( ajaxOptions );
            }
        });
    }

    // If one of our update buttons is clicked on a single widget
    $( \'.widgets-holder-wrap\' ).on( \'click\', \'.widget-control-remove, .widget-control-close, .widget-control-save\', function() {

        // Get our parent, or sidebar, ID
        var widget_parent_div = $(this).parents().eq(5).attr( \'id\' );

        // And if our parent div ID, or our sidebar ID, is one of the following
        if ( widget_parent_div == \'sidebar-footer-1\' || widget_parent_div == \'sidebar-footer-2\' || widget_parent_div == \'sidebar-footer-3\' ) {

            // Run our function
            wds_reset_footer_transient();
        }
    });
});
</pre>
<p>And that&#8217;s about it! Now you can manage a set of sidebars on the main site within your network and pass those sidebars to every site within your network. One set of widgets to manage for an entire network of sites. It wasn&#8217;t the solution that jumped out at us at first, but it&#8217;s the one we found and it&#8217;s the one that works for us. We&#8217;re pretty happy with the way it turned out, and we think the client is going to be happy only having to edit their widgets once and have those changes visible on 300+ sites.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:85:"http://webdevstudios.com/2013/12/17/sharing-sidebars-across-a-multisite-network/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"WordSesh 2 Video Presentations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://webdevstudios.com/2013/12/11/wordsesh-2-video-presentations/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"http://webdevstudios.com/2013/12/11/wordsesh-2-video-presentations/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Dec 2013 16:59:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7948";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:380:"WordSesh 2 was a complete success and WebDevStudios was happy to take part in such an awesome event! Below, you are going to find all the videos of the WDS presentations. First up is the DradCast that was presented by &#8230; <a class="more-link" href="http://webdevstudios.com/2013/12/11/wordsesh-2-video-presentations/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3024:"<p>WordSesh 2 was a complete success and WebDevStudios was happy to take part in such an awesome event! Below, you are going to find all the videos of the WDS presentations.</p>
<p>First up is the <a href="http://dradcast.com/">DradCast</a> that was presented by <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams,</a> <a href="https://twitter.com/dremeda">Dre Armeda</a>, and co-host <a href="https://twitter.com/scottbasgaard">Scott Basgaard</a> &#8211;</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/D-I90URtxLE?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
<p>Next for WDS was <a title="Scott Kingsley Clark" href="http://webdevstudios.com/team/scott-kingsley-clark/">Scott Kingsley Clark</a> with Not just a plugin: Pods &#8212; A comprehensive development framework &#8211;</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/SyaFTuHjGyg?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
<p><a title="Brad Parbs" href="http://webdevstudios.com/team/brad-parbs/">Brad Parbs</a> told us all about Building WordPress Themes Quickly with Reusable SASS &#8211;</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/UV3r4lGKmEA?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
<p><a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a> and an array of other WordPress experts presented us with WordPress Podcasting Roundtable &#8211;</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/ipkjTCJ1EFw?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
<p>And last, but not least, <a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a> shared her knowledge with i18n: Preparing Your WordPress Theme for the World &#8211;</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/fJfqgrzjEis?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"http://webdevstudios.com/2013/12/11/wordsesh-2-video-presentations/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:60:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WordSesh 2 — When And Where Can You Find WDS";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://webdevstudios.com/2013/12/03/wordsesh-2-and-wds/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://webdevstudios.com/2013/12/03/wordsesh-2-and-wds/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Dec 2013 17:11:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:18:"Community Projects";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:6:"How To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:16:"WordPress Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7936";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:389:"WordSesh 2 is coming up this weekend! This 24 hour event is being held on Saturday, December 7th from 00:00 &#8211; 24:00 UTC. If, during the event you need help keeping track of time, you can visit Worldtimeserver.com so you don&#8217;t &#8230; <a class="more-link" href="http://webdevstudios.com/2013/12/03/wordsesh-2-and-wds/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:5975:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/11/UTF-8Screenshot_on_11.22.2013_at_9.50.26_AM.png"><img class="alignleft size-medium wp-image-7922" alt="UTF-8\'\'Screenshot_on_11.22.2013_at_9.50.26_AM" src="http://webdevstudios.com/wp-content/uploads/2013/11/UTF-8Screenshot_on_11.22.2013_at_9.50.26_AM-300x300.png" width="300" height="300" /></a><a href="http://wordsesh.org/">WordSesh 2</a> is coming up this weekend! This 24 hour event is being held on Saturday, December 7th from 00:00 &#8211; 24:00 <strong>UTC</strong>. If, during the event you need help keeping track of time, you can visit <a href="http://www.worldtimeserver.com/current_time_in_UTC.aspx">Worldtimeserver.com</a> so you don&#8217;t miss any of the important presentations! If you are not familiar with <a href="http://wordsesh.org/">WordSesh</a>, it is a 24 hour event. 1 presentation, every hour, on the hour. The list of speakers for this event is outstanding and WDS is proud to be a part of WordSesh again this year! We have 4 team members of WDS speaking for WordSesh this year, and that includes &#8212; <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a>, <a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a>, <a title="Scott Kingsley Clark" href="http://webdevstudios.com/team/scott-kingsley-clark/">Scott Kingsley Clark</a>, and <a title="Brad Parbs" href="http://webdevstudios.com/team/brad-parbs/">Brad Parbs</a>.</p>
<p>Just like last year, kicking off WordSesh 2 will be <a href="https://twitter.com/williamsba">Brad Williams</a>, <a href="https://twitter.com/dremeda">Dre Aremeda</a>, and <a href="https://twitter.com/scottbasgaard">Scott Basgaard</a> with <a href="http://dradcast.com/">The DradCast</a>. The DradCast is a live podcast of all things WordPress, and it&#8217;s only appropriate to have guest host, Scott, who is the main organizer of this event to help kick it off. You can catch Brad, Dre, and Scott at <strong>0:00 UTC in Room A</strong>.</p>
<p>Next on the list of WDS speakers is <a title="Scott Kingsley Clark" href="http://webdevstudios.com/team/scott-kingsley-clark/">Scott Kingsley Clark</a>, who will be speaking with <a href="https://twitter.com/dcramer">David Cramer</a>, <a href="https://twitter.com/Josh412">Josh Pollock</a>, and <a href="https://twitter.com/pglewis13">Phil Lewis</a>. The topic of their discussion is &#8212; <span style="text-decoration: underline">Not Just A Plugin: Pods &#8211; A Comprehensive Development Framework</span>.</p>
<p>Details on their discussion:</p>
<p>You can find them in <strong>Room A at 1:00 UTC.</strong></p>
<blockquote><p>Scott will be leading a deep look into what Pods can do at a code-level. Covered areas will include building custom management areas in the Dashboard or Theme, the upcoming Gravity Forms Add-on capabilities, and a preview of Pods 3.0. Scott will be joined by Phil Lewis, David Cramer, and Josh Pollock. Phil will show off some of the classes included in Pods and their usefulness, especially for theming and frontend development. David will unveil the brand new Pods Frontier plugin &#8212; the first feature plugin for Pods that brings Twig support, Form building, Advanced Templating with a new looping syntax similar to magic tags, and a great code editor with magic tag autocompletion including traversal support across as many relationships and levels as you can dream up! Josh, Community Manager for the Pods project, will also be following Twitter and our IRC chat to catch questions and help get clarification on topics covered for those watching the live stream.</p></blockquote>
<p><a href="https://twitter.com/bradparbs">Brad Parbs</a> is next on the roster. He will be speaking at <strong>9:00 UTC in Room B</strong>. The topic for his discussion is &#8212; <span style="text-decoration: underline">Building WordPress Themes Quickly With Reusable SASS</span>.</p>
<p>A description of his presentation:</p>
<blockquote><p>Brad will share tips, techniques, best practices, and more relating to SASS and how it can be a great help in your theme toolkit. Brad will share the things he&#8217;s learned over the past few years building WordPress themes, and how SASS can help you do everything a lot faster.</p></blockquote>
<p><a href="https://twitter.com/williamsba">Brad Williams</a> appears again on the WordSesh speakers list at <strong>18:00 UTC in Room A</strong>. For this session, he will be joined by <a href="https://twitter.com/bradt">Brad Touesnard</a>, <a href="https://twitter.com/dremeda">Dre Armeda</a>, <a href="https://twitter.com/jasontucker">Jason Tucker</a>, <a href="https://twitter.com/jeffr0">Jeff Chandler</a>, <a href="https://twitter.com/mattmedeiros">Matt Medeiros</a>, and <a href="https://twitter.com/pippinsplugins">Pippin Williamson</a>. These gentlemen will be participating in the <span style="text-decoration: underline">WordPress Podcasting Roundtable.</span> This is where they will put their brains out on the table for all of you and discuss the latest topics and news in WordPress, and of course, about podcasting!</p>
<p><a href="https://twitter.com/LisaSabinWilson">Lisa Sabin-Wilson</a> is the last member of WDS to speak at WordSesh and she can be found in <strong>Room A at 21:00 UTC</strong>. Her discussion is &#8212; <span style="text-decoration: underline">i18n: Preparing Your WordPress Theme For The World</span>. This session covers the internationalization of WordPress Themes and making sure you do what is necessary to prepare themes for localization and translation.</p>
<p>Needless to say, we are enthusiastic about WordPress and spreading the knowledge that we have. We are grateful to be sharing a place in this event with the other great speakers that are also a part of WordSesh 2. So load up on your coffee, grab your cool note taking app, and absorb the awesomeness that is going to be entering your brain!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://webdevstudios.com/2013/12/03/wordsesh-2-and-wds/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Custom Metaboxes and Fields 1.0.0 Released!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://webdevstudios.com/2013/12/03/custom-metaboxes-and-fields-1-0-0-released/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:88:"http://webdevstudios.com/2013/12/03/custom-metaboxes-and-fields-1-0-0-released/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Dec 2013 14:19:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:18:"Community Projects";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"github";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"New Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:11:"Open Source";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7929";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:457:"If you&#8217;re not already familiar, Custom Metaboxes and Fields for WordPress is a WordPress drop-in plugin that will &#8220;create metaboxes with custom fields that will blow your mind.&#8221;  The Custom Metaboxes and Fields (CMB) library is a frequently used tool at WebDev, &#8230; <a class="more-link" href="http://webdevstudios.com/2013/12/03/custom-metaboxes-and-fields-1-0-0-released/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Jtsternberg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4179:"<p>If you&#8217;re not already familiar, <a href="https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress" target="_blank">Custom Metaboxes and Fields for WordPress</a> is a WordPress drop-in plugin that will &#8220;create metaboxes with custom fields that will blow your mind.&#8221;  The Custom Metaboxes and Fields (CMB) library is a frequently used tool at WebDev, so I approached Jared Atchison about some possible improvements. Jared gave me commit access and I began maintaining the project, introducing new features and merging changes from the community.</p>
<p>On Wednesday, November 27th, we rolled out version 1.0.0 which contains several big-bang features that are sure to make your WordPress development experience that much easier. Several WordPress community members, and a few WDS members (<a href="http://webdevstudios.com/team/brian-messenlehner/" rel="bookmark">Brian Messenlehner</a>, <a href="http://webdevstudios.com/team/michael-beckwith/" rel="bookmark">Michael Beckwith</a>, <a href="http://webdevstudios.com/team/corey-collins/" rel="bookmark">Corey Collins</a>, and <a title="Justin Sternberg" href="http://webdevstudios.com/team/justin-sternberg/">myself</a>) had a hand in this release.</p>
<p>Here is a list from the 1.0.0 changelog:</p>
<ul>
<li>Added <code>select_timezone</code> type, a standalone time zone select dropdown. The time zone select can be used with standalone <code>text_datetime_timestamp</code> if desired. Props <a title="@dessibelle" href="https://github.com/dessibelle" target="_blank">@dessibelle</a></li>
<li>Added <code>text_url</code> type, a basic url field. Props <a title="@dessibelle" href="https://github.com/dessibelle" target="_blank">@dessibelle</a></li>
<li>Added <code>text_email</code> type, a basic email field. Props <a title="@dessibelle" href="https://github.com/dessibelle" target="_blank">@dessibelle</a></li>
<li>Added ability to display metabox fields in frontend. Default is true, but can be overriden using the <code>cmb_allow_frontend</code> filter. If set to true, an entire metabox form can be output with a new function:
<pre><code>cmb_metabox_form( $meta_box, $object_id, $echo );</code></pre>
<p>Props <a title="@dessibelle" href="https://github.com/dessibelle" target="_blank">@dessibelle</a>, <a title="@messenlehner" href="https://github.com/messenlehner" target="_blank">@messenlehner</a> &amp; <a title="@jtsternberg" href="https://github.com/jtsternberg" target="_blank">@jtsternberg</a></li>
<li>Added hook <code>cmb_after_table</code> after all metabox output. Props <a title="@wpsmith" href="https://github.com/wpsmith" target="_blank">@wpsmith</a></li>
<li><code>file_list</code> now works like a repeatable field. Add as many files as you want. Props <a title="@coreymcollins" href="https://github.com/coreymcollins" target="_blank">@coreymcollins</a></li>
<li><code>text</code>, <code>text_small</code>, <code>text_medium</code>, <code>text_url</code>, <code>text_email</code>, &amp; <code>text_money</code> fields now all have the option to be repeatable. Props <a title="@jtsternberg" href="https://github.com/jtsternberg" target="_blank">@jtsternberg</a></li>
<li>Custom metaboxes can now be added for user meta. Add them on the user add/edit screen, or in a custom user profile edit page on the front-end. Props <a title="@tw2113" href="https://github.com/tw2113" target="_blank">@tw2113</a>, <a title="@jtsternberg" href="https://github.com/jtsternberg" target="_blank">@jtsternberg</a></li>
</ul>
<p>We hope you&#8217;re as excited for the possibilities with 1.0.0 as we are and we are already working on updates for version 1.0.1! If you would like to see a new feature or improvement feel free to contribute and submit patches on github. Also, the wiki page needs to be updated so if documentation is your thing, please feel free to jump in and <a href="https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress/wiki" target="_blank">update some docs</a>!</p>
<p>Get <a href="https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress" target="_blank">Custom Metaboxes and Fields for WordPress is a WordPress on Github</a>!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:84:"http://webdevstudios.com/2013/12/03/custom-metaboxes-and-fields-1-0-0-released/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WDS Giveaway – BuddyPress Theme Development by Tammie Lister";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://webdevstudios.com/2013/11/27/wds-giveaway-buddypress-theme-development-by-tammie-lister/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:104:"http://webdevstudios.com/2013/11/27/wds-giveaway-buddypress-theme-development-by-tammie-lister/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Nov 2013 14:51:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:10:"BuddyPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"Giveaway";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7924";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:454:"BuddyPress Theme Development is a book written by Tammie Lister. This book illustrates that you shouldn&#8217;t be afraid to jump into creating BuddyPress themes, because it&#8217;s not as scary as some might think! You will learn everything from BuddPress basics &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/27/wds-giveaway-buddypress-theme-development-by-tammie-lister/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3170:"<p><a href="http://t.co/6rdksFvED6"><img class="size-medium wp-image-7925 alignright" alt="51nzKO7hJZL._SX258_PJlook-inside-v2,TopRight,1,0_SH20_BO1,204,203,200_" src="http://webdevstudios.com/wp-content/uploads/2013/11/51nzKO7hJZL._SX258_PJlook-inside-v2TopRight10_SH20_BO1204203200_-242x300.jpg" width="242" height="300" /></a><a title="Buy BuddyPress Theme Development Book" href="http://t.co/6rdksFvED6" target="_blank">BuddyPress Theme Development</a> is a book written by <a title="Author of BuddyPress Theme Development" href="https://twitter.com/karmatosed" target="_blank">Tammie Lister</a>. This book illustrates that you shouldn&#8217;t be afraid to jump into creating BuddyPress themes, because it&#8217;s not as scary as some might think! You will learn everything from BuddPress basics to some advanced BuddyPress functionality and of course you will will learn how to create your own BuddyPress theme from scratch.</p>
<p>WebDevStudios co-founder <a title="Technical Reviewer of BuddyPress Theme Development" href="http://webdevstudios.com/team/brian-messenlehner/">Brian Messenlehner</a>, was a technical reviewer for <em>BuddyPress Theme Development</em>  published by Packt Publishing.</p>
<p>Here is what Tammie said about her book:</p>
<blockquote><p>When I started writing BuddyPress Theme Development, I had 4 goals (along with providing a good resource for creating themes):</p></blockquote>
<ol>
<li>
<blockquote><p>Blow away the myth that creating BuddyPress themes is hard.</p></blockquote>
</li>
<li>
<blockquote><p>Encourage readers to tailor their experience, choosing which components are critical to their success.</p></blockquote>
</li>
<li>
<blockquote><p>Raise the quality of BuddyPress themes and highlight good theme practices.</p></blockquote>
</li>
<li>
<blockquote><p>Encourage people to get involved with the BuddyPress project.</p></blockquote>
</li>
</ol>
<p>In true WDS fashion, we are going to be doing a giveaway for this book! We will be giving away 3 copies of <em>BuddyPress Theme Development</em>.</p>
<h1>Rules For Entry:</h1>
<ul>
<li>Comment on <strong>this post</strong> about why you&#8217;re interested in the BuddyPress Theme Development book. Make it interesting and give us a little back story on your involvement (or hopeful involvement) with BuddyPress.</li>
<li>The giveaway will run from Wednesday, 11/27/3013 until Monday, 12/16/2013.</li>
<li>The contest will begin on Wednesday the 7th, at 10am and end on Monday the 16th at 1pm EST.</li>
<li>At 2pm EST on Monday the 16th, we will pick who we think is the well deserving winner of the book! (Make sure your email is attached to your comment in some way so we can contact you if you&#8217;ve won.)</li>
</ul>
<p>We love doing giveaways because it&#8217;s an opportunity to give back to the WordPress community! We look forward to reading all about your BuddyPress experiences and what you&#8217;re hoping to accomplish with it. If after the contest, you do not win a copy of the book, you are always welcome to purchase it from  <a title="BuddyPress Theme Development" href="http://t.co/6rdksFvED6" target="_blank">Packt Publishing</a>. Good luck!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:100:"http://webdevstudios.com/2013/11/27/wds-giveaway-buddypress-theme-development-by-tammie-lister/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"WordSesh 2 Speakers Announced!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://webdevstudios.com/2013/11/22/wordsesh-2-speakers-announced/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://webdevstudios.com/2013/11/22/wordsesh-2-speakers-announced/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Nov 2013 16:59:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:16:"WordPress Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7919";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:361:"WDS is excited to be a part of WordSesh again this year. Our own Brad Williams helped organize the event in 2012 and is helping organize it this year as well! If you were around for it last year, you &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/22/wordsesh-2-speakers-announced/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3005:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/11/UTF-8Screenshot_on_11.22.2013_at_9.50.26_AM.png"><img class="alignleft size-medium wp-image-7922" alt="UTF-8\'\'Screenshot_on_11.22.2013_at_9.50.26_AM" src="http://webdevstudios.com/wp-content/uploads/2013/11/UTF-8Screenshot_on_11.22.2013_at_9.50.26_AM-300x300.png" width="300" height="300" /></a>WDS is excited to be a part of <a href="http://wordsesh.org/">WordSesh</a> again this year. Our own Brad Williams helped organize the event in 2012 and is helping organize it this year as well! If you were around for it last year, you know that <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a> did a live broadcast of the <a href="http://dradcast.com/">DradCast</a>, <a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a> spoke about how scoping projects don&#8217;t have to be stressful, and <a title="Scott Kingsley Clark" href="http://webdevstudios.com/team/scott-kingsley-clark/">Scott Kingsley Clark</a> told us all about content types.</p>
<p>You can find all of the <a href="http://wordsesh.org/">WordSesh</a> presentations from last year on their <a href="http://www.youtube.com/playlist?list=PL9bmvLB3RpG7zGrbwbd2R9a2tqT-FiYiGhttp://www.youtube.com/playlist?list=PL9bmvLB3RpG7zGrbwbd2R9a2tqT-FiYiG">YouTube page</a>, including <a href="http://www.youtube.com/watch?v=_WQ5bjvwzoY&amp;list=PL9bmvLB3RpG7zGrbwbd2R9a2tqT-FiYiG&amp;index=1">The DradCast</a>, <a href="http://www.youtube.com/watch?v=RTVDXavDvLw&amp;list=PL9bmvLB3RpG7zGrbwbd2R9a2tqT-FiYiG">Scoping Projects to Avoid Stress, Headaches &amp; Angry Mobs</a>, and <a href="http://www.youtube.com/watch?v=RjyDyEJygxU&amp;list=PL9bmvLB3RpG7zGrbwbd2R9a2tqT-FiYiG">Ermahgerd! Content Types</a>!</p>
<p>If you aren&#8217;t familiar with what <a href="http://wordsesh.org/">WordSesh</a> is; it is 24 straight hours of all things WordPress. 1 presentation, every hour, on the hour. Best thing about it? It&#8217;s 100% FREE, which means you get to stuff your brain full of WordPress knowledge at no cost, how cool is that? This year, WordSesh will take place on <em>Saturday, December 7, 2013, 00:00 &#8211; 24:00 <strong>UTC</strong>.</em> When watching WordSesh, if you need help keeping track of the UTC time, you can track it with the <a href="http://www.worldtimeserver.com/current_time_in_UTC.aspx">World Time Server</a>.</p>
<p>Brad, Lisa, and Scott will be speaking again for <a href="http://wordsesh.org/">WordSesh 2</a>! The details on their presentations will come when we are closer to the date. WebDevStudios is always excited to be involved in the WordPress community, and WordSesh is an awesome way of spreading the knowledge. We are happy to be involved and to be working with the other amazing speakers to make this WordSesh even better than last year!</p>
<p>To keep updated on all things WordSesh, <a href="https://twitter.com/wordsesh">follow their twitter</a>!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://webdevstudios.com/2013/11/22/wordsesh-2-speakers-announced/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"CyberSource and 2Checkout Add-Ons for iThemes Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://webdevstudios.com/2013/11/18/cybersource-and-2checkout-add-ons-for-ithemes-exchange/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:100:"http://webdevstudios.com/2013/11/18/cybersource-and-2checkout-add-ons-for-ithemes-exchange/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 18 Nov 2013 18:56:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:3:"API";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7913";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:420:"WebDevStudios is proud to announce two more add-ons for the iThemes Exchange plugin! We now have three total add-ons for this easy to use Ecommerce option; the first being the PayPal Pro Add-On. All three of these add-ons are payment &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/18/cybersource-and-2checkout-add-ons-for-ithemes-exchange/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3387:"<p>WebDevStudios is proud to announce two more add-ons for the <a href="http://ithemes.com/exchange/">iThemes Exchange plugin</a>! We now have three total add-ons for this easy to use Ecommerce option; the first being the <a href="http://ithemes.com/purchase/paypal-pro/">PayPal Pro Add-On</a>. All three of these add-ons are payment gateway options for the iThemes Exchange Plugin so customers can use their existing payment gateway with the Exchange store. The goal is make it feel seamless when going through the checkout process.</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/11/2co-cybersource.png"><img class="aligncenter size-medium wp-image-7915" alt="2co-cybersource" src="http://webdevstudios.com/wp-content/uploads/2013/11/2co-cybersource-300x139.png" width="300" height="139" /></a></p>
<p>Now, to introduce our two new add-ons, <a href="http://ithemes.com/purchase/cybersource/">CyberSource</a> and <a href="http://ithemes.com/purchase/2checkout/">2Checkout</a>. <a href="http://webdevstudios.com/wp-content/uploads/2013/11/Screen-Shot-2013-11-13-at-4.42.36-PM.png"><img class="size-medium wp-image-7914 alignright" alt="Screen-Shot-2013-11-13-at-4.42.36-PM" src="http://webdevstudios.com/wp-content/uploads/2013/11/Screen-Shot-2013-11-13-at-4.42.36-PM-186x300.png" width="186" height="300" /></a></p>
<p>With the CyberSource Add-On, you have the ability to accept credit cards on your site, via the <a href="http://www.cybersource.com/">CyberSource</a> payment gateway.</p>
<p><strong>How To Use The CyberSource Add-On:</strong></p>
<blockquote><p>To get started, enter your <strong>Merchant ID</strong>, <strong>Live Transaction Security Key</strong> and <strong>Test Transaction Security Key</strong> on the CyberSource Add-on settings page.</p>
<p>Select your transaction sale method: <strong>Authorize and Capture</strong> or <strong>Authorize</strong>.</p>
<p>You can also enable and disable <strong>CyberSource Sandbox Mode</strong> and change the <strong>purchase button label.</strong></p></blockquote>
<p>The 2Checkout Add-On allows 2Checkout members to use their account to purchase items off of your site. This option is for members only. After clicking on the purchase button, the customer will be redirected to the 2Checkout payment process.</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/11/2checkout-screenshot.png"><img class="alignleft size-medium wp-image-7916" alt="2checkout-screenshot" src="http://webdevstudios.com/wp-content/uploads/2013/11/2checkout-screenshot-300x291.png" width="300" height="291" /></a><strong>How To Use The 2Checkout Add-On:</strong></p>
<blockquote><p>To get started taking payments through 2Checkout, enter your 2Checkout SID and Secret Word on the 2Checkout Add-on settings page.</p>
<p>In the add-on settings you can choose Credit Card or PayPal as the default payment method.</p>
<p>You can also enable and disable test 2Checkout Demo mode and change the Purchase button text to whatever you prefer.</p></blockquote>
<p>WDS is very excited about this on-going relationship with <a href="http://ithemes.com/">iThemes</a> and we can&#8217;t wait to continue making Exchange awesome for users. If you want to learn more about the <a href="http://ithemes.com/exchange/">iThemes Exchange</a> plugin and these add-ons, you can <a href="http://ithemes.com/exchange/">visit their site</a>!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:96:"http://webdevstudios.com/2013/11/18/cybersource-and-2checkout-add-ons-for-ithemes-exchange/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:41:"http://feeds.feedburner.com/webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:13:"webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:13:"webdevstudios";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:28:"http://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"QGFnWOFuc0R5pWt0SkrbtPm/pIo";s:13:"last-modified";s:29:"Wed, 15 Jan 2014 13:27:35 GMT";s:4:"date";s:29:"Wed, 15 Jan 2014 14:06:39 GMT";s:7:"expires";s:29:"Wed, 15 Jan 2014 14:06:39 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (164, '_transient_timeout_feed_mod_c809918297b2c893fd8504c06adcaf00', '1389838000', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (165, '_transient_feed_mod_c809918297b2c893fd8504c06adcaf00', '1389794800', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (166, 'cpt_custom_post_types', 'a:2:{i:0;a:21:{s:4:"name";s:4:"work";s:5:"label";s:4:"Work";s:14:"singular_label";s:7:"Project";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"0";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"0";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:11:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:7:"excerpt";i:3;s:10:"trackbacks";i:4;s:13:"custom-fields";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:9:"thumbnail";i:8;s:6:"author";i:9;s:15:"page-attributes";i:10;s:12:"post-formats";}i:1;N;i:2;a:12:{s:9:"menu_name";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}i:1;a:21:{s:4:"name";s:12:"testimonials";s:5:"label";s:12:"Testimonials";s:14:"singular_label";s:11:"Testimonial";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"0";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"0";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:11:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:7:"excerpt";i:3;s:10:"trackbacks";i:4;s:13:"custom-fields";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:9:"thumbnail";i:8;s:6:"author";i:9;s:15:"page-attributes";i:10;s:12:"post-formats";}i:1;N;i:2;a:12:{s:9:"menu_name";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (171, 'acf_version', '4.3.4', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (179, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1389973685;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (180, 'current_theme', 'Portfolio for Allison Grayce', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (181, 'theme_mods_wpportfolio', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (182, 'theme_switched', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (186, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (203, '_site_transient_timeout_browser_bd6be51e0926a593dfa798090bb5c0c5', '1390835671', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (204, '_site_transient_browser_bd6be51e0926a593dfa798090bb5c0c5', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"32.0.1700.77";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (276, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (298, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (302, 'twiget_options', 'a:1:{s:25:"twiget_default_options_db";s:0:"";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (303, 'widget_twiget-widget', 'a:2:{i:2;a:9:{s:8:"username";s:7:"zgordon";s:5:"count";s:1:"5";s:5:"title";s:13:"Latest tweets";s:13:"followercount";b:0;s:12:"hide_replies";b:0;s:10:"new_window";b:1;s:11:"profile_pic";b:1;s:8:"show_bio";b:0;s:14:"twitter_client";b:1;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (307, 'widget_wpDribbble', 'a:6:{s:10:"playerName";s:13:"allisongrayce";s:11:"widgetTitle";s:0:"";s:8:"maxItems";s:1:"1";s:10:"includeCSS";s:2:"on";s:10:"dropShadow";s:0:"";s:8:"bigImage";s:0:"";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (319, 'widget_wptreehouse_badges_widget', 'a:2:{i:2;a:3:{s:5:"title";s:16:"Treehouse Badges";s:10:"num_badges";s:1:"8";s:15:"display_tooltip";s:1:"1";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (320, 'wptreehouse_badges', 'a:3:{s:20:"wptreehouse_username";s:13:"allisongrayce";s:19:"wptreehouse_profile";O:8:"stdClass":7:{s:4:"name";s:23:"Allison Grayce Marshall";s:12:"profile_name";s:13:"allisongrayce";s:11:"profile_url";s:38:"http://teamtreehouse.com/allisongrayce";s:12:"gravatar_url";s:140:"https://secure.gravatar.com/avatar/db59a283dcd1589db55090746f1318de?s=200&d=https://teamtreehouse.com/assets/content/default_avatar.png&r=pg";s:13:"gravatar_hash";s:32:"db59a283dcd1589db55090746f1318de";s:6:"badges";a:41:{i:0;O:8:"stdClass":6:{s:2:"id";i:49;s:4:"name";s:6:"Newbie";s:3:"url";s:38:"http://teamtreehouse.com/allisongrayce";s:8:"icon_url";s:77:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Generic_Newbie.png";s:11:"earned_date";s:20:"2011-11-07T03:18:01Z";s:7:"courses";a:0:{}}i:1;O:8:"stdClass":6:{s:2:"id";i:46;s:4:"name";s:10:"Old School";s:3:"url";s:77:"http://teamtreehouse.com/library/how-to-make-a-website/beginning-html-and-css";s:8:"icon_url";s:78:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Generic_TVM_alt.png";s:11:"earned_date";s:20:"2011-11-07T03:18:01Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:21:"How to Make a Website";s:3:"url";s:54:"http://teamtreehouse.com/library/how-to-make-a-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:22:"Beginning HTML and CSS";s:3:"url";s:77:"http://teamtreehouse.com/library/how-to-make-a-website/beginning-html-and-css";s:11:"badge_count";i:1;}}}i:2;O:8:"stdClass":6:{s:2:"id";i:26;s:4:"name";s:12:"Introduction";s:3:"url";s:50:"http://teamtreehouse.com/library/html/introduction";s:8:"icon_url";s:74:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/HTML_Basics.png";s:11:"earned_date";s:20:"2011-11-10T14:45:46Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:4:"HTML";s:3:"url";s:37:"http://teamtreehouse.com/library/html";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:12:"Introduction";s:3:"url";s:50:"http://teamtreehouse.com/library/html/introduction";s:11:"badge_count";i:1;}}}i:3;O:8:"stdClass":6:{s:2:"id";i:28;s:4:"name";s:4:"Text";s:3:"url";s:42:"http://teamtreehouse.com/library/html/text";s:8:"icon_url";s:72:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/HTML_Text.png";s:11:"earned_date";s:20:"2011-11-10T14:47:23Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:4:"HTML";s:3:"url";s:37:"http://teamtreehouse.com/library/html";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:4:"Text";s:3:"url";s:42:"http://teamtreehouse.com/library/html/text";s:11:"badge_count";i:1;}}}i:4;O:8:"stdClass":6:{s:2:"id";i:48;s:4:"name";s:8:"Elements";s:3:"url";s:63:"http://teamtreehouse.com/library/aesthetic-foundations/elements";s:8:"icon_url";s:81:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Aesthetic_Elements.png";s:11:"earned_date";s:20:"2011-11-23T19:50:12Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:21:"Aesthetic Foundations";s:3:"url";s:54:"http://teamtreehouse.com/library/aesthetic-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:8:"Elements";s:3:"url";s:63:"http://teamtreehouse.com/library/aesthetic-foundations/elements";s:11:"badge_count";i:1;}}}i:5;O:8:"stdClass":6:{s:2:"id";i:42;s:4:"name";s:12:"Color Theory";s:3:"url";s:67:"http://teamtreehouse.com/library/aesthetic-foundations/color-theory";s:8:"icon_url";s:85:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Aesthetic_Color_Theory.png";s:11:"earned_date";s:20:"2011-11-23T20:42:19Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:21:"Aesthetic Foundations";s:3:"url";s:54:"http://teamtreehouse.com/library/aesthetic-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:12:"Color Theory";s:3:"url";s:67:"http://teamtreehouse.com/library/aesthetic-foundations/color-theory";s:11:"badge_count";i:1;}}}i:6;O:8:"stdClass":6:{s:2:"id";i:36;s:4:"name";s:10:"Principles";s:3:"url";s:65:"http://teamtreehouse.com/library/aesthetic-foundations/principles";s:8:"icon_url";s:83:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Aesthetic_Principles.png";s:11:"earned_date";s:20:"2011-11-23T20:53:49Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:21:"Aesthetic Foundations";s:3:"url";s:54:"http://teamtreehouse.com/library/aesthetic-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:10:"Principles";s:3:"url";s:65:"http://teamtreehouse.com/library/aesthetic-foundations/principles";s:11:"badge_count";i:1;}}}i:7;O:8:"stdClass":6:{s:2:"id";i:71;s:4:"name";s:21:"Aesthetic Foundations";s:3:"url";s:38:"http://teamtreehouse.com/allisongrayce";s:8:"icon_url";s:72:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Aesthetic.png";s:11:"earned_date";s:20:"2011-11-23T20:53:49Z";s:7:"courses";a:0:{}}i:8;O:8:"stdClass":6:{s:2:"id";i:57;s:4:"name";s:23:"Selector Code Challenge";s:3:"url";s:38:"http://teamtreehouse.com/allisongrayce";s:8:"icon_url";s:79:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/CSS_Selectors_CC.png";s:11:"earned_date";s:20:"2011-12-06T22:19:51Z";s:7:"courses";a:0:{}}i:9;O:8:"stdClass":6:{s:2:"id";i:87;s:4:"name";s:15:"Treehouse Staff";s:3:"url";s:38:"http://teamtreehouse.com/allisongrayce";s:8:"icon_url";s:72:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/treehouse.png";s:11:"earned_date";s:20:"2011-12-06T22:23:51Z";s:7:"courses";a:0:{}}i:10;O:8:"stdClass":6:{s:2:"id";i:94;s:4:"name";s:16:"Workspace Basics";s:3:"url";s:71:"http://teamtreehouse.com/library/photoshop-foundations/workspace-basics";s:8:"icon_url";s:82:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Photoshop_Workspace.png";s:11:"earned_date";s:20:"2011-12-30T16:56:10Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:21:"Photoshop Foundations";s:3:"url";s:54:"http://teamtreehouse.com/library/photoshop-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:16:"Workspace Basics";s:3:"url";s:71:"http://teamtreehouse.com/library/photoshop-foundations/workspace-basics";s:11:"badge_count";i:1;}}}i:11;O:8:"stdClass":6:{s:2:"id";i:121;s:4:"name";s:14:"Graphic Basics";s:3:"url";s:70:"http://teamtreehouse.com/library/technology-foundations/graphic-basics";s:8:"icon_url";s:77:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Graphic_Basics.png";s:11:"earned_date";s:20:"2012-03-01T19:25:55Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:22:"Technology Foundations";s:3:"url";s:55:"http://teamtreehouse.com/library/technology-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:14:"Graphic Basics";s:3:"url";s:70:"http://teamtreehouse.com/library/technology-foundations/graphic-basics";s:11:"badge_count";i:1;}}}i:12;O:8:"stdClass":6:{s:2:"id";i:131;s:4:"name";s:34:"Taking The Perfect Profile Picture";s:3:"url";s:38:"http://teamtreehouse.com/allisongrayce";s:8:"icon_url";s:74:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/profile-pic.png";s:11:"earned_date";s:20:"2012-04-02T15:52:36Z";s:7:"courses";a:0:{}}i:13;O:8:"stdClass":6:{s:2:"id";i:126;s:4:"name";s:10:"Chair Yoga";s:3:"url";s:38:"http://teamtreehouse.com/allisongrayce";s:8:"icon_url";s:73:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/chair-yoga.png";s:11:"earned_date";s:20:"2012-04-02T16:03:49Z";s:7:"courses";a:0:{}}i:14;O:8:"stdClass":6:{s:2:"id";i:132;s:4:"name";s:13:"Online Dating";s:3:"url";s:38:"http://teamtreehouse.com/allisongrayce";s:8:"icon_url";s:76:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/online-dating.png";s:11:"earned_date";s:20:"2012-04-02T16:04:07Z";s:7:"courses";a:0:{}}i:15;O:8:"stdClass":6:{s:2:"id";i:124;s:4:"name";s:12:"Layer Basics";s:3:"url";s:67:"http://teamtreehouse.com/library/photoshop-foundations/layer-basics";s:8:"icon_url";s:85:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Photoshop_Layer_Basics.png";s:11:"earned_date";s:20:"2012-04-02T16:08:56Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:21:"Photoshop Foundations";s:3:"url";s:54:"http://teamtreehouse.com/library/photoshop-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:12:"Layer Basics";s:3:"url";s:67:"http://teamtreehouse.com/library/photoshop-foundations/layer-basics";s:11:"badge_count";i:1;}}}i:16;O:8:"stdClass":6:{s:2:"id";i:135;s:4:"name";s:12:"Masks Basics";s:3:"url";s:67:"http://teamtreehouse.com/library/photoshop-foundations/masks-basics";s:8:"icon_url";s:78:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Photoshop_Masks.png";s:11:"earned_date";s:20:"2012-04-30T17:14:31Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:21:"Photoshop Foundations";s:3:"url";s:54:"http://teamtreehouse.com/library/photoshop-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:12:"Masks Basics";s:3:"url";s:67:"http://teamtreehouse.com/library/photoshop-foundations/masks-basics";s:11:"badge_count";i:1;}}}i:17;O:8:"stdClass":6:{s:2:"id";i:138;s:4:"name";s:10:"Type Tools";s:3:"url";s:65:"http://teamtreehouse.com/library/photoshop-foundations/type-tools";s:8:"icon_url";s:77:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/Photoshop_Type.png";s:11:"earned_date";s:20:"2012-05-17T14:14:39Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:21:"Photoshop Foundations";s:3:"url";s:54:"http://teamtreehouse.com/library/photoshop-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:10:"Type Tools";s:3:"url";s:65:"http://teamtreehouse.com/library/photoshop-foundations/type-tools";s:11:"badge_count";i:1;}}}i:18;O:8:"stdClass":6:{s:2:"id";i:154;s:4:"name";s:6:"MeetUp";s:3:"url";s:38:"http://teamtreehouse.com/allisongrayce";s:8:"icon_url";s:69:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/MeetUp.png";s:11:"earned_date";s:20:"2012-07-10T19:38:09Z";s:7:"courses";a:0:{}}i:19;O:8:"stdClass":6:{s:2:"id";i:167;s:4:"name";s:16:"Fluid Foundation";s:3:"url";s:87:"http://teamtreehouse.com/library/build-a-responsive-website/creating-a-fluid-foundation";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland2_Stage2.png";s:11:"earned_date";s:20:"2012-08-16T19:41:23Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:26:"Build a Responsive Website";s:3:"url";s:59:"http://teamtreehouse.com/library/build-a-responsive-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:27:"Creating a Fluid Foundation";s:3:"url";s:87:"http://teamtreehouse.com/library/build-a-responsive-website/creating-a-fluid-foundation";s:11:"badge_count";i:1;}}}i:20;O:8:"stdClass":6:{s:2:"id";i:173;s:4:"name";s:15:"Adaptive Design";s:3:"url";s:75:"http://teamtreehouse.com/library/build-a-responsive-website/adaptive-design";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland2_Stage3.png";s:11:"earned_date";s:20:"2012-09-05T16:08:47Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:26:"Build a Responsive Website";s:3:"url";s:59:"http://teamtreehouse.com/library/build-a-responsive-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:15:"Adaptive Design";s:3:"url";s:75:"http://teamtreehouse.com/library/build-a-responsive-website/adaptive-design";s:11:"badge_count";i:1;}}}i:21;O:8:"stdClass":6:{s:2:"id";i:196;s:4:"name";s:17:"Responsive Design";s:3:"url";s:77:"http://teamtreehouse.com/library/build-a-responsive-website/responsive-design";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland2_Stage4.png";s:11:"earned_date";s:20:"2012-09-27T02:17:34Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:26:"Build a Responsive Website";s:3:"url";s:59:"http://teamtreehouse.com/library/build-a-responsive-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:17:"Responsive Design";s:3:"url";s:77:"http://teamtreehouse.com/library/build-a-responsive-website/responsive-design";s:11:"badge_count";i:1;}}}i:22;O:8:"stdClass":6:{s:2:"id";i:3;s:4:"name";s:12:"Introduction";s:3:"url";s:71:"http://teamtreehouse.com/library/css-foundations-version-1/introduction";s:8:"icon_url";s:79:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/CSS_Introduction.png";s:11:"earned_date";s:20:"2012-10-03T23:30:41Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:27:"CSS Foundations - Version 1";s:3:"url";s:58:"http://teamtreehouse.com/library/css-foundations-version-1";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:12:"Introduction";s:3:"url";s:71:"http://teamtreehouse.com/library/css-foundations-version-1/introduction";s:11:"badge_count";i:1;}}}i:23;O:8:"stdClass":6:{s:2:"id";i:81;s:4:"name";s:5:"Links";s:3:"url";s:43:"http://teamtreehouse.com/library/html/links";s:8:"icon_url";s:73:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/HTML_Links.png";s:11:"earned_date";s:20:"2012-10-08T04:10:53Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:4:"HTML";s:3:"url";s:37:"http://teamtreehouse.com/library/html";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:5:"Links";s:3:"url";s:43:"http://teamtreehouse.com/library/html/links";s:11:"badge_count";i:1;}}}i:24;O:8:"stdClass":6:{s:2:"id";i:77;s:4:"name";s:7:"Objects";s:3:"url";s:45:"http://teamtreehouse.com/library/html/objects";s:8:"icon_url";s:75:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/HTML_Objects.png";s:11:"earned_date";s:20:"2012-10-08T04:18:05Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:4:"HTML";s:3:"url";s:37:"http://teamtreehouse.com/library/html";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:7:"Objects";s:3:"url";s:45:"http://teamtreehouse.com/library/html/objects";s:11:"badge_count";i:1;}}}i:25;O:8:"stdClass":6:{s:2:"id";i:165;s:4:"name";s:21:"Text Editors and HTML";s:3:"url";s:77:"http://teamtreehouse.com/library/build-a-simple-website/text-editors-and-html";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland1_Stage2.png";s:11:"earned_date";s:20:"2013-02-10T02:13:51Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:22:"Build a Simple Website";s:3:"url";s:55:"http://teamtreehouse.com/library/build-a-simple-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:21:"Text Editors and HTML";s:3:"url";s:77:"http://teamtreehouse.com/library/build-a-simple-website/text-editors-and-html";s:11:"badge_count";i:1;}}}i:26;O:8:"stdClass":6:{s:2:"id";i:170;s:4:"name";s:28:"Creating a Website Structure";s:3:"url";s:84:"http://teamtreehouse.com/library/build-a-simple-website/creating-a-website-structure";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland1_Stage3.png";s:11:"earned_date";s:20:"2013-02-10T03:26:50Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:22:"Build a Simple Website";s:3:"url";s:55:"http://teamtreehouse.com/library/build-a-simple-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:28:"Creating a Website Structure";s:3:"url";s:84:"http://teamtreehouse.com/library/build-a-simple-website/creating-a-website-structure";s:11:"badge_count";i:1;}}}i:27;O:8:"stdClass":6:{s:2:"id";i:175;s:4:"name";s:15:"Styling Content";s:3:"url";s:71:"http://teamtreehouse.com/library/build-a-simple-website/styling-content";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland1_Stage4.png";s:11:"earned_date";s:20:"2013-02-10T23:55:52Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:22:"Build a Simple Website";s:3:"url";s:55:"http://teamtreehouse.com/library/build-a-simple-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:15:"Styling Content";s:3:"url";s:71:"http://teamtreehouse.com/library/build-a-simple-website/styling-content";s:11:"badge_count";i:1;}}}i:28;O:8:"stdClass":6:{s:2:"id";i:268;s:4:"name";s:20:"InControl Conference";s:3:"url";s:38:"http://teamtreehouse.com/allisongrayce";s:8:"icon_url";s:72:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/incontrol.png";s:11:"earned_date";s:20:"2013-02-18T18:59:19Z";s:7:"courses";a:0:{}}i:29;O:8:"stdClass":6:{s:2:"id";i:245;s:4:"name";s:15:"Workflow Basics";s:3:"url";s:70:"http://teamtreehouse.com/library/photoshop-foundations/workflow-basics";s:8:"icon_url";s:83:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_DD_PSF_Stage3.png";s:11:"earned_date";s:20:"2013-02-28T15:13:08Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:21:"Photoshop Foundations";s:3:"url";s:54:"http://teamtreehouse.com/library/photoshop-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:15:"Workflow Basics";s:3:"url";s:70:"http://teamtreehouse.com/library/photoshop-foundations/workflow-basics";s:11:"badge_count";i:1;}}}i:30;O:8:"stdClass":6:{s:2:"id";i:206;s:4:"name";s:19:"Advanced Techniques";s:3:"url";s:79:"http://teamtreehouse.com/library/build-a-responsive-website/advanced-techniques";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland2_Stage5.png";s:11:"earned_date";s:20:"2013-03-07T16:13:31Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:26:"Build a Responsive Website";s:3:"url";s:59:"http://teamtreehouse.com/library/build-a-responsive-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:19:"Advanced Techniques";s:3:"url";s:79:"http://teamtreehouse.com/library/build-a-responsive-website/advanced-techniques";s:11:"badge_count";i:1;}}}i:31;O:8:"stdClass":6:{s:2:"id";i:162;s:4:"name";s:37:"Introduction to Responsive Web Design";s:3:"url";s:97:"http://teamtreehouse.com/library/build-a-responsive-website/introduction-to-responsive-web-design";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland2_Stage1.png";s:11:"earned_date";s:20:"2013-03-07T16:15:08Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:26:"Build a Responsive Website";s:3:"url";s:59:"http://teamtreehouse.com/library/build-a-responsive-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:37:"Introduction to Responsive Web Design";s:3:"url";s:97:"http://teamtreehouse.com/library/build-a-responsive-website/introduction-to-responsive-web-design";s:11:"badge_count";i:1;}}}i:32;O:8:"stdClass":6:{s:2:"id";i:159;s:4:"name";s:14:"Website Basics";s:3:"url";s:70:"http://teamtreehouse.com/library/build-a-simple-website/website-basics";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland1_Stage1.png";s:11:"earned_date";s:20:"2013-03-07T16:15:30Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:22:"Build a Simple Website";s:3:"url";s:55:"http://teamtreehouse.com/library/build-a-simple-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:14:"Website Basics";s:3:"url";s:70:"http://teamtreehouse.com/library/build-a-simple-website/website-basics";s:11:"badge_count";i:1;}}}i:33;O:8:"stdClass":6:{s:2:"id";i:179;s:4:"name";s:21:"Launching the Website";s:3:"url";s:77:"http://teamtreehouse.com/library/build-a-simple-website/launching-the-website";s:8:"icon_url";s:91:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WebsiteIsland1_Stage5.png";s:11:"earned_date";s:20:"2013-03-07T16:21:37Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:22:"Build a Simple Website";s:3:"url";s:55:"http://teamtreehouse.com/library/build-a-simple-website";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:21:"Launching the Website";s:3:"url";s:77:"http://teamtreehouse.com/library/build-a-simple-website/launching-the-website";s:11:"badge_count";i:1;}}}i:34;O:8:"stdClass":6:{s:2:"id";i:274;s:4:"name";s:24:"Intro to User Experience";s:3:"url";s:79:"http://teamtreehouse.com/library/ux-foundations/introduction-to-user-experience";s:8:"icon_url";s:82:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_DD_UX_Stage1.png";s:11:"earned_date";s:20:"2013-03-07T23:34:20Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:14:"UX Foundations";s:3:"url";s:47:"http://teamtreehouse.com/library/ux-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:31:"Introduction to User Experience";s:3:"url";s:79:"http://teamtreehouse.com/library/ux-foundations/introduction-to-user-experience";s:11:"badge_count";i:1;}}}i:35;O:8:"stdClass":6:{s:2:"id";i:187;s:4:"name";s:24:"Getting Started with PHP";s:3:"url";s:88:"http://teamtreehouse.com/library/build-a-simple-php-application/getting-started-with-php";s:8:"icon_url";s:86:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_eCommerce_Stage1.png";s:11:"earned_date";s:20:"2013-04-03T00:55:23Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:11:"Programming";s:3:"url";s:44:"http://teamtreehouse.com/library/programming";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:30:"Build a Simple PHP Application";s:3:"url";s:63:"http://teamtreehouse.com/library/build-a-simple-php-application";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:24:"Getting Started with PHP";s:3:"url";s:88:"http://teamtreehouse.com/library/build-a-simple-php-application/getting-started-with-php";s:11:"badge_count";i:1;}}}i:36;O:8:"stdClass":6:{s:2:"id";i:180;s:4:"name";s:24:"Getting Started with CSS";s:3:"url";s:73:"http://teamtreehouse.com/library/css-foundations/getting-started-with-css";s:8:"icon_url";s:83:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_DD_CSS_Stage1.png";s:11:"earned_date";s:20:"2013-04-03T01:14:58Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:15:"CSS Foundations";s:3:"url";s:48:"http://teamtreehouse.com/library/css-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:24:"Getting Started with CSS";s:3:"url";s:73:"http://teamtreehouse.com/library/css-foundations/getting-started-with-css";s:11:"badge_count";i:1;}}}i:37;O:8:"stdClass":6:{s:2:"id";i:286;s:4:"name";s:20:"Defining the Project";s:3:"url";s:68:"http://teamtreehouse.com/library/ux-foundations/defining-the-project";s:8:"icon_url";s:82:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_DD_UX_Stage2.png";s:11:"earned_date";s:20:"2013-04-09T18:55:02Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:14:"UX Foundations";s:3:"url";s:47:"http://teamtreehouse.com/library/ux-foundations";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:20:"Defining the Project";s:3:"url";s:68:"http://teamtreehouse.com/library/ux-foundations/defining-the-project";s:11:"badge_count";i:1;}}}i:38;O:8:"stdClass":6:{s:2:"id";i:202;s:4:"name";s:30:"Getting Started with WordPress";s:3:"url";s:92:"http://teamtreehouse.com/library/how-to-make-a-wordpress-blog/getting-started-with-wordpress";s:8:"icon_url";s:88:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WP_MakeBlog_Stage1.png";s:11:"earned_date";s:20:"2013-04-24T20:21:07Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:28:"How to Make a WordPress Blog";s:3:"url";s:61:"http://teamtreehouse.com/library/how-to-make-a-wordpress-blog";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:30:"Getting Started with WordPress";s:3:"url";s:92:"http://teamtreehouse.com/library/how-to-make-a-wordpress-blog/getting-started-with-wordpress";s:11:"badge_count";i:1;}}}i:39;O:8:"stdClass":6:{s:2:"id";i:203;s:4:"name";s:21:"Configuring WordPress";s:3:"url";s:83:"http://teamtreehouse.com/library/how-to-make-a-wordpress-blog/configuring-wordpress";s:8:"icon_url";s:88:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WP_MakeBlog_Stage2.png";s:11:"earned_date";s:20:"2013-04-24T20:38:39Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:28:"How to Make a WordPress Blog";s:3:"url";s:61:"http://teamtreehouse.com/library/how-to-make-a-wordpress-blog";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:21:"Configuring WordPress";s:3:"url";s:83:"http://teamtreehouse.com/library/how-to-make-a-wordpress-blog/configuring-wordpress";s:11:"badge_count";i:1;}}}i:40;O:8:"stdClass":6:{s:2:"id";i:209;s:4:"name";s:39:"Adding and Editing Content in WordPress";s:3:"url";s:88:"http://teamtreehouse.com/library/how-to-make-a-wordpress-blog/adding-and-editing-content";s:8:"icon_url";s:88:"https://wac.A8B5.edgecastcdn.net/80A8B5/achievement-images/badges_WP_MakeBlog_Stage3.png";s:11:"earned_date";s:20:"2013-04-24T20:43:11Z";s:7:"courses";a:3:{i:0;O:8:"stdClass":3:{s:5:"title";s:8:"Websites";s:3:"url";s:41:"http://teamtreehouse.com/library/websites";s:11:"badge_count";i:1;}i:1;O:8:"stdClass":3:{s:5:"title";s:28:"How to Make a WordPress Blog";s:3:"url";s:61:"http://teamtreehouse.com/library/how-to-make-a-wordpress-blog";s:11:"badge_count";i:1;}i:2;O:8:"stdClass":3:{s:5:"title";s:26:"Adding and Editing Content";s:3:"url";s:88:"http://teamtreehouse.com/library/how-to-make-a-wordpress-blog/adding-and-editing-content";s:11:"badge_count";i:1;}}}}s:6:"points";O:8:"stdClass":12:{s:5:"total";i:2268;s:4:"html";i:450;s:3:"css";i:432;s:10:"javascript";i:0;s:4:"ruby";i:0;s:3:"ios";i:0;s:8:"business";i:0;s:7:"android";i:0;s:3:"php";i:72;s:9:"wordpress";i:180;s:6:"design";i:432;s:9:"dev tools";i:0;}}s:12:"last_updated";i:1390750146;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (355, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:41:"https://wordpress.org/wordpress-3.8.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:41:"https://wordpress.org/wordpress-3.8.1.zip";s:10:"no_content";s:52:"https://wordpress.org/wordpress-3.8.1-no-content.zip";s:11:"new_bundled";s:53:"https://wordpress.org/wordpress-3.8.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.8.1";s:7:"version";s:5:"3.8.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1393525655;s:15:"version_checked";s:5:"3.8.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (356, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:20:"adiakritos@gmail.com";s:7:"version";s:5:"3.8.1";s:9:"timestamp";i:1390663213;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (377, '_transient_timeout_plugin_slugs', '1390836359', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (378, '_transient_plugin_slugs', 'a:11:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:26:"ag-custom-admin/plugin.php";i:2;s:19:"akismet/akismet.php";i:3;s:35:"backupwordpress/backupwordpress.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:9:"hello.php";i:6;s:71:"official-treehouse-badges-widgets-and-shortcodes/wptreehouse-badges.php";i:7;s:55:"super-simple-contact-form/super-simple-contact-form.php";i:8;s:17:"twiget/twiget.php";i:9;s:24:"wordpress-seo/wp-seo.php";i:10;s:34:"WP-Dribbble-master/wp-dribbble.php";}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (488, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1390789435', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (489, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:54:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/?v=3.9-alpha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/01/wordpress-3-8-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/01/wordpress-3-8-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3063";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:358:"After six weeks and more than 9.3 million downloads of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3809:"<p>After six weeks and more than <a href="http://wordpress.org/download/counter/">9.3 million downloads</a> of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available.</p>
<p>Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query was resolved. And if you&#8217;ve been frustrated by submit buttons that won&#8217;t do anything when you click on them (or thought you were going crazy, like some of us), we&#8217;ve found and fixed this &#8220;dead zone&#8221; on submit buttons.</p>
<p>It also contains a fix for <strong>embedding tweets</strong> (by placing the URL to the tweet on its own line), which was broken due to a recent Twitter API change. (For more on Embeds, see <a href="http://codex.wordpress.org/Embeds">the Codex</a>.)</p>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.8.1">list of tickets</a> and <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=27018&amp;stop_rev=26862">the changelog</a>. There&#8217;s also a <a href="http://make.wordpress.org/core/2014/01/22/wordpress-3-8-1-release-candidate/">detailed summary</a> for developers on the development blog.</p>
<p>If you are one of the millions already running WordPress 3.8, we will start rolling out automatic background updates for WordPress 3.8.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.8.1:</p>
<p><a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="#">José Pino</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p><em>WordPress three eight one<br />
We heard you didn&#8217;t like bugs<br />
So we took them out</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/01/wordpress-3-8-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WordPress 3.8 “Parker”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://wordpress.org/news/2013/12/parker/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/12/parker/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Dec 2013 17:00:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2765";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:354:"Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:18740:"<p>Version 3.8 of WordPress, named “Parker” in honor of <a href="http://en.wikipedia.org/wiki/Charlie_Parker">Charlie Parker</a>, bebop innovator, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet.</p>
<div id="v-6wORgoGb-1" class="video-player"><embed id="v-6wORgoGb-1-video" src="http://s0.videopress.com/player.swf?v=1.03&amp;guid=6wORgoGb&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<h2 class="aligncenter">Introducing a modern new design</h2>
<p><img class="wp-image-2951 aligncenter" alt="overview" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/overview.jpg?resize=623%2C193" data-recalc-dims="1" /></p>
<p>WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. Gone are overbearing gradients and dozens of shades of grey — bring on a bigger, bolder, more colorful design!</p>
<p><img class="aligncenter  wp-image-2856" style="margin-left: 0;margin-right: 0" alt="about-modern-wordpress" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/design.png?resize=623%2C151" data-recalc-dims="1" /></p>
<h3>Modern aesthetic</h3>
<p>The new WordPress dashboard has a fresh, uncluttered design that embraces clarity and simplicity.</p>
<h3>Clean typography</h3>
<p>The Open Sans typeface provides simple, friendly text that is optimized for both desktop and mobile viewing. It’s even open source, just like WordPress.</p>
<h3>Refined contrast</h3>
<p>We think beautiful design should never sacrifice legibility. With superior contrast and large, comfortable type, the new design is easy to read and a pleasure to navigate.</p>
<hr />
<h2 class="aligncenter">WordPress on every device</h2>
<p><img class="alignright  wp-image-2984" alt="responsive" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/responsive.jpg?resize=255%2C255" data-recalc-dims="1" />We all access the internet in different ways. Smartphone, tablet, notebook, desktop — no matter what you use, WordPress will adapt and you’ll feel right at home.</p>
<h3>High definition at high speed</h3>
<p>WordPress is sharper than ever with new vector-based icons that scale to your screen. By ditching pixels, pages load significantly faster, too.</p>
<hr />
<h2 class="aligncenter">Admin color schemes to match your personality</h2>
<p><img class="aligncenter  wp-image-2954" alt="colors" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/colors.jpg?resize=623%2C339" data-recalc-dims="1" /></p>
<p>WordPress just got a colorful new update. We’ve included eight new admin color schemes so you can pick the one that suits you best.</p>
<p>Color schemes can be previewed and changed from your Profile page.</p>
<hr />
<h2 class="aligncenter">Refined theme management</h2>
<p><img class="alignright  wp-image-2967" alt="themes" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/themes.jpg?resize=360%2C344" data-recalc-dims="1" />The new themes screen lets you survey your themes at a glance. Or want more information? Click to discover more. Then sit back and use your keyboard’s navigation arrows to flip through every theme you’ve got.</p>
<h3>Smoother widget experience</h3>
<p>Drag-drag-drag. Scroll-scroll-scroll. Widget management can be complicated. With the new design, we’ve worked to streamline the widgets screen.</p>
<p>Have a large monitor? Multiple widget areas stack side-by-side to use the available space. Using a tablet? Just tap a widget to add it.</p>
<hr />
<h2 class="aligncenter">Twenty Fourteen, a sleek new magazine theme</h2>
<p><img class="aligncenter size-large wp-image-2789" alt="The new Twenty Fourteen theme displayed on a laptop. tablet and phone" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/twentyfourteen.jpg?resize=692%2C275" data-recalc-dims="1" /></p>
<h3>Turn your blog into a magazine</h3>
<p>Create a beautiful magazine-style site with WordPress and Twenty Fourteen. Choose a grid or a slider to display featured content on your homepage. Customize your site with three widget areas or change your layout with two page templates.</p>
<p>With a striking design that does not compromise our trademark simplicity, Twenty Fourteen is our most intrepid default theme yet.</p>
<hr />
<h2>Beginning of a new era</h2>
<p>This release was led by Matt Mullenweg. This is our second release using the new plugin-first development process, with a much shorter timeframe than in the past. We think it’s been going great. You can check out the features currently in production on the <a title="Make WordPress Core" href="http://make.wordpress.org/core/" target="_blank">make/core blog</a>.</p>
<p>There are 188 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/admiralthrawn">admiralthrawn</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aralbald">Andrey Kabakchiev</a>, <a href="http://profiles.wordpress.org/apeatling">Andy Peatling</a>, <a href="http://profiles.wordpress.org/ankitgadertcampcom">Ankit Gade</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/fliespl">Arkadiusz Rzadkowolski</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/binarymoon">binarymoon</a>, <a href="http://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/calin">Calin Don</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="http://profiles.wordpress.org/caspie">Caspie</a>, <a href="http://profiles.wordpress.org/chrisbliss18">Chris Jean</a>, <a href="http://profiles.wordpress.org/iblamefish">Clinton Montague</a>, <a href="http://profiles.wordpress.org/cojennin">cojennin</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/dbernar1">Dan Bernardic</a>, <a href="http://profiles.wordpress.org/danieldudzic">Daniel Dudzic</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/datafeedrcom">datafeedr</a>, <a href="http://profiles.wordpress.org/lessbloat">Dave Martin</a>, <a href="http://profiles.wordpress.org/drw158">Dave Whitley</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/dziudek">dziudek</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gnarf37">gnarf37</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/isaackeyet">Isaac Keyet</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="http://profiles.wordpress.org/janhenckens">janhenckens</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jblz">Jeff Bowen</a>, <a href="http://profiles.wordpress.org/jeffr0">Jeff Chandler</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jeherve">Jeremy Herve</a>, <a href="http://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jhned">jhned</a>, <a href="http://profiles.wordpress.org/jim912">jim912</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joen">Joen Asmussen</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/nukaga">Junko Nukaga</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K. Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/codebykat">Kat Hagan</a>, <a href="http://profiles.wordpress.org/littlethingsstudio">Kate Whitley</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/koki4a">Konstantin Dankov</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lite3">lite3</a>, <a href="http://profiles.wordpress.org/lucp">Luc Princen</a>, <a href="http://profiles.wordpress.org/latz">Lutz Schroer</a>, <a href="http://profiles.wordpress.org/mako09">Mako</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/megane9988">megane9988</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/micahwave">micahwave</a>, <a href="http://profiles.wordpress.org/cainm">Michael Cain</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">Michael Erlewine</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/chellycat">Michelle Langston</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mt8biz">moto hachi</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/ninio">ninio</a>, <a href="http://profiles.wordpress.org/ninnypants">ninnypants</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="http://profiles.wordpress.org/odysseygate">odyssey</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/swissspidy">Pascal Birchler</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/senlin">Piet</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/bamadesigner">Rachel Carden</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/radices">Radices</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/defries">Remkus de Vries</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/wet">Robert Wetzlmayr, PHP-Programmierer</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood</a>, <a href="http://profiles.wordpress.org/sanchothefat">sanchothefat</a>, <a href="http://profiles.wordpress.org/sboisvert">sboisvert</a>, <a href="http://profiles.wordpress.org/scottbasgaard">Scott Basgaard</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/designsimply">Sheri Bigelow (designsimply)</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirbrillig">sirbrillig</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/thomasguillot">Thomas Guillot</a>, <a href="http://profiles.wordpress.org/tierra">tierra</a>, <a href="http://profiles.wordpress.org/tillkruess">Till Krüss</a>, <a href="http://profiles.wordpress.org/tlamedia">TLA Media</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tommcfarlin">tommcfarlin</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/taupecat">Tracy Rotton</a>, <a href="http://profiles.wordpress.org/trishasalas">trishasalas</a>, <a href="http://profiles.wordpress.org/mbmufffin">Tyler Smith</a>, <a href="http://profiles.wordpress.org/grapplerulrich">Ulrich</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/l10n">Vladimir</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yonasy">yonasy</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, and <a href="http://profiles.wordpress.org/tollmanz">Zack Tollman</a>. Also thanks to <a href="http://benmorrison.org/">Ben Morrison</a> and <a href="http://christineswebb.com/">Christine Webb</a> for help with the video.</p>
<p>Thanks for choosing WordPress. See you soon for version 3.9!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"http://wordpress.org/news/2013/12/parker/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"3.8 RC2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://wordpress.org/news/2013/12/3-8-rc2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/news/2013/12/3-8-rc2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Dec 2013 01:08:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2805";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:343:"Release candidate 2 of WordPress 3.8 is now available for download. This is the last pre-release, and we expect it to be effectively identical to what&#8217;s officially released to the public on Thursday. This means if you are a plugin or theme developer, start your engines! (If they&#8217;re not going already.) Lots of admin code [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1180:"<p>Release candidate 2 of WordPress 3.8 is <a href="http://wordpress.org/wordpress-3.8-RC2.zip">now available for download</a>. This is the last pre-release, and we expect it to be effectively identical to what&#8217;s officially released to the public on Thursday.</p>
<p>This means if you are a plugin or theme developer, start your engines! (If they&#8217;re not going already.) Lots of admin code has changed so it&#8217;s especially important to see if your plugin works well within the new admin design and layout, and update <a href="http://wordpress.org/plugins/about/readme.txt">the &#8220;Tested up to:&#8221; part of your plugin readme.txt</a>.</p>
<p>If there is something in your plugin that you&#8217;re unable to fix, or if you think you&#8217;ve found a bug, join us <a href="http://codex.wordpress.org/IRC">in #wordpress-dev in IRC</a>, especially if you&#8217;re able to join during the dev chat on Wednesday, or post in the <a href="http://wordpress.org/support/forum/alphabeta">alpha/beta forum</a>. The developers and designers who worked on this release are happy to help anyone update their code before the 3.8 release.</p>
<p>Happy hacking, everybody!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/news/2013/12/3-8-rc2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"WordPress 3.8 RC1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/12/3-8-almost/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/news/2013/12/3-8-almost/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Dec 2013 09:54:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2760";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:345:"We&#8217;re entering the quiet but busy part of a release, whittling down issues to bring you all of the new features you&#8217;re excited about with the stability you expect from WordPress. There are just a few days from the &#8220;code freeze&#8221; for our 3.8 release, which includes a number of exciting enhancements, so the focus [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1873:"<p>We&#8217;re entering the quiet but busy part of a release, whittling down issues to bring you all of the new features you&#8217;re excited about with the stability you expect from WordPress. There are just a few days from the &#8220;code freeze&#8221; for our 3.8 release, <a href="http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/">which includes a number of exciting enhancements</a>, so the focus is on identifying any major issues and resolving them as soon as possible.</p>
<p>If you&#8217;ve ever wondered about how to contribute to WordPress, here&#8217;s a time you can: download this release candidate and use it in as many ways as you can imagine. Try to break it, and if you do, let us know how you did it so we can make sure it never happens again. If you work for a web host, this is the release you should test as much as possible and start getting your automatic upgrade systems and 1-click installers ready.</p>
<p><a href="http://wordpress.org/wordpress-3.8-RC1.zip">Download WordPress 3.8 RC1</a> (zip) or use the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;).</p>
<p>If you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.8">everything we’ve fixed</a> so far.</p>
<p><em>We&#8217;re so close to the</em><br />
<em>finish line, jump in and help</em><br />
<em>good karma is yours.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/12/3-8-almost/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.8 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Nov 2013 05:21:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2754";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:307:"The first beta of the 3.8 is now available, and the next dates to watch out for are code freeze on December 5th and a final release on December 12th. 3.8 brings together several of the features as plugins projects and while this isn&#8217;t our first rodeo, expect this to be more beta than usual. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2236:"<p>The first beta of the 3.8 is now available, and the next dates to watch out for are code freeze on December 5th and a final release on December 12th.</p>
<p>3.8 brings together <a href="http://make.wordpress.org/core/features-as-plugins/">several of the features as plugins projects</a> and while this isn&#8217;t our first rodeo, expect this to be more beta than usual. The headline things to test out in this release are:</p>
<ul>
<li>The new admin design, especially the responsive aspect of it. Try it out on different devices and browsers, see how it goes, especially the more complex pages like widgets or seldom-looked-at-places like Press This. Color schemes, which you can change on your profile, have also been spruced up.</li>
<li>The dashboard homepage has been refreshed, poke and prod it.</li>
<li>Choosing themes under Appearance is completely different, try to break it however possible.</li>
<li>There&#8217;s a new default theme, Twenty Fourteen.</li>
<li>Over 250 issues closed already.</li>
</ul>
<p>Given how many things in the admin have changed it&#8217;s extra super duper important to test as many plugins and themes with admin pages against the new stuff. Also if you&#8217;re a developer consider how you can make your admin interface fit the MP6 aesthetic better.</p>
<p>As always, if you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.8">everything we’ve fixed</a> so far.</p>
<p><a href="http://wordpress.org/wordpress-3.8-beta-1.zip">Download WordPress 3.8 Beta 1</a> (zip) or use the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;).</p>
<p><em>Alphabet soup of</em><br />
<em>Plugins as features galore</em><br />
<em>The future is here</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.7.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/10/wordpress-3-7-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/10/wordpress-3-7-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Oct 2013 21:04:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2745";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:371:"WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling some [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1594:"<p>WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including:</p>
<ul>
<li>Images with captions no longer appear broken in the visual editor.</li>
<li>Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org.</li>
<li>Avoid fatal errors with certain plugins that were incorrectly calling some WordPress functions too early.</li>
<li>Fix hierarchical sorting in get_pages(), exclusions in wp_list_categories(), and in_category() when called with empty values.</li>
<li>Fix a warning that may occur in certain setups while performing a search, and a few other notices.</li>
</ul>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.7.1">list of tickets</a> and <a href="http://core.trac.wordpress.org/log/branches/3.7?stop_rev=25914&amp;rev=25986">the changelog</a>.</p>
<p>If you are one of the <a href="http://wordpress.org/download/counter/">nearly two million</a> already running WordPress 3.7, we will start rolling out the all-new <a href="http://wordpress.org/news/2013/10/basie/">automatic background updates</a> for WordPress 3.7.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.7.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p><em>Just a few fixes<br />
Your new update attitude:<br />
Zero clicks given</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/wordpress-3-7-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.7 “Basie”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2013/10/basie/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2013/10/basie/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Oct 2013 22:35:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2736";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:357:"Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don&#8217;t have to lift a finger to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:17229:"<p>Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of <a href="http://en.wikipedia.org/wiki/Count_basie">Count Basie</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones:</p>
<ul>
<li><strong>Updates while you sleep</strong>: With WordPress 3.7, you don&#8217;t have to lift a finger to apply maintenance and security updates. Most sites are now able to automatically apply these updates in the background. The update process also has been made even more reliable and secure, with dozens of new checks and safeguards.</li>
<li><strong>Stronger password recommendations</strong>: Your password is your site&#8217;s first line of defense. It&#8217;s best to create passwords that are complex, long, and unique. To that end, our password meter has been updated in WordPress 3.7 to recognize common mistakes that can weaken your password: dates, names, keyboard patterns (123456789), and even pop culture references.</li>
<li><strong>Better global support</strong>: Localized versions of WordPress will receive faster and more complete translations. WordPress 3.7 adds support for automatically installing the right language files and keeping them up to date, a boon for the many millions who use WordPress in a language other than English.</li>
</ul>
<p>For developers there are lots of options around how to control the new updates feature, including allowing it to handle major upgrades as well as minor ones, more sophisticated date query support, and multisite improvements. As always, if you&#8217;re hungry for more <a href="http://codex.wordpress.org/Version_3.7">dive into the Codex</a> or browse the <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.7">over 400 closed tickets on Trac</a>.</p>
<h3>A New Wave</h3>
<p>This release was led by Andrew Nacin, backed up by Dion Hulse and Jon Cave. This is our first release using the new plugin-first development process, with a much shorter timeframe than in the past. (3.6 was released in August.) The 3.8 release, due in December, will continue this plugin-led development cycle that gives much more autonomy to plugin leads and allows us to decouple feature development from a release. You can follow this grand experiment, and what we&#8217;re learning from it, <a href="http://make.wordpress.org/core/">on the make/core blog</a>. There are 211 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/technosailor">Aaron Brazell</a>, <a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/andg">andg</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/andrewspittle">Andrew Spittle</a>, <a href="http://profiles.wordpress.org/askapache">askapache</a>, <a href="http://profiles.wordpress.org/atimmer">atimmer</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/beaulebens">Beau Lebens</a>, <a href="http://profiles.wordpress.org/benmoody">ben.moody</a>, <a href="http://profiles.wordpress.org/bhengh">Ben Miller</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bftrick">BFTrick</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/bmb">bmb</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brianhogg">brianhogg</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/charlesclarkson">CharlesClarkson</a>, <a href="http://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisrudzki">Chris Rudzki</a>, <a href="http://profiles.wordpress.org/aeg0125">coderaaron</a>, <a href="http://profiles.wordpress.org/coenjacobs">Coen Jacobs</a>, <a href="http://profiles.wordpress.org/crrobi01">Colin Robinson</a>, <a href="http://profiles.wordpress.org/andreasnrb">cyonite</a>, <a href="http://profiles.wordpress.org/daankortenbach">Daan Kortenbach</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/convissor">Daniel Convissor</a>, <a href="http://profiles.wordpress.org/dartiss">dartiss</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/csixty4">Dave Ross</a>, <a href="http://profiles.wordpress.org/davidjlaietta">David Laietta</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/dllh">dllh</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling (ocean90)</a>, <a href="http://profiles.wordpress.org/dpash">dpash</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/dzver">dzver</a>, <a href="http://profiles.wordpress.org/cais">Edward Caissie</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faishal">faishal</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/foofy">Foofy</a>, <a href="http://profiles.wordpress.org/fjarrett">Frankie Jarrett</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/gayadesign">Gaya Kessler</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gizburdt">Gizburdt</a>, <a href="http://profiles.wordpress.org/goldenapples">goldenapples</a>, <a href="http://profiles.wordpress.org/gradyetc">gradyetc</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/webord">Gustavo Bordoni</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/creativeinfusion">itinerant</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jakubtyrcha">jakub.tyrcha</a>, <a href="http://profiles.wordpress.org/jamescollins">James Collins</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="http://profiles.wordpress.org/johnnyb">John Beales</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn (johnbillion)</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/jchristopher">Jonathan Christopher</a>, <a href="http://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jonlynch">Jon Lynch</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/josephscott">Joseph Scott</a>, <a href="http://profiles.wordpress.org/betzster">Josh Betz</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/ketwaroo">Ketwaroo</a>, <a href="http://profiles.wordpress.org/kevinb">kevinB</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/koopersmith">koopersmith</a>, <a href="http://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis (leewillis77)</a>, <a href="http://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="http://profiles.wordpress.org/layotte">Lew Ayotte</a>, <a href="http://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="http://profiles.wordpress.org/iworks">Marcin Pietrzak</a>, <a href="http://profiles.wordpress.org/cimmo">Marco Cimmino</a>, <a href="http://profiles.wordpress.org/marco_teethgrinder">Marco Galasso</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/naomicbush">Naomi</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/natejacobs">NateJacobs</a>, <a href="http://profiles.wordpress.org/nathanrice">nathanrice</a>, <a href="http://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nickmomrik">Nick Momrik</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/noahsilverstein">noahsilverstein</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nukaga">nukaga</a>, <a href="http://profiles.wordpress.org/nullvariable">nullvariable</a>, <a href="http://profiles.wordpress.org/butuzov">Oleg Butuzov</a>, <a href="http://profiles.wordpress.org/paolal">Paolo Belcastro</a>, <a href="http://profiles.wordpress.org/xparham">Parham</a>, <a href="http://profiles.wordpress.org/pbiron">Paul Biron</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/peterjaap">peterjaap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/plocha">plocha</a>, <a href="http://profiles.wordpress.org/pollett">Pollett</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="http://profiles.wordpress.org/rasheed">Rasheed Bydousi</a>, <a href="http://profiles.wordpress.org/raybernard">RayBernard</a>, <a href="http://profiles.wordpress.org/rboren">rboren</a>, <a href="http://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="http://profiles.wordpress.org/rfair404">rfair404</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/r3df">Rick Radko</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/wpmuguru">Ron Rennick</a>, <a href="http://profiles.wordpress.org/rpattillo">rpattillo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/hotchkissconsulting">Sam Hotchkiss</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/scottsweb">scottsweb</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/scruffian">scruffian</a>, <a href="http://profiles.wordpress.org/tenpura">Seisuke Kuraishi (tenpura)</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sillybean">Stephanie Leary</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar (@netweb)</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/strangerstudios">strangerstudios</a>, <a href="http://profiles.wordpress.org/sweetie089">sweetie089</a>, <a href="http://profiles.wordpress.org/swissspidy">swissspidy</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tivnet">tivnet</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/toscho">toscho</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/sorich87">Ulrich Sossou</a>, <a href="http://profiles.wordpress.org/vericgar">vericgar</a>, <a href="http://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wikicms">wikicms</a>, <a href="http://profiles.wordpress.org/willnorris">Will Norris</a>, <a href="http://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="http://profiles.wordpress.org/wycks">wycks</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p>Enjoy what may be one of your last few manual updates. See you soon for version 3.8!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/10/basie/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.7 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 00:05:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2729";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:417:"The second release candidate of WordPress 3.7 is now available for testing! Those of you already testing WordPress 3.7 will be updated automatically to RC2. (Nice.) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”) or download the release candidate here (zip). Please post to the Alpha/Beta [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1183:"<p>The second release candidate of WordPress 3.7 is now available for testing!</p>
<p>Those of you already testing WordPress 3.7 will be updated automatically to RC2. (<em>Nice.</em>) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”) or <a href="http://wordpress.org/wordpress-3.7-RC2.zip">download the release candidate here</a> (zip). Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a> if you think you&#8217;ve found a bug, and if any known issues are raised, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>Developers, please test your plugins and themes against WordPress 3.7. If there is a compatibility issue, let us know as soon as possible so we can deal with it before the final release.</p>
<p>For more on WordPress 3.7, check out the <a href="http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/">announcement post for Release Candidate 1</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Upcoming WordCamps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Oct 2013 19:25:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2723";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:368:"WordCamps are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Jen Mylo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3584:"<p><a href="http://central.wordcamp.org/">WordCamps</a> are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s over. If there&#8217;s one near you, check it out! In addition to getting to know your local WordPress community, most WordCamps attract some traveling visitors a well, giving you the chance to meet contributors to the WordPress open source project and <a href="http://make.wordpress.org/">get involved</a> yourself.</p>
<p>Here are the WordCamps on the schedule for the rest of this year.</p>
<p>October 25-27: <strong><a href="http://2013.boston.wordcamp.org/">WordCamp Boston</a></strong>, Boston, MA, USA<br />
October 25-26: <strong><a href="http://2013.malaga.wordcamp.org/">WordCamp Malaga</a></strong>, Spain<br />
October 26: <strong><a href="http://2013.nepal.wordcamp.org/">WordCamp Nepal</a></strong>, Kathmandu, Nepal<br />
October 26: <strong><a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia</a></strong>, Bulgaria<br />
November 7: <strong><a href="http://2013.capetown.wordcamp.org/">WordCamp Cape Town</a></strong>, South Africa<br />
November 9: <strong><a href="http://2013.porto.wordcamp.org/">WordCamp Porto</a></strong>, Portugal<br />
November 9-10: <strong><a href="http://2013.kenya.wordcamp.org/">WordCamp Kenya</a></strong>, Nairobi, Kenya<br />
November 15: <strong><a href="http://2013.edmonton.wordcamp.org/">WordCamp Edmonton</a></strong>, AB, Canada<br />
November 16-17: <strong><a href="http://2013.orlando.wordcamp.org/">WordCamp Orlando</a></strong>, FL, USA<br />
November 16: <strong><a href="http://2013.denver.wordcamp.org/">WordCamp Denver</a></strong>, CO, USA<br />
November 23-24: <strong><a href="http://2013.london.wordcamp.org/">WordCamp London</a></strong>, UK<br />
November 23-24: <strong><a href="http://2013.raleigh.wordcamp.org/">WordCamp Raleigh</a></strong>, NC, USA<br />
November 23: <strong><a href="http://2013.saopaulo.wordcamp.org/">WordCamp São Paulo</a></strong>, Brazil<br />
December 14: <strong><a href="http://2013.vegas.wordcamp.org/">WordCamp Las Vegas</a></strong>, NV, USA<br />
December 14-15: <strong><a href="http://2013.sevilla.wordcamp.org/">WordCamp Sevilla</a></strong>, Spain</p>
<p>No WordCamps on this list in your area? Not to worry! There are thriving <a href="http://wordpress.meetup.com/">WordPress meetups</a> all over the world where you can meet like-minded people, and we maintain a library of <a href="http://wordpress.tv/category/wordcamptv/">WordCamp videos</a> at <a href="http://wordpress.tv/">WordPress.tv</a>.</p>
<h3>Get Involved</h3>
<ul>
<li>If you&#8217;re interested in organizing a WordCamp in your area, check out our <a href="http://plan.wordcamp.org/">WordCamp planning</a> site.</li>
<li>If you&#8217;re interested in <a href="http://make.wordpress.org/community/meetup-interest-form/">starting a WordPress meetup</a> in your area, let us know and we can set up a group on meetup.com for you.</li>
<li>And speaking of WordCamp videos, we&#8217;ve recently enabled volunteer-generated subtitles/closed captioning of the videos on WordPress.tv to make them more accessible. Interested in helping? Check out the <a href="http://wordpress.tv/using-amara-org-to-caption-or-subtitle-a-wordpress-tv-video/">WordPress.tv subtitling instructions</a>.</li>
</ul>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.7 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Oct 2013 19:52:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2718";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:331:"The first release candidate for WordPress 3.7 is now available! In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 next week, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2274:"<p>The first release candidate for WordPress 3.7 is now available!</p>
<p>In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>WordPress 3.7 introduces <strong>automatic background updates</strong> for security and minor releases (like updating from 3.7 to 3.7.1). These are really easy to test  — RC 1 will update every 12 hours or so to the latest development version, and then email you the results. (You may get two emails: one for debugging, and one all users of 3.7 will receive.) If something went wrong, you can report it.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 3.7 RC1, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.7-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what&#8217;s new in WordPress 3.7, visit the awesome About screen in your dashboard (<strong><img alt="" src="http://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" data-recalc-dims="1" /> → About</strong> in the toolbar). There, you can also see if your install is eligible for background updates. WordPress won’t automatically update, for example, if you’re using version control like Subversion or Git.</p>
<p><strong>Developers,</strong> please test your plugins and themes against WordPress 3.7, so that if there is a compatibility issue, we can figure it out before the final release. Make sure you post any issues to the support forums.</p>
<p><em>WordPress three seven</em><br />
<em>A self-updating engine</em><br />
<em>Lies beneath the hood</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 26 Jan 2014 14:23:54 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 23 Jan 2014 20:54:06 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (490, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1390789435', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (491, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1390746235', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (492, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1390789436', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (493, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WordPress.tv: David Lockie: 10 Ways That WordPressers Can Make The World A Better Place";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=30102";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://wordpress.tv/2014/01/25/david-lockie-10-ways-that-wordpressers-can-make-the-world-a-better-place/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:723:"<div id="v-eRcBXwZA-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/30102/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/30102/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=30102&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/01/25/david-lockie-10-ways-that-wordpressers-can-make-the-world-a-better-place/"><img alt="David Lockie: 10 Ways That WordPressers Can Make The World A Better Place" src="http://videos.videopress.com/eRcBXwZA/video-370b734fce_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 26 Jan 2014 00:14:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WordPress.tv: Hristo Pandjarov: Need For Speed: Gear Up Your WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=30087";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wordpress.tv/2014/01/25/hristo-pandjarov-need-for-speed-gear-up-your-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:688:"<div id="v-1nPSHx0E-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/30087/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/30087/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=30087&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/01/25/hristo-pandjarov-need-for-speed-gear-up-your-wordpress/"><img alt="Hristo Pandjarov: Need For Speed: Gear Up Your WordPress" src="http://videos.videopress.com/1nPSHx0E/video-99b7cff76f_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 26 Jan 2014 00:06:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: WPWeekly Episode 135 – Podcasting With WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=15427&preview_id=15427";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:156:"http://wptavern.com/wpweekly-episode-135-podcasting-with-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-135-podcasting-with-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3563:"<p>In this episode of WordPress Weekly, I was joined by <a href="http://marcuscouch.com/" title="http://marcuscouch.com/">Marcus Couch</a> and Matt Medeiros of <a href="http://mattreport.com/" title="http://mattreport.com/">Mattreport.com</a> and founder of <a href="http://slocumstudio.com/" title="http://slocumstudio.com/">Slocumstudio.com</a>. I threw out the show notes for this episode and instead, tapped into the collective knowledge of my guests to discuss the world of podcasting with WordPress. The first part of the conversation covers equipment, audio quality, and audience while the second half focuses on WordPress. One thing immediately became clear. We&#8217;re all fans of the <a href="http://wordpress.org/plugins/powerpress/" title="http://wordpress.org/plugins/powerpress/">Blubrry Powerpress</a> plugin. If you&#8217;re thinking about starting a show and using WordPress to publish it, you&#8217;ll want to listen to this episode!</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/wordpress-developers-take-note-tinymce-4-0-merged-into-core" title="http://wptavern.com/wordpress-developers-take-note-tinymce-4-0-merged-into-core">WordPress Developers Take Note: TinyMCE 4.0 Merged Into Core</a><br />
<a href="http://wptavern.com/interview-with-jason-schuller-founder-of-press75-com" title="http://wptavern.com/interview-with-jason-schuller-founder-of-press75-com">Interview With Jason Schuller Founder Of Press75.com</a><br />
<a href="http://wptavern.com/tickets-on-sale-for-wordcamp-dayton-ohio" title="http://wptavern.com/tickets-on-sale-for-wordcamp-dayton-ohio">Tickets On Sale For WordCamp Dayton, Ohio</a><br />
<a href="http://wptavern.com/wordpress-3-8-1-released-fixes-twitter-oembed-issues" title="http://wptavern.com/wordpress-3-8-1-released-fixes-twitter-oembed-issues">WordPress 3.8.1 Released: Fixes Twitter oEmbed Issues</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="http://wordpress.org/plugins/google-drive-wp-media/" title="http://wordpress.org/plugins/google-drive-wp-media/">Google Drive WP Media</a> allows direct access to your Google Drive, enabling you to manage your files remotely from your WordPress blog. Upload and share your files directly from your WordPress blog to Google Drive and back again.</p>
<p><a href="http://wordpress.org/plugins/skype-mobile-switcher/" title="http://wordpress.org/plugins/skype-mobile-switcher/">Skype Mobile Switcher</a> uses a shortcode to switch between presenting a Skype call link and a phone number that can be clicked to call. </p>
<p><a href="http://wordpress.org/plugins/dynamic-home-length/" title="http://wordpress.org/plugins/dynamic-home-length/">Dynamic Home Length</a> adjusts the number of posts per page of the front page based on the total amount of text in all recent posts so that its height will automatically be in proportional with the height of your widget column.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, January 31st 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #135:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 25 Jan 2014 03:17:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: Technique For Creating Portable Social Menus In WordPress Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15271";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:192:"http://wptavern.com/technique-for-creating-portable-social-menus-in-wordpress-themes?utm_source=rss&utm_medium=rss&utm_campaign=technique-for-creating-portable-social-menus-in-wordpress-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1903:"<p>One of the features within the <a href="http://themehybrid.com/themes/stargazer" title="http://themehybrid.com/themes/stargazer">Stargazer</a> child theme we are using on WPTavern are the social icons located at the bottom of the site. The social icons are not images but rather, <a href="http://genericons.com/" title="http://genericons.com/">Genericons</a>. As explained by <a href="http://kovshenin.com/2014/social-menus-in-wordpress-themes/" title="http://kovshenin.com/2014/social-menus-in-wordpress-themes/">Konstantin Kovshenin</a>, Justin Tadlock used a method to add social network icons that are portable between themes. By using a few simple CSS selectors, the social links are able to be targeted by their <em>href</em> attribute.</p>
<blockquote><p>No more plugin dependencies, no more long docs of CSS class names, no more arguing with the Theme Reviewers Theme on WordPress.org that social profile icons are part of the appearance of a theme and not “plugin territory” because users can lose their content upon theme switch.</p></blockquote>
<p>Justin Tadlock published <a href="http://justintadlock.com/archives/2013/08/07/social-media-nav-menus" title="http://justintadlock.com/archives/2013/08/07/social-media-nav-menus">two</a> different <a href="http://justintadlock.com/archives/2013/08/14/social-nav-menus-part-2" title="http://justintadlock.com/archives/2013/08/14/social-nav-menus-part-2">posts</a> that explain the thought process behind the technique as well as the code needed to make it work. It&#8217;s being championed by the WordPress theme community to the point of it possibly being added to the <a href="https://make.wordpress.org/docs/theme-developer-handbook/releasing-your-theme/theme-review-guidelines/" title="https://make.wordpress.org/docs/theme-developer-handbook/releasing-your-theme/theme-review-guidelines/">WordPress Theme Review Guidelines</a>. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Jan 2014 22:06:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: Status App: A WordPress-Powered Mobile Micro Messaging Service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14785";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:186:"http://wptavern.com/status-app-a-wordpress-powered-mobile-micro-messaging-service?utm_source=rss&utm_medium=rss&utm_campaign=status-app-a-wordpress-powered-mobile-micro-messaging-service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3595:"<p>As Matt Mullenweg predicted in the State of the Word address in 2013, this new year brings with it a growing excitement around building applications based on WordPress. The launch of <a href="http://wptavern.com/apppresser-launches-first-mobile-app-development-framework-for-wordpress" target="_blank">AppPresser</a>, the first mobile application framework for WordPress, produced a healthy buzz around the idea and now the community is primed for more.</p>
<p>Ryan Fugate, better known around the web as &#8220;<a href="https://twitter.com/modemlooper" target="_blank">@modemlooper</a>&#8220;, has created a WordPress-powered micro messaging app for mobile. <a href="http://taptappress.com/status-app/" target="_blank">Status App</a> is actually a WordPress plugin that creates a Twitter type micro blogging platform for mobile users at your chosen URL.</p>
<p><img src="http://wptavern.com/wp-content/uploads/2014/01/status.png" alt="status" width="906" height="454" class="aligncenter size-full wp-image-15390" /></p>
<p>Want to try it? Visit this URL from a mobile browser: <a href="http://status.taptappress.com/status" target="_blank">http://status.taptappress.com/status</a></p>
<p>The status updates are stored as a custom post type within WordPress and can be managed from the admin. Right now the app doesn&#8217;t include a settings panel. You simply activate the plugin and then visit your site on mobile. </p>
<p><img src="http://wptavern.com/wp-content/uploads/2014/01/status-cpt.png" alt="status-cpt" width="985" height="302" class="aligncenter size-full wp-image-15403" /></p>
<p>Since Status App is technically a social app, why didn&#8217;t he build it with BuddyPress? Ryan explained his reasoning when he <a href="http://taptappress.com/status-app/" target="_blank">introduced</a> the app: </p>
<blockquote><p>This could have been an app for BuddyPress but I am targeting a different group of users. BuddyPress is for front sided social networks with lots of features. Status App is for the content creators of a site. If you have ever used Yammer then you can understand the need for this type of functionality.</p></blockquote>
<p>For now, @modemlooper is completing more user testing on multiple devices before the beta release of the plugin. More features are currently in the works, including @mentions, favoriting, profile editing, private messages. He plans to release Status App as a free plugin with a commercial version available to include more settings and add additional features. </p>
<p>Check out @modemlooper&#8217;s <a href="http://taptappress.com/news/" target="_blank">TapTapPress blog</a> for more discussions on developing mobile apps for WordPress. If you&#8217;re testing the Status App and can help with reporting any issues, <a href="http://taptappress.com/contact/" target="_blank">get in touch with Ryan</a> and let him know the type of device you&#8217;re using.</p>
<p>I tested Status App last night and found it to be ridiculously simple and enjoyable to use. Additionally, unlike using Twitter, you own your own data when you create your own messaging service. I believe it&#8217;s apps like these that will lead to the ultimate crumbling of the massive social data silos that feed you advertisements and blatantly disregard user privacy. Eventually, users are going to be fed up and will flock to simple private social networks like the kind you can create with Status App. We&#8217;ll be closely following the evolution of this app and will let you know when you can download the free plugin to create your own micro messaging service.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Jan 2014 20:43:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: 30 Beautiful Brewery Websites Built With WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:164:"http://wptavern.com/30-beautiful-brewery-websites-built-with-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=30-beautiful-brewery-websites-built-with-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8099:"<p>While the WordPress community continues to grow and expand every day, so does the craft beer scene. So it only makes sense that a growing number of craft breweries are choosing to build their websites on WordPress. After all, WordPress and craft beer have a lot in common: enthusiasm, loyalty, broad appeal, no shortage of strong opinions and a community of contributors of every stripe. </p>
<p>Craft brewers often share many of the same ideals found in open source culture, including  the cheerful sharing of knowledge, skills, recipes and the strong support of each other&#8217;s work. You might even say that craft brewing culture is the open source version of the beer industry. With that in mind, here are 30 beautiful brewery websites that have been built with WordPress. Pour your favorite local pint, sit back, and enjoy. Cheers!</p>
<h3>Groundswell Brewing Company</h3>
<p><a href="http://groundswellbrew.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/groundswell.png" alt="groundswell" width="1400" height="791" class="aligncenter size-full wp-image-15322" /></a></p>
<h3>The Post Brewing Co.</h3>
<p><a href="http://www.postbrewing.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/thepost.png" alt="thepost" width="1280" height="800" class="aligncenter size-full wp-image-15327" /></a></p>
<h3>Canal Park Brewing Company</h3>
<p><a href="http://canalparkbrewery.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/canalpark.png" alt="canalpark" width="1400" height="884" class="aligncenter size-full wp-image-15332" /></a></p>
<h3>Brewsters Brewing Company</h3>
<p><a href="http://brewsters.ca/"><img src="http://wptavern.com/wp-content/uploads/2014/01/brewsters.png" alt="brewsters" width="1400" height="836" class="aligncenter size-full wp-image-15330" /></a></p>
<h3>Camden Town Brewery</h3>
<p><a href="http://www.camdentownbrewery.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/camdentownbrewery.png" alt="camdentownbrewery" width="1400" height="804" class="aligncenter size-full wp-image-15333" /></a></p>
<h3>Cook Ale Works</h3>
<p><a href="http://coopaleworks.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/coop.png" alt="coop" width="1400" height="759" class="aligncenter size-full wp-image-15335" /></a></p>
<h3>Rogness Brewing Company</h3>
<p><a href="http://rognessbrewing.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/rogness.png" alt="rogness" width="1400" height="703" class="aligncenter size-full wp-image-15337" /></a></p>
<h3>Driftwood Brewery</h3>
<p><a href="http://driftwoodbeer.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/driftwood.png" alt="driftwood" width="1227" height="856" class="aligncenter size-full wp-image-15338" /></a></p>
<h3>Brouwerij ‘t IJ</h3>
<p><a href="http://www.brouwerijhetij.nl/"><img src="http://wptavern.com/wp-content/uploads/2014/01/Brouwerij-‘t-IJ.png" alt="Brouwerij ‘t IJ" width="1500" height="740" class="aligncenter size-full wp-image-15357" /></a></p>
<h3>Carolina Brewery</h3>
<p><a href="http://carolinabrewery.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/carolinabrewery.png" alt="carolinabrewery" width="1400" height="943" class="aligncenter size-full wp-image-15341" /></a></p>
<h3>Matso&#8217;s Broome Brewery</h3>
<p><a href="http://www.matsos.com.au/"><img src="http://wptavern.com/wp-content/uploads/2014/01/matsos.png" alt="matsos" width="1400" height="915" class="aligncenter size-full wp-image-15343" /></a></p>
<h3>Hargreaves Hill Brewing Company</h3>
<p><a href="http://www.hargreaveshill.com.au/"><img src="http://wptavern.com/wp-content/uploads/2014/01/hargreaves.jpg" alt="hargreaves" width="1440" height="822" class="aligncenter size-full wp-image-15378" /></a></p>
<h3>Prairie Artisan Ales</h3>
<p><a href="http://prairieales.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/prairie.png" alt="prairie" width="1500" height="930" class="aligncenter size-full wp-image-15345" /></a></p>
<h3>U Fleků</h3>
<p><a href="http://ufleku.cz/"><img src="http://wptavern.com/wp-content/uploads/2014/01/UFleku.jpg" alt="UFleku" width="1312" height="826" class="aligncenter size-full wp-image-15372" /></a></p>
<h3>Widmer Brothers</h3>
<p><a href="http://widmerbrothers.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/widmer.png" alt="widmer" width="1500" height="820" class="aligncenter size-full wp-image-15347" /></a></p>
<h3>Gigantic Brewing Company</h3>
<p><a href="http://giganticbrewing.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/gigantic.png" alt="gigantic" width="1500" height="817" class="aligncenter size-full wp-image-15349" /></a></p>
<h3>Mikkeller</h3>
<p><a href="http://mikkeller.dk/"><img src="http://wptavern.com/wp-content/uploads/2014/01/mikkeller.jpg" alt="mikkeller" width="1322" height="830" class="aligncenter size-full wp-image-15375" /></a></p>
<h3>Bonfire Brewing</h3>
<p><a href="http://bonfirebrewing.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/bonfire-brewing.png" alt="bonfire-brewing" width="1500" height="899" class="aligncenter size-full wp-image-15351" /></a></p>
<h3>Monkey Paw Brewing</h3>
<p><a href="http://monkeypawbrewing.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/monkeypaw.png" alt="monkeypaw" width="1060" height="878" class="aligncenter size-full wp-image-15353" /></a></p>
<h3>Yowie Beer</h3>
<p><a href="http://yowiebeer.com.au/"><img src="http://wptavern.com/wp-content/uploads/2014/01/yowie.jpg" alt="yowie" width="1326" height="918" class="aligncenter size-full wp-image-15382" /></a></p>
<h3>Thorn St. Brewery</h3>
<p><a href="http://thornstreetbrew.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/thornstbrewery.png" alt="thornstbrewery" width="1500" height="983" class="aligncenter size-full wp-image-15355" /></a></p>
<h3>Brouwerij De 7 Deugden</h3>
<p><a href="http://www.de7deugden.nl/"><img src="http://wptavern.com/wp-content/uploads/2014/01/Brouwerij-De-7-Deugden.png" alt="Brouwerij De 7 Deugden" width="1500" height="1036" class="aligncenter size-full wp-image-15359" /></a></p>
<h3>Redemption Brewing Co.</h3>
<p><a href="http://www.redemptionbrewing.co.uk/"><img src="http://wptavern.com/wp-content/uploads/2014/01/redemption.jpg" alt="redemption" width="1054" height="896" class="aligncenter size-full wp-image-15364" /></a></p>
<h3>Oskar Blue Brewery</h3>
<p><a href="http://oskarblues.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/oskar-blues.jpg" alt="oskar-blues" width="1100" height="880" class="aligncenter size-full wp-image-15365" /></a></p>
<h3>Hops and Grains</h3>
<p><a href="http://www.hopsandgrain.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/hopsandgrains.jpg" alt="hopsandgrains" width="1036" height="798" class="aligncenter size-full wp-image-15367" /></a></p>
<h3>Captain Lawrence Brewing Company</h3>
<p><a href="http://www.captainlawrencebrewing.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/captainlawrence.jpg" alt="captainlawrence" width="1098" height="830" class="aligncenter size-full wp-image-15368" /></a></p>
<h3>Red Hook</h3>
<p><a href="http://redhook.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/redhook.jpg" alt="redhook" width="1134" height="824" class="aligncenter size-full wp-image-15370" /></a></p>
<h3>Manchester Marble Beers</h3>
<p><a href="http://www.marblebeers.com/"><img src="http://wptavern.com/wp-content/uploads/2014/01/marble.jpg" alt="marble" width="1026" height="748" class="aligncenter size-full wp-image-15384" /></a></p>
<h3>Dugges Ale &#038; Porterbryggeri</h3>
<p><a href="http://dugges.se/"><img src="http://wptavern.com/wp-content/uploads/2014/01/dugges.jpg" alt="dugges" width="1098" height="680" class="aligncenter size-full wp-image-15376" /></a></p>
<h3>Hawthorne Brewing Co.</h3>
<p><a href="http://hawthornbrewing.com.au/"><img src="http://wptavern.com/wp-content/uploads/2014/01/hawthorne.jpg" alt="hawthorne" width="1080" height="914" class="aligncenter size-full wp-image-15380" /></a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Jan 2014 18:47:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress.tv: Marko Heijnen: Building Plugins Like A Pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=30007";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.tv/2014/01/24/marko-heijnen-building-plugins-like-a-pro/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:661:"<div id="v-GucbrQSP-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/30007/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/30007/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=30007&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/01/24/marko-heijnen-building-plugins-like-a-pro/"><img alt="Marko Heijnen: Building Plugins Like A Pro" src="http://videos.videopress.com/GucbrQSP/video-abf855d2e0_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Jan 2014 16:06:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WordPress.tv: Luke Oatham: GovIntranet WordPress Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=30013";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.tv/2014/01/24/luke-oatham-govintranet-wordpress-theme/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:657:"<div id="v-UQ0KX6xM-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/30013/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/30013/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=30013&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/01/24/luke-oatham-govintranet-wordpress-theme/"><img alt="Luke Oatham: GovIntranet WordPress Theme" src="http://videos.videopress.com/UQ0KX6xM/video-240a36afb3_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Jan 2014 13:25:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: PressCastle Aims to Put Every WordPress Theme in One Place";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15264";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:180:"http://wptavern.com/presscastle-aims-to-put-every-wordpress-theme-in-one-place?utm_source=rss&utm_medium=rss&utm_campaign=presscastle-aims-to-put-every-wordpress-theme-in-one-place";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3057:"<p><a href="http://presscastle.com/" target="_blank">PressCastle</a> launched this month with an ambitious goal: to put every WordPress theme in one place. The site currently has more than 13,000 themes that are categorized and searchable. The themes were collected from more than 250 sites and represent 400+ theme authors.</p>
<p>If you visit the <a href="http://presscastle.com/themes/" target="_blank">Themes section</a> of the site you can filter themes based on price, layout, framework and genre with subcategories for each. PressCastle is in the process of adding filters to the themes to specify compatibility with multisite, BuddyPress, bbPress, Jigoshop and other commonly used plugins.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/presscastle-themes.jpg" rel="prettyphoto[15264]"><img src="http://wptavern.com/wp-content/uploads/2014/01/presscastle-themes.jpg" alt="presscastle-themes" width="946" height="491" class="aligncenter size-full wp-image-15298" /></a></p>
<p>The site is using affiliate links on the themes to help fund the efforts required for indexing this massive library. The launch post claims that they now have the largest and most up to date index of WordPress themes on the web. They plan to update it with new theme releases and remove discontinued items along the way.</p>
<p>I entered a few common search terms related to WordPress themes and found that the search engine was quite accurate in returning relevant information. Although, from a consumer standpoint, I have a difficult time connecting with the whole medieval castle theme they&#8217;ve got running, I can see the utility in the indexing and searching capabilities PressCastle provides. But does it solve a real problem?</p>
<h3>Are WordPress Theme Indexing Sites a Fad?</h3>
<p>The fact that themes are scattered throughout hundreds of websites can make it difficult to locate one that you want to use. PressCastle is trying to provide a solution for this. <a href="http://wptavern.com/theme-friendly-helps-you-find-the-perfect-wordpress-theme" target="_blank">Theme Friendly</a> is another site that recently launched with a similar goal of helping users find the perfect WordPress theme. While Theme Friendly has a different angle in that it provides reviews on the quality of themes, the work is similarly powered by affiliate links. Only time will tell whether affiliate commissions will be adequate compensation for the amount of effort required to keep these indexes current.</p>
<p>Theme indexing sites seem to be popping up quite frequently these days, all of them vying to capitalize on the high demand for WordPress themes and the difficulty users have when searching. The question remains &#8211; will any of these sites actually take off and gain a following? In many cases their efforts seem to be duplicating the results a user might find with a reasonably formed search engine query. So I put the question to you: <strong>Are you likely to visit a WordPress theme indexing site when shopping for your next theme?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Jan 2014 00:09:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"Alex King: Owning Your Online Identity";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=19292";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://crowdfavorite.com/blog/2014/01/own-your-online-identity/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1470:"<div>
	<img width="160" height="120" src="http://alexking.org/wp-content/uploads/2014/01/Screen-Shot-2014-01-23-at-2.39.30-PM-160x120.png" class="attachment-thumb-img wp-post-image" alt="Post at the Crowd Favorite blog" /></div>
<p>I&#8217;ve put up a post on the <a href="http://crowdfavorite.com/blog/">Crowd Favorite blog</a> about how I use WordPress and the <a href="http://crowdfavorite.com/favepersonal/">FavePersonal</a> theme (free!) to own my online identity, while still participating with my friends on Facebook and Twitter.</p>
<p>I love how I have (on my own site) a history of the social reactions to <a href="http://alexking.org/blog/2013/04/24/capsule-the-developers-code-journal">posts like this</a>. Here&#8217;s a <a href="http://alexking.org/blog/2014/01/09/ipad-use-and-productivity">more casual example</a>; where the social reactions really add to the overall story.</p>
<p>I think owning your online identity is hugely important &#8211; don&#8217;t outsource it to some 3rd-party service. But there&#8217;s no reason not to take advantage of the benefits of those services. I want to have my cake and eat it to &#8211; and I believe I&#8217;m doing just that.</p>
<p class="threads-post-notice">This post is part of the project: <a href="http://alexking.org/project/favepersonal">FavePersonal</a>. View the project timeline for more context on this post.</p>
<p><a href="http://alexking.org/blog/2014/01/23/owning-your-online-identity">#</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 21:41:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: WordPress 3.8.1 Released: Fixes Twitter oEmbed Issues";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13644";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/wordpress-3-8-1-released-fixes-twitter-oembed-issues?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-3-8-1-released-fixes-twitter-oembed-issues";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2429:"<p>WordPress 3.8.1 was <a href="http://wordpress.org/news/2014/01/wordpress-3-8-1/" target="_blank">released</a> today with more than 30 tickets resolved for this <a href="https://core.trac.wordpress.org/query?milestone=3.8.1" target="_blank">milestone</a>. Automatic background updates will be gradually rolled out over the next 24 hours.</p>
<p>One of the most notable fixes was switching Twitter oEmbed to SSL. Twitter changed its API, which broke Twitter oEmbed links across all WordPress installations. If you&#8217;ve got a lot of content with embedded tweets, then upgrading to WordPress 3.8.1 should be a high priority for you. </p>
<p>Additionally, WordPress 3.8.1 addresses some issues with taxonomy queries in WP_Query, general fixes for the newly designed admin areas and resolves a strange bug with &#8220;dead zones&#8221; on submit buttons.</p>
<h3>An Impressive Success Rate For Automatic Updates</h3>
<p>Skeptics of WordPress 3.7&#8242;s automatic updates feature may be interested in looking at the results so far. The success rate for automatic updates with WordPress 3.8 was astonishing, given that it was a major release, with many major changes. Andrew Nacin <a href="http://make.wordpress.org/core/2013/12/18/automatic-updates-for-3-8-started-to-flow-early/" target="_blank">cites</a> the stats for critical failures:</p>
<blockquote><p>Success rate is around 99.78 percent of about 15,000 updates. That’s a bit lower than 3.7.1, which was 99.988 percent for about a million updates. This is to be expected; for example, far more files were changed.</p></blockquote>
<p>When referring to critical failures, Nacin clarifies that these are not disaster scenarios, as the term might seem to indicate. &#8220;<strong>Remember that a critical failure (what these numbers are calculating) only means &#8216;we started to copy files and failed to verify we copied all of them&#8217;</strong>,&#8221; he clarified. &#8220;It doesn&#8217;t mean the site crashed and burned.&#8221; </p>
<p>These stats are good news for any WordPress admin who has been hesitant to have automatic background updates turned on for minor releases. If you previously had background updates turned off, now might be a good time to consider <a href="http://wptavern.com/how-to-configure-automatic-core-updates-for-wordpress-3-7" target="_blank">re-configuring your settings</a> to include automatic core updates for minor releases. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 21:24:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"Dev Blog: WordPress 3.8.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3063";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/01/wordpress-3-8-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3834:"<p>After six weeks and more than <a href="http://wordpress.org/download/counter/">9.3 million downloads</a> of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available.</p>
<p>Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query was resolved. And if you&#8217;ve been frustrated by submit buttons that won&#8217;t do anything when you click on them (or thought you were going crazy, like some of us), we&#8217;ve found and fixed this &#8220;dead zone&#8221; on submit buttons.</p>
<p>It also contains a fix for <strong>embedding tweets</strong> (by placing the URL to the tweet on its own line), which was broken due to a recent Twitter API change. (For more on Embeds, see <a href="http://codex.wordpress.org/Embeds">the Codex</a>.)</p>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.8.1">list of tickets</a> and <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=27018&stop_rev=26862">the changelog</a>. There&#8217;s also a <a href="http://make.wordpress.org/core/2014/01/22/wordpress-3-8-1-release-candidate/">detailed summary</a> for developers on the development blog.</p>
<p>If you are one of the millions already running WordPress 3.8, we will start rolling out automatic background updates for WordPress 3.8.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.8.1:</p>
<p><a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://wordpress.org/news/feed/">José Pino</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p><em>WordPress three eight one<br />
We heard you didn&#8217;t like bugs<br />
So we took them out</em></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: Behind The Scenes In The WordPress Plugin Directory With Mika Epstein";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15237";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:202:"http://wptavern.com/behind-the-scenes-in-the-wordpress-plugin-directory-with-mika-epstein?utm_source=rss&utm_medium=rss&utm_campaign=behind-the-scenes-in-the-wordpress-plugin-directory-with-mika-epstein";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:10264:"<p>The <a href="http://wordpress.org/plugins/" target="_blank">WordPress Plugin Directory</a> currently lists more than 29,000 plugins. It&#8217;s the first stop for any WordPress user looking to extend the capabilities of the software. With over 585 million downloads and a massive worldwide user base, it takes a dedicated team to monitor the quality and security of so many extensions.</p>
<p><div id="attachment_15252" class="wp-caption alignright"><a href="http://wptavern.com/wp-content/uploads/2014/01/ipstenu.jpg" rel="prettyphoto[15237]"><img src="http://wptavern.com/wp-content/uploads/2014/01/ipstenu-332x500.jpg" alt="Mika Epstein - photo credit: ma.tt " width="332" height="500" class="size-large wp-image-15252" /></a><p class="wp-caption-text">Mika Epstein &#8211; photo credit: <a href="http://ma.tt/2012/08/wcsf-hack-day/mcm_3384-3/" target="_blank">ma.tt</a></p></div>
<p>I had the opportunity to interview Mika Epstein, better known around the web as &#8220;<a href="https://twitter.com/ipstenu" target="_blank">Ipstenu</a>&#8220;, about her work behind the scenes with the plugin directory. Epstein is part of a team of folks, including Scott Reilly, Pippin Williamson, Otto, and a handful of others, who stand at the door of the repository and review incoming plugins to make sure they meet the <a href="http://wordpress.org/plugins/about/guidelines/" target="_blank">guidelines</a>.</p>
<p>How does someone get involved with reviewing plugins for WordPress? For Mika it was in the vein with something she&#8217;d be doing already. She has a passion for helping plugins play nice with WordPress. </p>
<blockquote><p>Otto reached out to me to join the plugin review team after I started, on my own, scanning the repo using <a href="https://github.com/markjaquith/WordPress-Plugin-Directory-Slurper" target="_blank">Mark Jaquith&#8217;s slurper</a> &#8211; for people who were doing some silly, but easy to mistake, things like jquery. This started after WP upgraded jquery and a lot of plugins and themes broke. I was so annoyed, I started trying to head them off at the pass.</p></blockquote>
<h3>The Plugin Review Process</h3>
<p>Once a plugin developer submits his work to the directory, he or she generally has to wait a little while for it to be approved. Epstein says that they try to get to everyone within seven days but that some weeks are better than others. &#8220;Small plugins are often approved right away, larger can take a while,&#8221; she said. &#8220;On our good days, we can same-day review everyone. How long each review takes is also subjective to the plugin size and complexity. <span class="pullquote alignleft">Many times a delay pops up when we have to figure out what the code was supposed to do because of poor documentation.</span>&#8221;</p>
<p>There&#8217;s a helpful gem in there for aspiring plugin developers submitting to WordPress.org: <strong>The better your documentation is, the faster your plugin is likely to move through the process.</strong></p>
<p>You might be surprised to learn that the plugin review process is not terribly mysterious or complicated. It simply takes a little bit of time. Epstein outlines what&#8217;s involved:</p>
<blockquote><p>We review plugin submissions, and that really means we download the zip, read the code, test it, and approve it or push back for various things. Every single line of code is looked at, and we generally look for things that are &#8216;wrong.&#8217; After a while, they start to jump out at you.</p></blockquote>
<p>This translates into a daily routine for her. <strong>&#8220;I usually spend an hour or two a day just on plugins,&#8221;</strong> Epstein said. &#8220;Minimum&#8217;s an hour, which lets me run a decent triage on people with pending requests and some of the new ones.&#8221; Additionally, there are reports and weird issues that come in that she will funnel to the entire team.</p>
<h4>The Most Common Issues With Plugins</h4>
<p>Believe it or not, the most common reason for a plugin to get rejected is not ultimately due to brazen violations of the guidelines. Epstein says that many plugin authors simply do not reply to emails: &#8220;After 7 days, if the plugin code isn&#8217;t completed, the plugin&#8217;s rejected.&#8221; </p>
<p>Bad plugin names are another reason that she says are grounds for rejection, as well as HTML in the title. &#8220;We auto-reject anyone with &#8216;wordpress&#8217; in the plugin slug (like you can no longer request &#8216;wordpress-fedex-shipping&#8217;) but manually we reject anything with encoded HTML characters in the title (like %d) or the term &#8216;plugin&#8217; (most of the time&#8230; if your plugin is &#8216;network plugin settings&#8217; that&#8217;s okay, but &#8216;rebooter-plugin&#8217; is not).&#8221;</p>
<h3>Why Plugins Get Pulled From the Directory</h3>
<p>You&#8217;ve probably seen it happen a time or two: A plugin is newly listed in the repository and then it suddenly vanishes a day or two later. I asked Mika why it is that a plugins make it through this review process but end up being pulled just a couple days later. She replied:</p>
<blockquote><p>Ouch. So &#8230; we&#8217;re human, right? And SOME plugins are really simple and others are really complex. Just like the dev may miss a security hole in their plugin, we might too. While we do look at every line of code, the problem with this is the same as the problem with all security reviews and that is we look for wrong, and sometimes miss it in the cruft of right.</p></blockquote>
<p>In addition, Epstein said that sometimes WP Tavern or another site will post about a new plugin and then a larger number of people will take a look at it, inspect the code, and uncover something that might have been missed. However, there are some plugin developers out there with bad motives, who knowingly violate the guidelines through what Epstein calls a <strong>&#8220;bait-and-switch&#8221;</strong>:</p>
<blockquote><p>Someone submits plugin A, we approve it, but they upload plugin B to the repository. That&#8217;s something a lot of spammers like to do. Sometimes people upload the wrong version of the code by accident, other times they intentionally go back and add in code we told them to remove. We try to mitigate this by filtering emails (I actually get an email for every single plugin check in) and scan for known issues, but it&#8217;s never-ending. Right now there are 20 security reports to go through.</p></blockquote>
<p>The review team is constantly improving its checks, which help them scan for the most basic and unintentional violations. Unfortuantely, there is no way to scan for bait-and-switch techniques, which require someone to go back and manually check for violations after the plugin is already sent to the repository.</p>
<h3>Advice For Managing Orphaned Plugins</h3>
<p>One of the problems plaguing the plugin directory is plugins that have been abandoned or are no longer maintained. Given Epstein&#8217;s close involvement with support, I asked her what the best course of action is for a plugin author who no longer wishes to update his/her plugin on WordPress.org. Would it be best to remove it? If he/she can&#8217;t find someone to adopt the plugin, is it better to leave the plugin there as a starting point for someone else or to remove it entirely to prevent frustrating users? Ultimately, the decision falls to the plugin author, but Epstein offered some practical tips:</p>
<ul>
<li>If a plugin author wants to no longer support or update a plugin, I suggest they make DARN SURE that&#8217;s documented in their readme!</li>
<li>If they want to leave it open for someone else to adopt that&#8217;s great, just make sure to put up a way to be contacted.</li>
<li>If they want to close it forever and ever, that&#8217;s okay too, just email plugins AT wordpress.org and link to the plugin.</li>
</ul>
<p>&#8220;Which is better? Depends on the plugin,&#8221; she said. &#8220;Like <a href="http://wordpress.org/plugins/twitter-blackbird-pie/" target="_blank">Blackbird Pie</a>, the plugin to embed Twitter, was something I would feel was essential not to close &#8230; until we added in Twitter oEmbeds. Now it&#8217;s not really as needed and may not even work. Would I extend that or close it? Hard to say, even if it was mine.&#8221;</p>
<h3>The Readme.txt File is Key to Improving User Experience in the Plugin Directory</h3>
<p>When searching the directory, it&#8217;s not uncommon to find plugins with what seems to be only a title. Many plugins are missing vital details (or any details), screenshots, FAQs and basic information about what the plugin does. I asked Epstein what can we do to encourage plugin authors to provide more information. She has a few solid tips:</p>
<blockquote><p>I hate bad readmes with a passion. I try to push people to make better ones, pointing out that if the readme (which makes your wporg repository page) isn&#8217;t descriptive and helpful, no one will use your plugin and you&#8217;ll waste time answering easy questions. But we only force them to have a readme at submission if they&#8217;re a service (that is they&#8217;re calling other servers). Screenshots aren&#8217;t always needed, but a good and descriptive readme would save everyone a lot of pain. Short of letting me actually chase after people with a baseball bat, I don&#8217;t know if we&#8217;ll ever get to a place where everyone&#8217;s doing that.</p></blockquote>
<p>Unfortunately, the plugin review team cannot require better readme.txt files, but her advice would be good to take to heart if you are a plugin developer reading this. Don&#8217;t leave people in the dark about what your plugin does if you want anyone to use it.</p>
<p>Now that you know a little bit more about what the plugin review team has to contend with, aren&#8217;t you grateful for everything they do on WordPress.org? Many thanks to Mika Epstein and the rest of the team for their daily work on the <a href="http://wordpress.org/plugins/" target="_blank">WordPress Plugin Directory</a>. Without them, the directory would be a wasteland, overrun with spam and security threats. Because of their dedication, WordPress.org remains one of the safest places to look for extensions.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:31:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WPTavern: Tickets On Sale For WordCamp Dayton, Ohio";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15246";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:144:"http://wptavern.com/tickets-on-sale-for-wordcamp-dayton-ohio?utm_source=rss&utm_medium=rss&utm_campaign=tickets-on-sale-for-wordcamp-dayton-ohio";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1975:"<p><a href="http://wptavern.com/wp-content/uploads/2013/12/WordCampDayton2014Logo.jpg" rel="prettyphoto[15246]"><img src="http://wptavern.com/wp-content/uploads/2013/12/WordCampDayton2014Logo.jpg" alt="WordCamp Dayton 2014" width="177" height="226" class="alignright size-full wp-image-12640" /></a> Six weeks from now between March 7th and 8th, <a href="http://2014.dayton.wordcamp.org/" title="http://2014.dayton.wordcamp.org/">WordCamp Dayton, Ohio</a> will be underway. This is the first WordCamp to take place in the Dayton area and is <a href="http://central.wordcamp.org/schedule/" title="http://central.wordcamp.org/schedule/">one of three scheduled</a> in the state of Ohio. Sessions range from <a href="http://2014.dayton.wordcamp.org/session/podcasting-for-wordpress/" title="http://2014.dayton.wordcamp.org/session/podcasting-for-wordpress/">Podcasting for WordPress</a> to <a href="http://2014.dayton.wordcamp.org/session/wordpress-version-control/" title="http://2014.dayton.wordcamp.org/session/wordpress-version-control/">WordPress Version control</a>. There are three tracks of sessions available for the publisher, power user, and developer. To see a full list of speakers and their sessions, check out <a href="http://2014.dayton.wordcamp.org/schedule/" title="http://2014.dayton.wordcamp.org/schedule/">the event schedule</a>. </p>
<p><a href="http://2014.dayton.wordcamp.org/tickets/" title="http://2014.dayton.wordcamp.org/tickets/">Tickets for the event</a> are on sale and cost <strong>$40.00</strong> for general admission. If you&#8217;re a freelance developer, there is a specific package just for you that will get your name, website, and Twitter handle published on the <a href="http://2014.dayton.wordcamp.org/call-for-sponsors/" title="http://2014.dayton.wordcamp.org/call-for-sponsors/">WordCamp Dayton sponsors page</a>. I&#8217;ll be in attendance at this years event. If you&#8217;re going, let me know in the comments so we can meetup.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 18:17:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Matt: The Four Freedoms";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43469";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:35:"http://ma.tt/2014/01/four-freedoms/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:12488:"<p>Eleven months before the U.S. declared war on Japan, <a href="http://voicesofdemocracy.umd.edu/fdr-the-four-freedoms-speech-text/">President Franklin D. Roosevelt said</a> &#8220;As men do not live by bread alone, they do not fight by armaments alone.&#8221; He articulated four fundamental freedoms that everyone in the world ought to enjoy:</p>
<ol>
<li>Freedom of speech.</li>
<li>Freedom of worship.</li>
<li>Freedom from want.</li>
<li>Freedom from fear.</li>
</ol>
<p>Fast forward 72 years: technology has advanced at dizzying rates and permeated every aspect of our lives, from <a title="Too much technology." href="http://www.theatlantic.com/health/archive/2012/03/the-most-scientific-birth-is-often-the-least-technological-birth/254420/">how we are born</a> to <a title="Still too much technology." href="http://www.newyorker.com/reporting/2007/04/30/070430fa_fact_gawande">how we die</a> and everything in between. In this co-evolution of society and technology, what it means to be truly &#8220;free&#8221; is no longer about just the country we live in, or even its laws, but is shaped by the products we live <em>on</em>.</p>
<p>As <a title="Don\'t you wish Marc blogged more?" href="http://online.wsj.com/news/articles/SB10001424053111903480904576512250915629460">Marc Andreessen says, software is eating the world</a>. It’s a creative gale of destruction that irreversibly changes every industry it touches, and if you don&#8217;t control the software, the software controls you. It mediates how and with whom you communicate, what news you see, and what other software you&#8217;re able to run. It <a title="Long, but good, read." href="http://edge.org/responses/how-is-the-internet-changing-the-way-you-think">influences</a> the <a href="http://www.theatlantic.com/magazine/archive/2008/07/is-google-making-us-stupid/306868/">very way your brain works</a>, as you process the creative gale of <em>distraction</em> that interrupts us all hundreds of times each day. With <a href="http://www.nirandfar.com/2012/10/escape.html">every ping</a>, software burrows deeper into our lives.</p>
<p>In the early nineties, a prescient hacker named <a title="Read about the parrots." href="http://stallman.org/">Richard Stallman</a> — working at MIT, where today&#8217;s future had already happened — recognized this shift. He <a href="https://www.gnu.org/philosophy/free-sw.html">proposed a set of four freedoms</a> that were fundamental for software in an enlightened, tech-dependent society.</p>
<ol start="0">
<li>The freedom to run the program, for any purpose.</li>
<li>The freedom to study how the program works, and change it so it does your computing as you wish.</li>
<li>The freedom to redistribute copies so you can help your neighbor.</li>
<li>The freedom to distribute copies of your modified versions, giving the community a chance to benefit from your changes.</li>
</ol>
<p>(Aside: I originally thought Stallman <a href="http://en.wikipedia.org/wiki/Zero-based_numbering">started counting with zero instead of one</a> because he&#8217;s a geek. He is, but that wasn&#8217;t the reason. Freedoms one, two, and three came first, but later he wanted to add something to supercede all of them. So: freedom zero. The geekness is a happy accident.)</p>
<p>This is our Bill of Rights. Stallman called it <a title="Don\'t call it open source." href="https://www.gnu.org/philosophy/free-sw.html">Free Software</a>. The &#8220;free&#8221; doesn&#8217;t have to do with price, as you’re still free to charge for your software, but with freedom to create. Or as we geeks often say: not free as in beer, <a href="http://en.wikipedia.org/wiki/Freedom_of_speech_in_the_United_States">free as in speech</a>.</p>
<p>People are scared of free software, and I understand why. You&#8217;re taking the <a title="Industries with low IP protection are more creative and generate more sales." href="http://intenseminimalism.com/2010/creativity-in-a-copyright-less-world/">most valuable thing</a> you have, <a title="Old-school theme." href="http://sob.apotheon.org/?p=1519">your intellectual property</a>, and granting the freedom you enjoy as a creator to anyone who downloads your work. It&#8217;s terrifying, actually. It’s releasing your ideas, and letting anyone build on them — in a way that might be better than your own work. It’s releasing your traditional understanding of ownership, and your fear of being out-developed.</p>
<p>The most experienced entrepreneurs can cling to the concept that your <a href="http://www.paulgraham.com/ideas.html">idea is something precious that must be protected from the world</a>, and meted out in a controlled way. Lots of us hang on to the assumption that scarcity creates a proprietary advantage. It’s how many non-tech markets work.</p>
<p>Open source abdicates your flexibility as a developer to better serve the people who actually use your products. You can see that as a constraint&#8230; or you can see it as a door to iteration, innovation, and constant progress.</p>
<p>I&#8217;ve spent a third of my life building software based on Stallman’s four freedoms, and I&#8217;ve been astonished by the results. <a href="http://wordpress.org/">WordPress</a> wouldn’t be here if it weren’t for those freedoms, and it couldn’t have evolved the way it has.</p>
<p>WordPress was based on a program called <a title="The header is still classic." href="http://cafelog.com/">B2/cafelog</a> that predated it by two years. I was using B2 because it had freedoms 0 and 1: I could use it for whatever I wanted, including my zero-budget personal blog, and the source code was open. It was elegant and easy to understand, and anyone could tweak it.</p>
<p>B2 was ultimately <a title="This post is where WordPress started." href="http://ma.tt/2003/01/the-blogging-software-dilemma/">abandoned</a> by its creator. If I’d been using it under a proprietary license, that would have been the end — for me, and all its other users. But because we had freedoms 2 and 3, Mike Little and I were able to use the software as a foundation, giving us a two-year headstart over building something from scratch, and realize our own vision of what blogging could be.</p>
<p>We were just consumers of the software, volunteers in the forums, and occasional contributors to the codebase, but because (of the GPL) we had the freedom to build on B2, we were able to continue development as if it had been our own creation.</p>
<p>Ten years later, those freedoms are still embedded in every copy of WordPress downloaded, including the <a href="http://wordpress.org/download/counter/">9.2 million downloaded</a> in the past month or so since our <a href="http://wordpress.org/news/2013/12/parker/">3.8 release</a>.</p>
<p>I believe that software, and in fact entire companies, should be run in a way that assumes that the sum of the talent of people outside your walls is greater than the sum of the few you have inside. None of us are as smart as all of us. Given the right environment — one that leverages the marginal cost of distributing software and ideas — independent actors can work toward something that benefits them, while also increasing the capability of the entire community.</p>
<p>This is where open source gets really interesting: it&#8217;s not just about the <a href="http://www.gnu.org/licenses/license-list.html">legal wonkery around software licensing</a>, but what effect open sourced software has on people using it. In the proprietary world, those people are typically called &#8220;users,&#8221; a strange term that connotes dependence and addiction. In the open source world, they’re more rightly called a community.</p>
<p>The core features of WordPress aren’t <a href="http://www.amazon.com/Rocket-Surgery-Made-Easy-Do-It-Yourself/dp/0321657292">rocket surgery</a>. A handful of smart people in a room for a year could create a reasonable approximation of the software, and undoubtably improve some things — I see other startups do this <a title="Someday they will build a museum to document your former competitors." href="http://www.crunchbase.com/tag/cms">three or four times a year</a>.</p>
<p>What they miss is that WordPress isn&#8217;t a checklist of features. It&#8217;s over <a title="I have about 20 of them." href="http://wordpress.org/plugins/">29,000 plugins</a> created by the community, from the in-demand things like SEO to niche features like <a title="I can\'t make these things up." href="http://wordpress.org/plugins/hundstall-404/">using your 404 page to help adopt homeless dogs in Sweden</a>. Every WordPress site looks different, because of the thousands of themes available. Instead of one event to outdo, there are more than <a title="Check one out if you haven\'t been yet, amazing groups of folks." href="http://central.wordcamp.org/">70 volunteer-organized WordCamps on six continents</a> (and there’ll be more in 2014).</p>
<p>WordPress marketing has nothing to do with its website or <a title="Fight the Fauxgo." href="http://wordpress.org/about/logos/">logo</a>, it&#8217;s the <a href="http://wordpress.tv/2013/07/29/matt-mullenweg-state-of-the-word-2013/">tens of thousands of people who make a living building WordPress sites</a> and receive so much value from it that they proselytize to anyone that will listen, spreading the flame one site at a time. It works — as of December 2013, 21% of websites are powered by WordPress. One-fifth of the web is built with a tool that anyone can use, change, or improve, whenever and however they want (even more when you count other open source projects, like Drupal).</p>
<p>This approach to building isn&#8217;t an abdication of developers’ and designers’ responsibility to build beautiful, functional software. Design and forethought are <em>more important</em> than ever when every change sends millions of independent actors down a new path. Changes to WordPress have consequences today, tomorrow, five years, and ten years down the road, but the passion and talent of the community helps ensure that it always moves forward in a positive way.</p>
<p>The four freedoms don’t limit us as creators — they open possibilities for us as creators <em>and</em> consumers. When you apply them to software, you get Linux, Webkit/Chrome, and WordPress. When you apply them to medicine, you get the <a href="http://www.opengenomicsengine.org/">Open Genomics Engine</a>, which is accelerating cancer research and bringing us closer to personalized treatment. When you apply them to companies, you get radically geographically distributed, results-based organizations like <a href="http://automattic.com/">Automattic</a>. When you apply them to events you get <a href="http://www.ted.com/tedx">TEDx</a>, <a title="Which I accidentally ended up helping get started." href="http://en.wikipedia.org/wiki/BarCamp">Barcamp</a>, and <a href="http://wordcamp.org/">WordCamp</a>. When you apply them to knowledge, you get <a title="Where people argue you for deletion." href="http://wikipedia.org/">Wikipedia</a>.</p>
<p><a href="http://www.williamgibsonbooks.com/">William Gibson</a> is attributed with saying &#8220;The future is already here — it&#8217;s just not very evenly distributed.&#8221; The world is changing faster than any one person or organization can keep up with it. Closed off, proprietary development creates closed off, proprietary products that won’t keep pace in the long run. Open source provides another path — one that’s open to everyone, and can take advantage of the skills and talents of anyone in the world to build software that helps everyone.</p>
<p>As <a href="http://en.wikipedia.org/wiki/Joy\'s_Law_(management)">Bill Joy said</a>, &#8220;No matter who you are, most of the smartest people work for someone else.&#8221; Good ideas aren’t the sole province of groups of people behind high walls, and software shouldn’t be either.</p>
<p><em>This was adapted from a talk I gave at <a title="Was great fun, hope they do it again next year." href="http://www.lifeisbeautifulfestival.com/">the Life is Beautiful festival</a> in <a title="One of the more interesting scenes around right now." href="http://downtownproject.com/">Downtown Las Vegas</a>. Thanks to <a href="http://kingofstates.com/">Michelle</a>, <a href="http://stratechery.com/">Ben</a>, <a href="http://intenseminimalism.com/">Davide</a>, and <a href="http://paulmaiorana.com/notes/">Paul</a> for help with this.</em></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 17:02:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress.tv: Konstantin Kovshenin: Templating WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=30011";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.tv/2014/01/23/konstantin-kovshenin-templating-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:661:"<div id="v-JH7sJM4H-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/30011/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/30011/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=30011&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/01/23/konstantin-kovshenin-templating-wordpress/"><img alt="Konstantin Kovshenin: Templating WordPress" src="http://videos.videopress.com/JH7sJM4H/video-6338ae249d_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 16:03:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WordPress.tv: Joe Hoyle: Setting Up Production Environments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=30003";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wordpress.tv/2014/01/23/joe-hoyle-setting-up-production-environments/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:667:"<div id="v-c5z1cRXz-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/30003/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/30003/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=30003&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/01/23/joe-hoyle-setting-up-production-environments/"><img alt="Joe Hoyle: Setting Up Production Environments" src="http://videos.videopress.com/c5z1cRXz/video-3b5a88069a_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 15:39:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WPTavern: Interview With Jason Schuller Founder Of Press75.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15204";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/interview-with-jason-schuller-founder-of-press75-com?utm_source=rss&utm_medium=rss&utm_campaign=interview-with-jason-schuller-founder-of-press75-com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2067:"<p>The last time I spoke with <a href="http://jason.sc/" title="http://jason.sc/">Jason Schuller</a>, it was 2008 at WordCamp Chicago. He had just launched his commercial theme company <a href="http://press75.com/" title="http://press75.com/">Press75</a>. Since 2008, he&#8217;s launched a number of projects such as ThemeGarden, the first ever WordPress theme marketplace that gave 100% of the sale back to the theme author. Lately, Jason has been experimenting with creating simple publishing systems like Dropplets and Leeflets that focus on streamlining the publishing process. Many of these projects have since shut down.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/ThemeGardenLogo.jpg" rel="prettyphoto[15204]"><img src="http://wptavern.com/wp-content/uploads/2014/01/ThemeGardenLogo.jpg" alt="ThemeGarden Logo" width="458" height="231" class="aligncenter size-full wp-image-15222" /></a></p>
<p>I caught up with Jason Schuller one on one to find out what happened to all of the projects mentioned above, what he&#8217;s been up to the past 6 years and last but not least, find out what he&#8217;s working on in the immediate future. During the interview, we learn some valuable lessons from Jason such as when to ask others for help when a project gets too large for one person to handle. He tells us how he got involved with WordPress theme development and how WordPress became a pivotal moment in his life. </p>
<p>One of the main reasons for conducting this interview is that based on everything I&#8217;ve read from <a href="https://twitter.com/jschuller" title="https://twitter.com/jschuller">his Twitter account</a>, it seemed like he was leaving the WordPress community to pursue other opportunities. Jason told me that although he won&#8217;t be concentrating his efforts on WordPress in the immediate future, he will still attend WordCamps and continue to interact with all of the friends he&#8217;s made throughout the community over the years. I wish Jason the best with his future endeavors and hope you enjoy the interview. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 02:05:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WPTavern: WordPress.org vs. GitHub For Hosting WordPress Plugins and Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13576";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:192:"http://wptavern.com/wordpress-org-vs-github-for-hosting-wordpress-plugins-and-themes?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-org-vs-github-for-hosting-wordpress-plugins-and-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8157:"<p>There are many factors that come into play when deciding where to host your open source WordPress plugin or theme. Who is your target audience? How much support do you want to offer? Is the project open for collaboration? For many developers this choice often comes down to <a href="http://wordpress.org/" target="_blank">WordPress.org</a> vs. <a href="https://github.com/" target="_blank">GitHub</a>. </p>
<p>In the past, hosting with WordPress.org was the only option that would allow developers to push out updates to their plugin or theme via the WordPress admin. The <a href="https://github.com/afragen/github-updater" target="_blank">GitHub Updater</a> plugin, created by Andy Fragen and added to GitHub in July of 2013, makes it possible to ship updates to Github-hosted plugins and themes. This makes it convenient for developers who prefer GitHub to stay within their preferred workflow while continuing to provide updates. Incidentally, this plugin is banned from the WordPress.org repository.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/updater.png" rel="prettyphoto[13576]"><img src="http://wptavern.com/wp-content/uploads/2014/01/updater.png" alt="updater" width="640" height="480" class="aligncenter size-full wp-image-15182" /></a></p>
<p>Of course there are a number of other places that you can host your project, i.e. your own website or another code sharing site. We&#8217;re looking at GitHub vs. WordPress.org for the purposes of this comparison, since the two are among the most popular.</p>
<h2>Advantages of Hosting Your Project on WordPress.org</h2>
<p>By far, one of the best reasons to host a plugin or theme on WordPress.org is the increased exposure that it will offer for your work. Your extension is just a couple clicks away when a user performs a search within the WordPress admin, giving you an audience of millions of potential users. </p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/wporg.jpg" rel="prettyphoto[13576]"><img src="http://wptavern.com/wp-content/uploads/2014/01/wporg.jpg" alt="wporg" width="969" height="399" class="aligncenter size-full wp-image-15207" /></a></p>
<p>A summary of the advantages includes:</p>
<ul>
<li>Maximum exposure: Your extension can be searched for within the WP admin</li>
<li>Built-in trac and support forums</li>
<li>Easily push out updates to users</li>
<li>Ratings, reviews and download stats</li>
<li>Extensions are more trusted due to the WordPress.org review process and guidelines</li>
</ul>
<p>Of course, some of these same &#8220;advantages&#8221; could also be considered disadvantages. For example, if you&#8217;re not willing to offer free support, having your plugin or theme on WordPress.org with such a wide audience may send you a flood of support requests. If you don&#8217;t have the time to provide updates or support, the resulting star ratings and reviews may hurt your extension&#8217;s reputation.</p>
<h4>Disadvantages:</h4>
<p>One of the primary disadvantages of hosting a project on WordPress.org alone is that it can severely limit collaboration. Themes and plugins on WordPress.org are simply not geared for collaborative development. Most developers find it easier to collaborate via Git. Hosting on WordPress.org also requires a basic knowledge of SVN, which is not very popular these days. In summary, the disadvantages include:</p>
<ul>
<li>SVN</li>
<li>Does not encourage collaboration</li>
<li>Possible massive influx of support requests</li>
</ul>
<h2>Advantages of Hosting Your Project on GitHub</h2>
<p>Where a lack of collaboration is probably the strongest disadvantage of hosting on WordPress.org, it&#8217;s also the biggest advantage to hosting your extension on GitHub. The barrier of entry for participation on GitHub is much higher, which significantly lessens the likelihood of you becoming inundated with support requests.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/github-social-coding.jpg" rel="prettyphoto[13576]"><img src="http://wptavern.com/wp-content/uploads/2014/01/github-social-coding.jpg" alt="github-social-coding" width="580" height="230" class="aligncenter size-full wp-image-15213" /></a></p>
<p>Other advantages include:</p>
<ul>
<li>Easy for others to contribute to your project</li>
<li>Built-in wiki and issues queue available</li>
<li>Fewer support requests</li>
<li>Can easily push out updates w/ use of GitHub Updater</li>
<li>Fewer restrictions &#8211; No code review process or extra guidelines for compliance</li>
<li>Traffic analytics &#8211; GitHub recently introduced <a href="https://github.com/blog/1672-introducing-github-traffic-analytics" target="_blank">analytics data</a> for repositories</li>
</ul>
<h4>Disadvantages:</h4>
<ul>
<li>Likely a smaller audience</li>
<li>Will need to bundle the Git Updater with your extension or ask users to install it in order to ship updates</li>
<li>Does not include the same level of user trust as projects hosed on WordPress.org</li>
</ul>
<p>If you don&#8217;t want to have to mess with SVN and don&#8217;t mind losing out on the audience you get hosting on WordPress.org, then hosting your project on GitHub might be a strong option for you. </p>
<h2>The Best of Both Worlds</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/wpvsgithub.jpg" rel="prettyphoto[13576]"><img src="http://wptavern.com/wp-content/uploads/2014/01/wpvsgithub.jpg" alt="wpvsgithub" width="1600" height="594" class="aligncenter size-full wp-image-15216" /></a><br />
There&#8217;s no clear winner in the comparison between hosting on WordPress.org vs. Github. It depends entirely on your workflow and your goals for the extension.  Of course, many projects do a mixture of both, either through maintaining git mirrors or synchronizing via a script. Since every GitHub repository is also a Subversion repository, you can use SVN tools to checkout, branch, and commit to GitHub repositories if you are so inclined.  </p>
<p>Brent Shepherd has a <a href="https://github.com/thenbrent/multisite-user-management/blob/master/deploy.sh" target="_blank">script that will deploy a WordPress plugin from within Git</a> to WordPress.org&#8217;s SVN repository. &#8220;Since running the script for my plugins, I&#8217;ve not suffered the frustrations of minor errors – like having version numbers in the readme.txt &#038; plugin file differ,&#8221; Shepherd said. &#8220;I&#8217;ve lost less time deploying, so I&#8217;ve released more frequently, which means fewer bugs in the wild.&#8221;</p>
<p>Here are some other resources you might want to check out for learning more about working between Git and SVN for WordPress extensions.</p>
<ul>
<li><a href="http://ben.lobaugh.net/blog/90633/creating-a-synchronized-github-fork-of-a-wordpress-org-subversion-plugin-repository" target="_blank">Creating a Synchronized Github Fork of a WordPress.org Subversion Plugin Repository</a> &#8211; Ben Lobaugh</li>
<li><a href="http://teleogistic.net/2011/05/revisiting-git-github-and-the-wordpress-org-plugin-repository/" target="_blank">Revisiting Git, Github, and the WordPress.org Plugin Repository</a> &#8211; Boone Gorges</li>
<li><a href="http://danielbachhuber.com/2012/09/30/git-in-my-subversion/" target="_blank">Git in my Subversion</a> &#8211; Daniel Bachhuber</li>
<li><a href="https://github.com/growthdesigner/WordPress-3.8-Dashboard/issues/3" target="_blank">Syncing Git Repo with WordPress.org</a> &#8211; Daniel Bachhuber</li>
<li><a href="http://thereforei.am/2011/04/21/git-to-svn-automated-wordpress-plugin-deployment/" target="_blank">Git to SVN: Automated WordPress Plugin Deployment</a> &#8211; Brent Shepherd</li>
<li><a href="http://sudarmuthu.com/blog/developing-wordpress-plugins-in-github" target="_blank">Developing WordPress Plugins in Github</a> &#8211; Sudar Muthu</li>
</ul>
<p>Every developer has a different workflow, but there&#8217;s a good option for however you choose to develop and maintain your WordPress plugin or theme. After reviewing the advantages and disadvantages of each, which of these factors is the most important for you when making a decision about where to host an extension? </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jan 2014 23:43:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Matt: Abusing Copyright Laws";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43463";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2014/01/abusing-copyright-laws/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:251:"<p>Paul Sieminski, the general counsel at Automattic (Automattlock), writes for Wired on how <a href="http://www.wired.com/opinion/2014/01/internet-companies-care-fair-use/">Corporations Abusing Copyright Laws Are Ruining the Web for Everyone</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jan 2014 19:21:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WPTavern: CodePen Releases Official WordPress Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15130";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:148:"http://wptavern.com/codepen-releases-official-wordpress-plugin?utm_source=rss&utm_medium=rss&utm_campaign=codepen-releases-official-wordpress-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2629:"<p><a href="http://codepen.io/" target="_blank">CodePen</a> has released an official plugin for embedding pens in WordPress. If you haven&#8217;t yet discovered CodePen, it&#8217;s basically a virtual playground for frontend developers and browsing the site  can be addictive. It&#8217;s a place where you can write HTML, CSS, and JavaScript code in your browser and then see an instant preview. Each collection of snippets you create is saved under your account as a &#8220;pen&#8221; with its live preview directly beneath it. </p>
<p><a href="http://wordpress.org/plugins/codepen-embedded-pen-shortcode/" target="_blank">CodePen Embedded Pens Shortcode</a> is the new plugin that makes it easy to embed any pen on your self-hosted WordPress site. On the CodePen side of things, pens have now been updated to show a WordPress shortcode option when you click on Embed: </p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/embed-pen.jpg" rel="prettyphoto[15130]"><img src="http://wptavern.com/wp-content/uploads/2014/01/embed-pen.jpg" alt="embed-pen" width="944" height="470" class="aligncenter size-full wp-image-15164" /></a></p>
<p>If you&#8217;ve found a pen that inspires you and want to share it on your site, it&#8217;s as easy as copying that shortcode and pasting it into either the visual or text editor in WordPress.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/visual-editor.jpg" rel="prettyphoto[15130]"><img src="http://wptavern.com/wp-content/uploads/2014/01/visual-editor.jpg" alt="visual-editor" width="1138" height="657" class="aligncenter size-full wp-image-15170" /></a></p>
<p>The pen will then be embedded on your site with a tabbed interface for the code and the demo:</p>
<p class="codepen">See the Pen <a href="http://codepen.io/sang_nguyen/pen/pJxms">pJxms</a> by Sang Nguyen (<a href="http://codepen.io/sang_nguyen">@sang_nguyen</a>) on <a href="http://codepen.io">CodePen</a>.</p>
<p><br />
The plugin allows you to set a default theme for the pens. You can also override the default theme via the shortcode attribute. In the future, the CodePen team plans to add a fancy UI for picking pens to embed as well as more control over the HTML output.</p>
<p>CodePen and WordPress working together can be a beautiful thing, especially if you often publish frontend development tutorials with HTML, CSS and/or Javascript. Check out the <a href="http://wordpress.org/plugins/codepen-embedded-pen-shortcode/" target="_blank">CodePen Embedded Pens Shortcode</a> plugin on WordPress.org if you&#8217;re active on CodePen and want to add interactive demos to your WordPress site.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jan 2014 18:11:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WordPress.tv: David Coveney: Can WordPress Save The Publishing Industry?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=29948";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://wordpress.tv/2014/01/22/david-coveney-can-wordpress-save-the-publishing-industry/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:692:"<div id="v-bvUnu4KU-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/29948/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/29948/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=29948&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/01/22/david-coveney-can-wordpress-save-the-publishing-industry/"><img alt="David Coveney: Can WordPress Save The Publishing Industry?" src="http://videos.videopress.com/bvUnu4KU/video-dd5e5adfff_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jan 2014 13:46:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WPTavern: Quick Tip: WordPress Saves Your Widgets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15146";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:140:"http://wptavern.com/quick-tip-wordpress-saves-your-widgets?utm_source=rss&utm_medium=rss&utm_campaign=quick-tip-wordpress-saves-your-widgets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1582:"<p>Have you ever thought about switching your WordPress theme but then hesitated, wondering what might happen to your widgets? Although it may not be obvious, the good news is that WordPress remembers where you previously had your widgets and saves the settings. If you decide to revert back to your previous theme, WordPress will put your widgets back where they were.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/save-widgets.png" rel="prettyphoto[15146]"><img src="http://wptavern.com/wp-content/uploads/2014/01/save-widgets.png" alt="save-widgets" width="1200" height="485" class="aligncenter size-full wp-image-15148" /></a></p>
<p>As you can see in the screenshot, WordPress will even remind you of its widget saving capabilities when you switch to a new theme. </p>
<p>Back in the old days, if you switched your theme and then reverted it, you&#8217;d have to set all your widgets again, one by one. This could be quite a time consuming process if you had several widgetized areas loaded up with multiple widgets. In some cases this discouraged site owners from experimenting with different themes. That&#8217;s why widget saving is one of my favorite features of WordPress. Every time I see this feature reminder, I get a small thrill and I know I can rest easy when changing my theme.</p>
<p>WordPress has actually been saving your widgets since <a href="http://codex.wordpress.org/Version_3.3" target="_blank">version 3.3</a> was released in December of 2011. It was a small feature but it makes a big difference when you&#8217;re testing new themes.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jan 2014 03:21:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Customer Service As A Foundation For Webhosting Companies";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15098";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/customer-service-as-a-foundation-for-webhosting-companies?utm_source=rss&utm_medium=rss&utm_campaign=customer-service-as-a-foundation-for-webhosting-companies";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3755:"<p>Oli Dale of WPLift.com has <a href="http://wplift.com/how-we-work-siteground" title="http://wplift.com/how-we-work-siteground">published a great article</a> that goes behind the scenes of <a href="http://www.siteground.com/" title="http://www.siteground.com/">SiteGround</a>. SiteGround CEO, Tenko Nikolov, answered questions that provide insight into how the company operates on a day to day basis. I was surprised to learn that the company is just a few months younger than WordPress and will be celebrating their 10th anniversary in March. Check out these numbers that represent an average day of customer support:</p>
<blockquote><p>The story behind SiteGround is actually pretty cool, it was founded in 2004 by a group of university friends, with a handful of people working from their uni dorm rooms and has grown to the point where today it has 120 employees and is still growing. SiteGround claims to host over 250,000 domains and process 400 tickets, 150 phone calls and 300 chat requests per day.</p></blockquote>
<h3>Customer Service Used As A Foundation</h3>
<p>When the company started, Tenko mentions the company’s vision was to provide more help to the customers than a standard host did at that time. This is interesting to me because ten years later, WordPress centric hosting companies are being started with the same vision. <a href="http://wptavern.com/wpweekly-episode-118-hey-get-flywheel" title="http://wptavern.com/wpweekly-episode-118-hey-get-flywheel">Flywheel hosting</a> is the most recent example of a host that puts customer service at the forefront of everything they do. At this point, what else is there to differentiate webhosting companies from one another besides customer service? </p>
<p>I&#8217;ve been vocal about the problems I&#8217;ve experienced with webhosting companies <a href="http://wptavern.com/my-performance-woes" title="http://wptavern.com/my-performance-woes">such as HostGator</a>. As I said in a <a href="http://www.inmotionhosting.com/support/webhostingwarriors" title="http://www.inmotionhosting.com/support/webhostingwarriors">recent interview with Web Hosting Warriors</a>, how a webhosting company treats you when a major problem surfaces tells you everything you need to know. </p>
<h3>My Thoughts On Webhosting Companies</h3>
<p>I hope you&#8217;ll tune in and listen as I share my experiences with webhosting companies I&#8217;ve used in the past to host WPTavern.com. I also explain what I as a customer expect out of the company, especially from the customer service stand point. While I initially talk about the history of WPTavern and how I turned it into a successful website, you can fast forward to the <strong>13 minute mark</strong> to hear me discuss my woes with HostGator. </p>
<p><span class="embed-youtube"></span></p>
<h3>What Do You Look For In a Webhost</h3>
<p>In 2010, I shared my list of <a href="http://wptavern.com/14-things-to-consider-when-choosing-a-webhost-for-your-wordpress-powered-site" title="http://wptavern.com/14-things-to-consider-when-choosing-a-webhost-for-your-wordpress-powered-site">fourteen things to consider</a> before choosing a webhost. Many of the things I listed in that post are still relevant today. Having a great experience with a webhosting company is almost like winning the lottery because it’s so rare. Ultimately, it comes down to gathering as much information as possible in order to make an informed decision as to whether a particular webhost is right for you. Price should not be the only determining factor for hosting your site, especially if you plan on taking things seriously. What is the most important factor you look for in a webhost? What influences your decision to go with one particular company over another? </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Jan 2014 23:23:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: tinyCoffee: A Simple, Elegant Donation Plugin for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14948";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/tinycoffee-a-simple-elegant-donation-plugin-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=tinycoffee-a-simple-elegant-donation-plugin-for-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3567:"<p>The WordPress plugin repository hosts dozens of extensions for accepting donations and includes everything from plugins for creating donation forms to plugins that implement full-on CRM solutions for non-profits. But what if you just want to make it easy for supporters to buy you a coffee?</p>
<p><a href="http://wordpress.org/plugins/tinycoffee/" target="_blank">tinyCoffee</a> is a new plugin that caught my eye due to its simple, elegant design. It gives visitors an opportunity to support your work by sending you a beverage of your choice. tinyCoffee features an interactive slider that automatically calculates how many beverages the donation will buy.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/sample-donation-page.png" rel="prettyphoto[14948]"><img src="http://wptavern.com/wp-content/uploads/2014/01/sample-donation-page.png" alt="sample-donation-page" width="804" height="463" class="aligncenter size-full wp-image-15111" /></a></p>
<p>The plugin makes use of the <a href="http://fontawesome.io/" target="_blank">FontAwesome</a> icon font collection to render the beverage image. the tinyCoffee options panel lets you select the icon you&#8217;d like to use, so you&#8217;re not limited to just coffee or beer, or even beverages for that matter. You can select music, money, film, books or anything that fits in with your interests.</p>
<p>tinyCoffee also makes it easy to place your donation request anywhere within your website with the following four options:</p>
<ul>
<li>Template tag (get_coffee()/the_coffee())</li>
<li>Shortcode ([tiny_coffee]/[tiny_coffee])</li>
<li>Sidebar widget</li>
<li>Hash-activated modal screen (domain.com#coffee)</li>
</ul>
<p>So for example, if you wanted to make &#8220;Coffee&#8221; a permanent menu item that launches a modal window or link to it within your content, you would simply add the hash to your link:</p>
<pre>http://example.com#coffee</pre>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/donation-modal.png" rel="prettyphoto[14948]"><img src="http://wptavern.com/wp-content/uploads/2014/01/donation-modal.png" alt="donation-modal" width="1260" height="389" class="aligncenter size-full wp-image-15112" /></a></p>
<p>I tested the modal window on mobile to make sure it was device-friendly and it launched just as smoothly as it would on desktop. I also put the plugin through the paces to see how each placement option worked and was pleasantly surprised to find that the options panel offered far more customization options than detailed in its readme.txt file. You can easily change just about everything related to its display, including:</p>
<ul>
<li>Title and default text outputted by the plugin</li>
<li>Select the FontAwesome icon</li>
<li>Customize the hash</li>
<li>Change the currency template</li>
<li>Set the coffee price</li>
<li>PayPal details, currency, exchange rate</li>
<li>Customize Callback URL settings</li>
</ul>
<p>When it comes to donation plugins, tinyCoffee has most others beat on simplicity, design and configuration options. If you work on an open source project or offer something for free on your website, the last thing you want to spend your time on is testing a bunch of donation plugins. If it isn&#8217;t convenient, you&#8217;re likely to skip it altogether.  But people do like to show their support through donations and tinyCoffee offers a stylish and interactive way to enable them on your site. <a href="http://wordpress.org/plugins/tinycoffee/" target="_blank">Download</a> it for free from the WordPress plugin repository.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Jan 2014 22:18:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WPTavern: WordPress Front-end Editor Plugin Gets Major Updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15070";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/wordpress-front-end-editor-plugin-gets-major-updates?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-front-end-editor-plugin-gets-major-updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3300:"<p>This week the WordPress Front-end Editor team <a href="http://make.wordpress.org/ui/2014/01/20/front-end-editor-meeting-20-january/" target="_blank">posted</a> its progress on the Make WordPress UI development blog. Front-end editing capabilities are being developed as a <a href="http://make.wordpress.org/core/features-as-plugins/" target="_blank">feature plugin</a> and will hopefully be considered for inclusion in the core sometime this year. It currently looks a little something like this:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/frontend-editing.png" rel="prettyphoto[15070]"><img src="http://wptavern.com/wp-content/uploads/2014/01/frontend-editing.png" alt="frontend-editing" width="1280" height="699" class="aligncenter size-full wp-image-15075" /></a></p>
<p>The plugin has improved by leaps and bounds since the last time I took it for a test drive. I&#8217;ve got it active on a site where I try everything that is fun. Despite the fact that it&#8217;s still under heavy development, the plugin is actually quite enjoyable to use. Editing posts on the frontend is lightening fast. </p>
<h3>New Modal Added For Post Meta Boxes</h3>
<p>The most recent update includes the ability to create posts and pages from the frontend. Janneke Van Dorpe, the project lead, has also added more TinyMCE tools and a new modal window to display post meta boxes. This works in a similar way to the media modal.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/custom-fields.png" rel="prettyphoto[15070]"><img src="http://wptavern.com/wp-content/uploads/2014/01/custom-fields.png" alt="custom-fields" width="1280" height="698" class="aligncenter size-full wp-image-15079" /></a></p>
<h3>New Media Features: oEmbed, Gallery Previews and Featured Image Editing</h3>
<p>Just after Christmas the team <a href="http://make.wordpress.org/ui/2013/12/26/front-end-editor-quick-christmas-update/" target="_blank">posted</a> some exciting media updates to the plugin. The WordPress Front-end Editor now automatically embeds links supported by oEmbed. It can also generate a preview of galleries and captions and allows for adding, editing or removing featured images. This video is a quick demonstration of those features in action:</p>
<p><span class="embed-youtube"></span></p>
<p>Since front-end editing is being developed as a feature plugin, you can test it out early if you&#8217;re feeling adventurous. Feel free to use it during its experimental stage and monitor the progress. You can find the <a href="http://wordpress.org/plugins/wp-front-end-editor/" target="_blank">WordPress Front-end Editor</a> plugin in the WordPress plugin repository. There&#8217;s also a <a href="https://github.com/avryl/wp-front-end-editor" target="_blank">github mirror</a> of the plugin. Please be advised that it is still under very active development and probably not suitable for a client site.</p>
<p>If you&#8217;d like to get on board to contribute, check out the <a href="https://plugins.trac.wordpress.org/plugin/wp-front-end-editor" target="_blank">open tickets</a> for the plugin to see what is planned, report a bug or add ideas of your own. Contributors are welcome to join in on the next meeting scheduled for Tuesday, January 28, 2014 at 11:00 UTC-6 in #wordpress-ui.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Jan 2014 18:25:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: Opus: A Free WordPress Blogging Theme With A Big Personality";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15039";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/opus-a-free-wordpress-blogging-theme-with-a-big-personality?utm_source=rss&utm_medium=rss&utm_campaign=opus-a-free-wordpress-blogging-theme-with-a-big-personality";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2980:"<p><a href="http://wordpress.org/themes/opus" target="_blank">Opus</a> is a new WordPress theme for bloggers, now available in the official themes directory. Created by WordPress theme developer Fikri Rasyid, Opus takes a mobile first approach to responsive design and features a fluid layout. When he set out to create Opus, Rasyid wanted the theme to provide a great reading experience on any device. He also wanted it to have personality.</p>
<p>Inspired by the <a href="http://designmodo.com/square-free/" target="_blank">Square UI Design Kit</a>, Rasyid created Opus to incorporate a similar flat design with big fonts and spacious elements. Opus makes use of the popular <a href="http://www.google.com/fonts/specimen/Open+Sans" target="_blank">Open Sans</a> font.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/opus.png" rel="prettyphoto[15039]"><img src="http://wptavern.com/wp-content/uploads/2014/01/opus.png" alt="opus" width="600" height="450" class="aligncenter size-full wp-image-15041" /></a></p>
<h3>A Post Editor to Match the Frontend</h3>
<p>One unique feature of the theme is that the developer has added styles to make the post editing experience match the frontend as much as possible when the visual editor is in use.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/post-editor.png" rel="prettyphoto[15039]"><img src="http://wptavern.com/wp-content/uploads/2014/01/post-editor.png" alt="post-editor" width="520" height="365" class="aligncenter size-full wp-image-15045" /></a></p>
<h3>The Personality Factor</h3>
<p>The main visual feature of this theme is the big header image on the homepage, which is intended for users to customize. Opus includes support for WordPress&#8217; native custom header and you can easily change the theme&#8217;s colors via the customizer as well.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/customizer.jpg" rel="prettyphoto[15039]"><img src="http://wptavern.com/wp-content/uploads/2014/01/customizer.jpg" alt="customizer" width="1046" height="512" class="aligncenter size-full wp-image-15051" /></a></p>
<p>Check out a <a href="http://fikrirasyid.com/wordpress-themes/opus/" target="_blank">demo</a> on the developer&#8217;s website to see Opus in action.</p>
<p>If you like the theme and want to contribute, <a href="https://github.com/fikrirasyid/opus" target="_blank">Opus is also hosted on github</a> and its developer welcomes you to fork it, submit a patch, pull request or report any bugs you find. Since the theme can be found in the official <a href="http://wordpress.org/themes/" target="_blank">WordPress Themes Directory</a>, it has already passed a rigorous review by the WordPress Theme Review team and you can be certain that it doesn&#8217;t contain any malicious code. <a href="http://wordpress.org/themes/opus" target="_blank">Opus</a> is a great option for anyone who wants a minimalist and responsive one-column blog theme with a splash of personality.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Jan 2014 23:10:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Joseph: WordPress Car Stickers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://josephscott.org/?p=9834";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://josephscott.org/archives/2014/01/wordpress-car-stickers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:288:"<p><img src="https://farm8.staticflickr.com/7402/12016117746_9d0f7e3013_b.jpg" width="1024" height="452" class="aligncenter" /></p>
<p>Saw this in the parking lot during the <a title="First PHP conference in Utah, went very well." href="https://www.skiphp.com/">SkiPHP</a> conference.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Jan 2014 22:41:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Joseph Scott";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: WordPress Developers Take Note: TinyMCE 4.0 Merged Into Core";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=15016";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/wordpress-developers-take-note-tinymce-4-0-merged-into-core?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-developers-take-note-tinymce-4-0-merged-into-core";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3378:"<p>Andrew Ozz who is responsible for maintaining TinyMCE in WordPress <a title="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/" href="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">has announced</a> that TinyMCE 4.0 has been merged into core. The upgrade contains a number of changes including:</p>
<ul>
<li>New UI and UI API.</li>
<li>New theme.</li>
<li>Revamped events system/API.</li>
<li>Better code quality, readability and build process.</li>
<li>Lots of (inline) documentation.</li>
<li>Overall improvements everywhere</li>
</ul>
<div id="attachment_15031" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/01/TinyMCE40Interface.jpg" rel="prettyphoto[15016]"><img class="size-large wp-image-15031" alt="TinyMCE 4.0 In Development version of WP" src="http://wptavern.com/wp-content/uploads/2014/01/TinyMCE40Interface-500x204.jpg" width="500" height="204" /></a><p class="wp-caption-text">TinyMCE 4.0 In Development version of WP</p></div>
<p>All of the default TinyMCE plugins as well as the custom plugins used by WordPress have been upgraded to be compatible with 4.0. Since there are a lot of API changes, plugin developers are strongly encouraged to update their plugins to make sure they are compatible with 4.0 and then test them against WordPress Trunk.</p>
<p>Andrew Ozz listed three groups of general TinyMCE plugins that are added by WordPress Plugins.</p>
<ul>
<li>A custom plugin created specifically for the WordPress plugin. If you’ve developed this kind of plugin, please see the 3.x to 4.0 <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and the <a href="http://www.tinymce.com/wiki.php/api4:index">4.0 API documentation</a>.</li>
<li>WordPress plugins that add third-party or default TinyMCE plugins would (of course) need to be updated to include the 4.0 version of the plugin. The PHP global $tinymce_version can be used to determine which plugin to load.</li>
<li>Mini-plugins that only add a button to the toolbar. This works pretty much the same. It is advisable to update to use the ‘dashicons’ icon font instead of image icon.</li>
</ul>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/TinyMCE40Icons.jpg" rel="prettyphoto[15016]"><img class="alignright size-full wp-image-15026" alt="TinyMCE 4.0 Icons" src="http://wptavern.com/wp-content/uploads/2014/01/TinyMCE40Icons.jpg" width="315" height="136" /></a>After upgrading to the bleeding edge version of WordPress 3.9 to compare the visual editor with WordPress 3.8, I immediately noticed that the <a title="http://ran.ge/wordpress-plugin/pull-quotes/" href="http://ran.ge/wordpress-plugin/pull-quotes/">Pull Quotes</a> icon image that&#8217;s added to the visual editor disappeared. While the place holder is still there and the button functions normally, the icon image is gone. There are two other plugins that have added custom icon images to the visual editor and those work just fine. However, since they are not using SVG images or Dashicons, the experience is not consistent with the rest of the interface.</p>
<p>If you&#8217;re the author of a plugin that modifies or changes the behavior of TinyMCE, now is the time to test it against the trunk of WordPress so users don&#8217;t encounter unexpected changes when they upgrade to WordPress 3.9.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Jan 2014 21:00:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: WordCamp Paris 2014: Uniting The French WordPress Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14988";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:180:"http://wptavern.com/wordcamp-paris-2014-uniting-the-french-wordpress-community?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-paris-2014-uniting-the-french-wordpress-community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5823:"<p>The third official <a href="http://2014.paris.wordcamp.org/" target="_blank">WordCamp Paris</a> was held this past weekend, featuring 15 talks and seven workshops during Jan 17-18. From all accounts it seems to have been a stellar event. The first day focused on business and enterprise and the second day included a mix of talks and workshops focused on tech, design and community topics.</p>
<p>All of the WordCamps that we&#8217;ve attended and reported on have been held in English, so I got in touch with <a href="http://www.jennybeaumont.com/" target="_blank">Jenny Beaumont</a> to see if she could give us an inside look into WordCamp Paris. </p>
<div id="attachment_15019" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/01/jennyb.jpg" rel="prettyphoto[14988]"><img src="http://wptavern.com/wp-content/uploads/2014/01/jennyb.jpg" alt="WordPress Developer Jenny Beaumont - photo credit: cc license -  Manuel Schmalstieg" width="610" height="534" class="size-full wp-image-15019" /></a><p class="wp-caption-text">WordPress Developer Jenny Beaumont &#8211; photo credit: cc license &#8211;  <a href="http://www.flickr.com/photos/kinetoskop/12030822934/sizes/c/in/set-72157639932762833/">Manuel Schmalstieg</a></p></div>
<p>Beaumont came to France in 1998 where she began her career in the web. She now lives in rural Normandy and works as a freelance front-end developer specializing in WordPress. </p>
<p>While most of the sessions were given in French, a handful of presentations were in English. WordCamp Paris featured an impressive variety of topics, including challenges for WordPress agencies, pricing a WordPress site, multisite and multilingual case studies, e-commerce, interface design and much more. </p>
<p>Beaumont attended 10 of the 23 conferences and workshops and said that two sessions were particularly outstanding. &#8220;There were a lot of interesting topics presented, including a round table debate about the world of theming,&#8221; she said. &#8220;But for me, two sessions really stood out above the rest: <a href="https://twitter.com/glueckpress" target="_blank">Caspar Hübinger</a>&#8216;s presentation &#8220;<a href="http://glueckpress.com/5175" target="_blank">The Multilingual Blogging Software Dilemma (and ways to solve it)</a>&#8220;, and <a href="https://twitter.com/BoiteAWeb" target="_blank">Julio Potier</a>&#8216;s &#8220;<a href="http://fr.slideshare.net/Boiteaweb/choisir-les-bons-hooks-dans-vos-dveloppements-wordpress" target="_blank">Diving into WordPress Hooks</a>&#8221; (rough translation). They were both tight, incredibly funny and very well delivered.&#8221;</p>
<h3>Workshops: An Alternative to Contributor Days</h3>
<p>WordCamp Paris is unique in that the organizers have opted for facilitating workshops instead of hosting a contributor day. These are small sessions where Beaumont says everyone is encouraged to get into the nitty-gritty of subjects like hooks, multilingual publishing, SEO, the why and how of creating plugins and working with advanced custom fields. &#8220;I think we&#8217;re seeing what other WordCamps are, from what I&#8217;ve heard,&#8221; Beaumont said. &#8220;And that&#8217;s a clear move from being technically oriented to really addressing all aspects — and all users — of the WordPress ecosystem.&#8221; The workshops at WordCamp Paris provided something for users of every level of WordPress expertise. </p>
<h3>The French WordPress Community Is Growing</h3>
<div id="attachment_15013" class="wp-caption alignright"><a href="http://wptavern.com/wp-content/uploads/2014/01/wcparis.jpg" rel="prettyphoto[14988]"><img src="http://wptavern.com/wp-content/uploads/2014/01/wcparis.jpg" alt="photo credit: gd6d - cc license" width="1600" height="556" class="size-full wp-image-15013" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/gd6d/12035168424/in/photostream/">gd6d</a> &#8211; cc license</p></div>
<p>Beaumont attended the last two WordCamps held in Paris and she believes that the French WordPress community is growing in numbers and may expand to host another event outside of Paris.</p>
<blockquote><p>Although WordCamps have only been held in Paris to date, the French community is taking root in every region of France, and I shouldn&#8217;t neglect mentioning our French-speaking neighbors in Belgium and Switzerland who also had a presence. I predict a strong increase in the number of Meetups for 2014 and it wouldn&#8217;t surprise me to see a WordCamp pop up outside of Paris in the near future.</p></blockquote>
<p>Every local WordPress community faces its own unique challenges. I asked Beaumont how she would characterize the French WordPress community, based on her experience at large events over the past few years. She replied:</p>
<blockquote><p>Had you asked me that last year I might have responded &#8220;fractured and stubborn&#8221;, but that is clearly no longer the case. I really feel that something special happened at WordCamp Europe back in October, something that inspired a momentum that we&#8217;re all still riding on today. People are coming together, opening up and crossing divides. There is a ton of creative energy and talent here — what&#8217;s been missing is the true spirit of giving and sharing, of community! That is shifting and it&#8217;s exciting to be a part of it.</p></blockquote>
<p>It&#8217;s good news to hear that WordPress events in Europe are bringing the French WordPress community together in a new way, with more meetups and collaboration on the horizon. For more photos and tweets related to the event, check out the <a href="http://wcparis.wparmchair.com/" target="_blank">WP Armchair site for WordCamp Paris 2014</a>. If you attended WordCamp Paris, what was your take on the event? </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Jan 2014 20:27:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WPTavern: How to Check For Broken Links On Your Site Using Xenu Link Sleuth";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14902";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:194:"http://wptavern.com/how-to-check-for-broken-links-on-your-site-using-xenu-link-sleuth?utm_source=rss&utm_medium=rss&utm_campaign=how-to-check-for-broken-links-on-your-site-using-xenu-link-sleuth";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3731:"<p>Checking for broken links using WordPress plugins can lead to intensive use of server resources and impact site performance. Plugins like <a title="http://wordpress.org/plugins/broken-link-checker/" href="http://wordpress.org/plugins/broken-link-checker/">Broken Link Checker</a> are restricted on certain webhosts because of the performance issues they can introduce to a site. Thankfully, there are free programs available that off-load the process of checking links from the web server to a local machine. <a title="http://home.snafu.de/tilman/xenulink.html#Download" href="http://home.snafu.de/tilman/xenulink.html#Download">Xenu Link Sleuth</a> is one such program. Released in 2010, Xenu Link Sleuth is compatible with Microsoft Windows 95/98/ME/NT/2000/XP/Vista/7.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/XenuBrokenURLS.jpg" rel="prettyphoto[14902]"><img class="aligncenter size-large wp-image-14965" alt="Xenu Link Sleuth Broken URLs" src="http://wptavern.com/wp-content/uploads/2014/01/XenuBrokenURLS-500x204.jpg" width="500" height="204" /></a></p>
<p>After installing the program to your machine, type in the URL you want to check. Link verification is performed on <strong>normal links, images, frames, plug-ins, backgrounds, local image maps, style sheets, scripts and java applets</strong>. It displays a continuously updated list of URLs which you can sort by different criteria. Reports can be generated at any time. Since the majority of processing takes place on the machine performing the report, it&#8217;s quicker and doesn&#8217;t need a database to store the results. Another advantage is that unlike online services, you&#8217;re not limited to a maximum number of URLs that can be checked.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/XenuCheckURL.jpg" rel="prettyphoto[14902]"><img class="aligncenter size-large wp-image-14961" alt="Xenu Check URL" src="http://wptavern.com/wp-content/uploads/2014/01/XenuCheckURL-500x452.jpg" width="500" height="452" /></a></p>
<p>When I generated a report for WPTavern.com, Xenu used between 29-30 threads and checked over 10,000 urls. Green colored text signals no errors while red indicates a problem. In my case, it usually meant the image was not found. Since a report can be made up of thousands of links, Xenu Link Sleuth provides the ability to only view broken ones.</p>
<div id="attachment_14962" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/01/XenuStatusText.jpg" rel="prettyphoto[14902]"><img class="size-large wp-image-14962" alt="Xenu Link Sleuth Status Text" src="http://wptavern.com/wp-content/uploads/2014/01/XenuStatusText-500x250.jpg" width="500" height="250" /></a><p class="wp-caption-text">Green Is Good. Red Is Bad</p></div>
<p>Although Xenu Link Sleuth does not work natively on the Mac, a program called <a title="http://peacockmedia.co.uk/integrity/" href="http://peacockmedia.co.uk/integrity/">Integrity</a> for Mac OS X Mavericks is available. Integrity was recently updated to include support for Mavericks and retina displays.</p>
<h3>Good Practice or Waste Of Time?</h3>
<p>By using Xenu Link Sleuth, I was able to see hundreds of broken links of the thousands that make up the WPTavern archive. I feel conflicted on whether I should fix them or not. Links breaking are part of the natural life cycle of the web. Part of me wants to make sure each link that exists on the domain works correctly. The other part feels that by changing the URL, I would be altering history. Should I only concern myself with links up to a certain time period? How often do you check for broken links on your site? What programs or services do you use to perform the task?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Jan 2014 18:00:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: GoDaddy Launches Managed WordPress Hosting Service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14897";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:164:"http://wptavern.com/godaddy-launches-managed-wordpress-hosting-service?utm_source=rss&utm_medium=rss&utm_campaign=godaddy-launches-managed-wordpress-hosting-service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5948:"<p><a href="http://wptavern.com/wp-content/uploads/2014/01/GoDaddyLogoSmall.jpg" rel="prettyphoto[14897]"><img class="alignright size-full wp-image-14958" alt="GoDaddy Small Logo" src="http://wptavern.com/wp-content/uploads/2014/01/GoDaddyLogoSmall.jpg" width="169" height="77" /></a>As Marcus Couch <a title="http://wptavern.com/its-go-time-godaddy-teases-future-managed-wordpress-hosting" href="http://wptavern.com/its-go-time-godaddy-teases-future-managed-wordpress-hosting">hinted at</a> back on November 27th, 2013, GoDaddy has <a title="http://www.godaddy.com/hosting/wordpress-hosting.aspx?ci=86979" href="http://www.godaddy.com/hosting/wordpress-hosting.aspx?ci=86979">entered the Managed WordPress hosting</a> space. Plans start at <strong>$6.29</strong> per month and include DDoS protection, firewalls, automatic updates and an easy one-click migration tool. GoDaddy states that their service will have <em>blistering speed and guaranteed <a title="http://www.godaddy.com/agreements/showdoc.aspx?pageid=hosting_sa" href="http://wptavern.com/  http://www.godaddy.com/agreements/showdoc.aspx?pageid=hosting_sa">99.9% uptime</a></em>.</p>
<h3>More Of The Same</h3>
<p>GoDaddy has a list of <a title="http://support.godaddy.com/help/article/8964/managed-wordpress-blacklisted-plugins" href="http://support.godaddy.com/help/article/8964/managed-wordpress-blacklisted-plugins">restricted plugins</a> similar to <a title="http://wpengine.com/support/disallowed-plugins/" href="http://wpengine.com/support/disallowed-plugins/">WP Engine</a>. GoDaddy explains that by restricting the plugins listed, it keeps their managed accounts secure. GoDaddy doesn&#8217;t have the best track record of being a secure webhost. <a title="http://blog.sucuri.net/2010/06/godaddy-sites-hacked-with-cloudisthebestnow.html" href="http://blog.sucuri.net/2010/06/godaddy-sites-hacked-with-cloudisthebestnow.html">In 2010</a>, the company experienced a number of malware type hacks on their hosting service as did other major hosting providers such as <a title="http://blog.sucuri.net/2010/06/blacklisted-sites-at-netsol.html" href="http://blog.sucuri.net/2010/06/blacklisted-sites-at-netsol.html">Network Solutions</a>.</p>
<div id="attachment_14957" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/01/GoDaddyHacked2010.jpg" rel="prettyphoto[14897]"><img class="size-large wp-image-14957" alt="GoDaddy Hacked In 2010" src="http://wptavern.com/wp-content/uploads/2014/01/GoDaddyHacked2010-500x110.jpg" width="500" height="110" /></a><p class="wp-caption-text">As Reported By Sucuri In 2010</p></div>
<p><a title="http://wptavern.com/its-go-time-godaddy-teases-future-managed-wordpress-hosting#comment-49358" href="http://wptavern.com/its-go-time-godaddy-teases-future-managed-wordpress-hosting#comment-49358">One of the fears</a> expressed by readers was that they would undercut the competition with rock bottom prices. Here is a comparison between a few different WordPress managed hosting providers using their cheapest plan as the lowest common denominator.</p>
<ul>
<li>GoDaddy &#8211; <strong>$6.99</strong> / month</li>
<li>Siteground &#8211; <strong>$9.95</strong> / month</li>
<li>Flywheel &#8211; <strong>$15.00</strong> / month</li>
<li>DreamPress &#8211; <strong>$19.95</strong> / month</li>
<li>Pagely &#8211; <strong>$24.00</strong> / month</li>
<li>Pressable &#8211; <strong>$25.00</strong> / month</li>
<li>Synthesis &#8211; <strong>$27.00</strong> / month</li>
<li>WP Engine &#8211; <strong>$29.00</strong> / month</li>
</ul>
<h3>GoDaddy Is The Cheapest But That Doesn&#8217;t Mean They Win</h3>
<p>If price were the only determining factor for choosing a managed WordPress webhost, GoDaddy would win. However, it&#8217;s important to note that each company applies different limits and options to their plans. These variations are one of the reasons for the variety of prices. Based on conversations I&#8217;ve had with a number of WordPress consultants who deal with webhosting companies on a daily basis, GoDaddy is not on the top of their list as a recommendation to their clients.</p>
<p><a title="http://wptavern.com/its-go-time-godaddy-teases-future-managed-wordpress-hosting#comment-49430" href="http://wptavern.com/its-go-time-godaddy-teases-future-managed-wordpress-hosting#comment-49430">According to Donnacha</a>, GoDaddy entering the market should help push prices closer to where they ought to be.</p>
<blockquote><p>Frankly, the existing “specialist” WordPress hosting companies are useless when a client has anything more than a minor problem. I have long thought that what customers are getting is, roughly, a $10 value for $30, with ridiculous jumps in billing for minor increases in resources. The entry of bigger players such as GoDaddy will, at least, push prices closer to where they should be.</p></blockquote>
<p>With that said, I don&#8217;t think established managed WordPress hosting companies have anything to fear. GoDaddy may have the cheapest prices, but they will have to work extremely hard to earn back the goodwill of the WordPress community.</p>
<h3>Low Prices Won&#8217;t Be Enough</h3>
<p>Since the departure of Bob Parsons as CEO, the company has changed its image from sexy women and hunting elephants to being much more professional as a business. I think GoDaddy has improved in many areas in the past two years but they still have a ways to go. The company has sponsored a number of WordCamps and has been very supportive of the WordPress project. But it&#8217;s going to take time and dedication to change the minds of so many WordPress hosting customers who have had a bad experience with the company the past three years. I&#8217;m looking forward to the day when I hear people recommending GoDaddy for hosting versus the other way around.</p>
<p>I&#8217;d love to hear from customers who are currently using the new GoDaddy managed WordPress hosting service.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Jan 2014 17:30:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: 10 Free Plugins to Customize WordPress Admin Color Schemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14676";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:180:"http://wptavern.com/10-free-plugins-to-customize-wordpress-admin-color-schemes?utm_source=rss&utm_medium=rss&utm_campaign=10-free-plugins-to-customize-wordpress-admin-color-schemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7061:"<p>Can you believe that there are already ten plugins available for customizing WordPress admin color schemes? This feature has been popular among plugin developers since the new admin design was added in the 3.8 release. We&#8217;ve selected ten plugins that offer a wide variety of ways to customize and control admin color schemes. Many of these plugins have very similar names, so it might be easy to get them confused. However, if you look closely you&#8217;ll find each does something slightly different.</p>
<h3>Admin Color Schemes</h3>
<p><a href="http://wordpress.org/plugins/admin-color-schemes/"><img src="http://wptavern.com/wp-content/uploads/2014/01/admin-color-schemes.png" alt="admin-color-schemes" width="1544" height="500" class="aligncenter size-full wp-image-14917" /></a></p>
<p>WordPress ships with eight different color schemes. The <a href="http://wordpress.org/plugins/admin-color-schemes/" target="_blank">Admin Color Schemes</a> plugin adds eight additional, professionally designed options for you to choose from. </p>
<h3>Grey Admin Color Schemes</h3>
<p><a href="http://wordpress.org/plugins/grey-admin-color-schemes/"><img src="http://wptavern.com/wp-content/uploads/2014/01/grey.png" alt="grey" width="772" height="250" class="aligncenter size-full wp-image-14922" /></a></p>
<p>The <a href="http://wordpress.org/plugins/grey-admin-color-schemes/" target="_blank">Grey Admin Color Schemes</a> plugin offers four slightly varied grey schemes, including the classic grey color scheme from WordPress 3.7, a blue-tinted grey scheme, a modern grey and a post-modern grey.</p>
<h3>Admin Color Schemer</h3>
<p><a href="http://wordpress.org/plugins/admin-color-schemer/"><img src="http://wptavern.com/wp-content/uploads/2013/12/featured-admin-color-schemer.jpg" alt="featured-admin-color-schemer" width="800" height="259" class="aligncenter size-full wp-image-13824" /></a></p>
<p>We <a href="http://wptavern.com/admin-color-schemer-the-easiest-way-to-customize-wordpress-admin-colors" target="_blank">featured</a> the <a href="http://wordpress.org/plugins/admin-color-schemer/" target="_blank">Admin Color Schemer</a> plugin on WPTavern at the end of December. It provides one of the easiest and most comprehensive ways to create and preview admin color schemes without having to touch any code. It includes 30 advanced options, including  the ability to customize body background, links, menu background, menu current background, checked form controls and more.</p>
<h3>WP Admin Classic Colors</h3>
<p><a href="http://wordpress.org/plugins/wp-admin-classic-colors/"><img src="http://wptavern.com/wp-content/uploads/2014/01/wp-admin-classic-colors.png" alt="wp-admin-classic-colors" width="772" height="250" class="aligncenter size-full wp-image-14924" /></a></p>
<p><a href="http://wordpress.org/plugins/wp-admin-classic-colors/" target="_blank">WP Admin Classic Colors</a> adds a new color scheme option to WordPress. It recreates the scheme that shipped with WordPress prior to 3.8, using light grey and blue colors. It also adds visible menu separators between menu blocks and menu items.</p>
<h3>WP Admin Classic</h3>
<p><a href="http://wordpress.org/plugins/wp-admin-classic/"><img src="http://wptavern.com/wp-content/uploads/2014/01/old-admin-style.png" alt="old-admin-style" width="800" height="353" class="aligncenter size-full wp-image-14935" /></a></p>
<p><a href="http://wordpress.org/plugins/wp-admin-classic/" target="_blank">WP Admin Classic</a> disables the new admin theme in WordPress 3.8 and turns on the old design instead. I have no idea why you would ever want to use this plugin, but it&#8217;s out there if you resist the new admin design and want to revert your site backwards.</p>
<h3>Color Schemes Roulette</h3>
<p><a href="http://wordpress.org/plugins/color-schemes-roulette/"><img src="http://wptavern.com/wp-content/uploads/2014/01/roulette.png" alt="roulette" width="1544" height="500" class="aligncenter size-full wp-image-14930" /></a></p>
<p><a href="http://wordpress.org/plugins/color-schemes-roulette/" target="_blank">Color Schemes Roulette</a> is a fun plugin that randomly changes the admin color scheme every time you publish a post. It was created to help motivate users to publish more and also works hand-in-hand with the <a href="http://wordpress.org/plugins/admin-color-schemes/" target="_blank">Admin Color Schemes</a> plugin.</p>
<h3>Default Admin Color Scheme</h3>
<p><a href="http://wordpress.org/plugins/default-admin-color-scheme/"><img src="http://wptavern.com/wp-content/uploads/2014/01/default-admin-color-scheme.png" alt="default-admin-color-scheme" width="1544" height="500" class="aligncenter size-full wp-image-14932" /></a></p>
<p><a href="http://wordpress.org/plugins/default-admin-color-scheme/" target="_blank">Default Admin Color Scheme</a> lets you select a default admin color scheme for new and existing users. It adds a new option to Settings > General where you can select a default color scheme for all users. You can also disable the color scheme picker on the Users > Profile page if you don&#8217;t want users to change it.</p>
<h3>Quick Admin Color Scheme Picker</h3>
<p><a href="http://wordpress.org/plugins/quick-admin-color-scheme-picker/"><img src="http://wptavern.com/wp-content/uploads/2014/01/quick-admin-color-scheme-picker.png" alt="quick-admin-color-scheme-picker" width="1592" height="613" class="aligncenter size-full wp-image-14939" /></a></p>
<p><a href="http://wordpress.org/plugins/quick-admin-color-scheme-picker/" target="_blank">Quick Admin Color Scheme Picker</a> adds the color scheme options to the &#8220;Howdy&#8221; menu in the top right of the WordPress admin for quick access.</p>
<h3>HS Custom Admin Theme</h3>
<p><a href="http://wordpress.org/plugins/hs-custom-admin-themes/"><img src="http://wptavern.com/wp-content/uploads/2014/01/hs-admin-color-scheme.png" alt="hs-admin-color-scheme" width="772" height="250" class="aligncenter size-full wp-image-14941" /></a></p>
<p><a href="http://wordpress.org/plugins/hs-custom-admin-themes/" target="_blank">HS Custom Admin Theme</a> gives you the ability to design your own color palettes for the WordPress admin area and then save them within a library of color schemes for later use. The options let you customize the background color, font color, navigation menu color, and post and page form color. </p>
<h3>Admin Bar Color</h3>
<p><a href="http://wordpress.org/plugins/admin-bar-color/"><img src="http://wptavern.com/wp-content/uploads/2014/01/admin-color-bar.png" alt="admin-color-bar" width="1430" height="459" class="aligncenter size-full wp-image-14943" /></a></p>
<p><a href="http://wordpress.org/plugins/admin-bar-color/" target="_blank">Admin Bar Color</a> is a simple plugin that applies your active admin color scheme to the front-end WordPress admin bar. This provides a more unified experience when switching between the front and the backend.</p>
<p>Did we miss any of your favorites? Which plugins do you find to be the most useful for customizing admin color schemes?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Jan 2014 17:20:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: WPWeekly Episode 134 – Talking WordCamps With David Bisset";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=14904&preview_id=14904";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:176:"http://wptavern.com/wpweekly-episode-134-talking-wordcamps-with-david-bisset?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-134-talking-wordcamps-with-david-bisset";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3860:"<p>This weeks edition of WordPress Weekly features special guest, <a href="http://www.davidbisset.com/" title="http://www.davidbisset.com/">David Bisset</a>. We were also joined by <a href="http://marcuscouch.com/" title="http://marcuscouch.com/">Marcus Couch.</a> After catching up on the headlines, we dove into the topic of WordCamps. Specifically, encouraging women to speak while also increasing diversity, new IRS regulations that corporate sponsors must abide by and last but not least, whether WordCamps need a dedicated safety officer or not. If you&#8217;re a current or future WordCamp organizer, this episode is for you! We concluded the show with Marcus giving his three plugin picks of the week. </p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/data-gov-is-using-wordpress-and-all-the-code-is-open-source" title="http://wptavern.com/data-gov-is-using-wordpress-and-all-the-code-is-open-source">Data.gov Is Using WordPress and All the Code is Open Source</a><br />
<a href="http://wptavern.com/wordpress-managed-host-nodeki-goes-bust-no-refunds-for-lifetime-customers" title="http://wptavern.com/wordpress-managed-host-nodeki-goes-bust-no-refunds-for-lifetime-customers">WordPress Managed Host NodeKi Goes Bust: No Refunds For Lifetime Customers</a><br />
<a href="http://wptavern.com/google-releases-its-first-plugin-for-wordpress-publishers" title="http://wptavern.com/google-releases-its-first-plugin-for-wordpress-publishers">Google Releases Its First Plugin For WordPress Publishers</a><br />
<a href="http://wptavern.com/official-git-mirror-now-available-for-wordpress-core-development-repository" title="http://wptavern.com/official-git-mirror-now-available-for-wordpress-core-development-repository">Official Git Mirror Now Available for WordPress Core Development Repository</a><br />
<a href="http://wptavern.com/tax-day-release-wordpress-3-9-to-drop-on-april-15" title="http://wptavern.com/tax-day-release-wordpress-3-9-to-drop-on-april-15">Tax Day Release: WordPress 3.9 to Drop on April 15</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="http://wordpress.org/plugins/wp-draftsforfriends/" title="http://wordpress.org/plugins/wp-draftsforfriends/">WP-DraftsForFriends</a> is a plugin that will generate a unique link that you can send to your friends to allow them to preview your draft before they are published. You are able to set the expiry for the link as well.</p>
<p><a href="http://wordpress.org/plugins/floating-publish-button/" title="http://wordpress.org/plugins/floating-publish-button/">Floating Publish Button</a> will help you click on &#8220;Publish/Update&#8221; button in admin panel without scrolling back to top of the page. The whole publish block floats downward as your scroll.</p>
<p><a href="http://wordpress.org/plugins/wp-triggers-lite/" title="http://wordpress.org/plugins/wp-triggers-lite/">WP Triggers Lite</a> creates interactive trigger boxes. These are conditional boxes that display when the user types in a predetermined phrase or keywords. Once the criteria is met, it triggers what you want to display. If it does not meet the criteria you set, it will default to whatever you set the default process to do.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, January 24th 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #134:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 18 Jan 2014 07:17:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Alex King: Pixel Jar Joins Crowd Favorite";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=19267";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://crowdfavorite.com/blog/2014/01/welcome-pixel-jar/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:738:"<p>I&#8217;m really excited to start working with Brandon and Jeffery; this is a great addition to the <a href="http://crowdfavorite.com">Crowd Favorite</a> family.</p>
<p>UPDATE: Check out <a href="http://chrislema.com/great-things-often-start-small/">Chris Lema&#8217;s post</a> and <a href="http://www.pixeljar.net/2014/01/17/pixel-jar-is-being-aquired/">the announcement on Pixel Jar&#8217;s blog</a>.</p>
<p class="threads-post-notice">This post is part of the thread: <a href="http://alexking.org/blog/thread/crowd-favorite">Crowd Favorite</a> &#8211; an ongoing story on this site. View the thread timeline for more context on this post.</p>
<p><a href="http://alexking.org/blog/2014/01/17/pixel-jar-joins-crowd-favorite">#</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 18 Jan 2014 06:00:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: Remly Hosting Extends Offer to Lifetime Customers Jilted by NodeKi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14878";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:196:"http://wptavern.com/remly-hosting-extends-offer-to-lifetime-customers-jilted-by-nodeki?utm_source=rss&utm_medium=rss&utm_campaign=remly-hosting-extends-offer-to-lifetime-customers-jilted-by-nodeki";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3840:"<p>After we reported on WordPress managed host <a href="http://wptavern.com/wordpress-managed-host-nodeki-goes-bust-no-refunds-for-lifetime-customers" target="_blank">NodeKi going out of business</a>, both former customers and the WordPress community were left wondering what happened behind the scenes. </p>
<p>The Tavern was then contacted by the company who purchased NodeKi&#8217;s paying customers. Jonathan VanSchaack, director of the web division of <a href="http://www.remcom.net/" target="_blank">Remly Communications</a>, offered to fill us in on some of the details behind what happened to NodeKi&#8217;s customers before the collapse of the company. He said:</p>
<blockquote><p>We had the opportunity to purchase NodeKi clients that were actively paying.  We did express some interest in the Lifetime clients but we chose not to as any business plan that relies on 0 revenue long term is due to fail. That being said we sent our own letter out to the paying customers of NodeKi letting them know we will be migrating them to our servers in the long term but also keeping their servers active.  We felt we could provide superior services along with great support to those clients. </p></blockquote>
<p>VanSchaack said that he purchased the customers directly from NodeKi and not the InterQuad holding company. As <a href="http://www.remcom.net/" target="_blank">Remly</a> has been in business for 11 years and offers managed hosting for WordPress and other CMS platforms, they felt that it was a great fit. &#8220;Remly purchased the clients for expansion,&#8221; he said.  &#8220;We are in a growth area of our business now that we feel infrastructure is at a very stable point.&#8221; </p>
<p>When asked how he became aware that NodeKi was wanting to sell off all of its customers, VanSchaack said that he was informed of the sale opportunity by a broker:</p>
<blockquote><p>The current owner was looking for a home for the customers that would give similar support and offerings. To be honest his asking price was far below market value. As in my opinion, he was trying to find the right place for the customers he could move.  We looked at the lifetime clients but did not feel they fit into our business plan.</p></blockquote>
<h3>An Offer For Displaced Lifetime Customers</h3>
<p>Remly Hosting is offering a three month free trial matching the top lifetime plan NodeKi offered for those customer who have been displaced. This includes migration services for cPanel to cPanel transfers. VanSchaack has already been in contact with the owner and says that he is willing to give access to client accounts where permission is given by the customer. The plan includes a comparable set of resources previously provided by NodeKi, in terms of disk space, bandwidth, databases, additional domains. </p>
<p>After the three months, former NodeKi customers can elect to break away from the hosting or transition to one of Remly&#8217;s paid Managed WordPress plans starting at $12.95 a month. VanSchaack said, &#8220;<strong>Our goal is to help customers that might be having issues on such a short notice but also show them our services are the same if not better than NodeKi and to stick with us long term.</strong>&#8221; Any NodeKi customers who are interested can email <a href="mailto:sales@remly.com">sales@remly.com</a> or open a support ticket under the NodeKi account and Remly will get involved. </p>
<p>The lesson to consumers here is that no lifetime plan is ever guaranteed to last a lifetime, and may not even be available for the lifetime of the company. Customers can be bought and sold at any time. When you&#8217;re looking for a WordPress host, it&#8217;s good to do a little background research into the stability of the company, especially if it is new and offering deals that might seem too good to be true.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Jan 2014 22:23:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"WPTavern: New WordPress Trac Features Have Been Ported to bbPress and BuddyPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14720";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:204:"http://wptavern.com/new-wordpress-trac-features-have-been-ported-to-bbpress-and-buddypress?utm_source=rss&utm_medium=rss&utm_campaign=new-wordpress-trac-features-have-been-ported-to-bbpress-and-buddypress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3078:"<p>So far, 2014 is the year for making over <a href="https://core.trac.wordpress.org/" target="_blank">WordPress Trac</a>. Over the past couple weeks and during the holidays, Andrew Nacin has implemented a host of <a href="http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements" target="_blank">new features</a> that make it easier for contributors to collaborate with one another, <a href="http://wptavern.com/wordpress-adds-per-ticket-notifications-to-trac" target="_blank">get better ticket notifications</a> and work more efficiently with new reports and keywords for sorting tickets.</p>
<p>Yesterday Nacin <a href="https://make.wordpress.org/meta/2014/01/15/trac-updates/" target="_blank">posted</a> that he has now ported over most of these new features to other tracs hosted on WordPress.org (meta, bbPress, BuddyPress, GlotPress, themes and plugins), including: </p>
<ul>
<li>Use WP.org cookie authentication, SSL and refreshed design</li>
<li>bbPress and BuddyPress now have their own skins</li>
<li>Image attachment previews in tickets</li>
<li>Email address syncing</li>
<li>IRC cross-references for #wordpress-meta, #buddypress-dev, #bbpress-dev, #glotpress, #wordpress-gsoc</li>
<li>Lots of bug fixes and tweaks</li>
</ul>
<p>Remember those pale yellow colored tickets? Trac is looking much better with projects using their own skins:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/buddypress-trac.png" rel="prettyphoto[14720]"><img src="http://wptavern.com/wp-content/uploads/2014/01/buddypress-trac.png" alt="buddypress-trac" width="1500" height="926" class="aligncenter size-full wp-image-14863" /></a></p>
<p>As BuddyPress, bbPress and other large projects use trac in a similar way to WordPress, it only makes sense that the new features would be ported over. It be awesome to have the same ticket-starring and per-ticket notifications features that have been added to the WordPress trac. Nacin said that these features are on their way:</p>
<blockquote><p>Notifications are coming very soon to BuddyPress, bbPress, GlotPress, and meta. Probably in the next few days. Once a Trac is running the new notifications feature, that means it has been migrated to MySQL, which means the data is more accessible to the rest of WP.org, as well.</p></blockquote>
<p>Nacin has also been experimenting with design/functionality of the plugins trac, which is looking pretty snazzy already:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/plugin-trac.png" rel="prettyphoto[14720]"><img src="http://wptavern.com/wp-content/uploads/2014/01/plugin-trac.png" alt="plugin-trac" width="1571" height="1309" class="aligncenter size-full wp-image-14872" /></a></p>
<p>He&#8217;s still working to add links from the plugin directory to these new pages, which could make things interesting for plugin authors. He also plans to add per-plugin notifications where committers will be subscribed by default. If you&#8217;re a plugin developer, watch for these changes to be added to WordPress.org in the coming days.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Jan 2014 06:34:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Matt: WordPress &amp; Techmeme 100";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43451";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:34:"http://ma.tt/2014/01/techmeme-100/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2134:"<p>Whenever I visit a site I can usually tell whether it&#8217;s <a href="http://wordpress.org/">WordPress</a> or not within an instant &#8212; there&#8217;s just something about a WordPress site that is distinctive. <a href="http://www.w3.org/Provider/Style/URI.html">Super-clean permalinks</a> are usually a dead giveaway. One thing I&#8217;ve been noticing a lot lately is on my guilty pleasure for tech news, <a href="http://techmeme.com/">Techmeme</a>, it seems like almost every link I click is to a WordPress-powered site. Fortunately <a href="http://techmeme.com/lb">Techmeme provides a leaderboard</a> showing both rank and % of space a site has taken up in headlines in the past thirty days.</p>
<p>The list changes almost every day but went ahead and took a snapshot of the top 100 as of January 16th and ran down the platform for each one, here&#8217;s how it ended up:</p>
<p><img class="alignnone size-full wp-image-43460" src="http://i1.wp.com/s.ma.tt/files/2014/01/techmeme-100-cms.png?resize=604%2C300" alt="techmeme-100-cms" /></p>
<p>WordPress comes in at 43%, custom or bespoke systems at 42%, and then the others. When you take into effect Techmeme&#8217;s &#8220;presence&#8221; factor WP jumps to 48.8% of presence in the top 100 and all Blogsmith, Drupal, Blogspot, Tumblr, and Typepad combined are 8.4%. If you curious of the raw data, here&#8217;s <a href="https://docs.google.com/spreadsheets/d/12wLHCZROu_JcQOtm-KXIY6AE2mj7no1mrNTItgy8uBk/edit?usp=sharing">the spreadsheet with the platforms</a>.</p>
<p>This is just a snapshot, it&#8217;d be interesting to see how this evolves over time. It&#8217;s a small slice of the world of websites, but a very influential one. I&#8217;ve actually reached out to <a href="https://twitter.com/gaberivera">Gabe Rivera</a> a few times to sponsor the leaderboard page, putting a W logo next to the ones that run WordPress in the table, but nothing has come of it yet.</p>
<p><em>Thanks to <a href="http://krutal.wordpress.com/">Krutal</a>, <a href="http://paolobelcastro.com/">Paolo</a>, and <a href="http://mattnt.wordpress.com/">MT</a> for help with this.</em></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Jan 2014 01:29:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: Fullby: A Free Magazine Theme For WordPress Based on Bootstrap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14689";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:186:"http://wptavern.com/fullby-a-free-magazine-theme-for-wordpress-based-on-bootstrap?utm_source=rss&utm_medium=rss&utm_campaign=fullby-a-free-magazine-theme-for-wordpress-based-on-bootstrap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2824:"<p>Fullby is a beautiful new free WordPress theme <a href="http://www.marchettidesign.net/2014/01/fullby-free-responsive-grid-wordpress-theme/" target="_blank">released</a> last week, created by designer Andrea Marchetti. The theme is fully responsive, based on <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a> and features a grid style. This super light theme includes only two images and is fully customizable via CSS.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/fullby.jpg" rel="prettyphoto[14689]"><img src="http://wptavern.com/wp-content/uploads/2014/01/fullby.jpg" alt="fullby" width="800" height="371" class="aligncenter size-full wp-image-14808" /></a></p>
<p>If the design looks familiar, it&#8217;s because it was inspired by <a href="http://wordpress.org/themes/twentyfourteen" target="_blank">Twenty Fourteen</a>. However, it&#8217;s not a child theme. Unlike Twenty Fourteen, Fullby is a fluid theme that expands to use all the available space on any screen, including desktop, mobile, tablet and larger screens.</p>
<h4>Fullby Features:</h4>
<ul>
<li>Gallery and Video Support &#8211; easily copy and paste a Youtube ID to publish.</li>
<li>Fluid, modular and responsive grid style for posts</li>
<li>Built with Bootstrap and Font Awesome &#8211; 369 icons available</li>
<li>Featured Header Content &#8211; add &#8220;featured&#8221; content to header by using the &#8220;featured&#8221; tag in the post</li>
<li>2 Menus and 2 Sidebars</li>
<li>Popular and Latest Post Widget
</li>
</ul>
<p>Every aspect of this theme shows attention to detail, including category pages, widgets and date-based archives. Single posts have a very striking appearance and are just as beautiful as the homepage design:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/single-post.png" rel="prettyphoto[14689]"><img src="http://wptavern.com/wp-content/uploads/2014/01/single-post.png" alt="single-post" width="1272" height="806" class="aligncenter size-full wp-image-14843" /></a></p>
<p>Check out a <a href="http://www.marchettidesign.net/fullby/demo/" target="_blank">live demo</a> to see the theme at its finest.</p>
<p>Fullby caught my eye the other day, so I decided to install it on a test site and check it out. I assumed that there would be quite a bit of configuring to get it to look anything like the demo but was pleasantly surprised. There are no design-related options to tinker with. Further customization, however, will require some CSS knowledge.</p>
<p>If you&#8217;re looking for a lean blogging or magazine style theme that is based on Bootstrap, then Fullby is a strong option. Download <a href="http://www.marchettidesign.net/fullby/" target="_blank">Fullby</a> for free from <a href="http://www.marchettidesign.net/" target="_blank">Marchetti Design</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jan 2014 22:41:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"Alex King: I’ll be at WordCamp PHX this weekend with a good c…";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=19259";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://alexking.org/blog/2014/01/16/19259";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:256:"<div>
<p>I&#8217;ll be at <a href="http://2014.phoenix.wordcamp.org/">WordCamp PHX</a> this weekend with a good contingent from <a href="http://crowdfavorite.com">Crowd Favorite</a>. I look forward to meeting a bunch of you internet folks there.</p>
</div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jan 2014 18:23:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:89:"WPTavern: Why You Shouldn’t Be Worried About Screwing Up When Contributing To WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14791";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:216:"http://wptavern.com/why-you-shouldnt-be-worried-about-screwing-up-when-contributing-to-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=why-you-shouldnt-be-worried-about-screwing-up-when-contributing-to-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:11687:"<p>In the <a title="https://irclogs.wordpress.org/chanlog.php?channel=wordpress-dev&day=2014-01-15&sort=asc" href="https://irclogs.wordpress.org/chanlog.php?channel=wordpress-dev&day=2014-01-15&sort=asc">WordPress 3.9 development chat</a> that was held on <strong>Wednesday, January 15th</strong>, a number of topics were discussed ranging from features that people are working on to announcing the date for the release of <a title="http://wptavern.com/tax-day-release-wordpress-3-9-to-drop-on-april-15" href="http://wptavern.com/tax-day-release-wordpress-3-9-to-drop-on-april-15">WordPress 3.9</a>. One of the most interesting topics, however, centered around first time contributors using trac to create tickets and patches.</p>
<p>Last week, <a title="http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements" href="http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements">one of the improvements</a> to trac was the addition of the &#8220;<em>good-first-bug</em>&#8221; tag. This tag will be used to identify tickets that are good starting points for new contributors. In my opinion, this is one of the most important changes to trac we have seen in a long time. Here&#8217;s why.</p>
<div id="attachment_8216" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2013/08/482.jpg" rel="prettyphoto[14791]"><img class="size-large wp-image-8216" alt="WCSF Contributor Day" src="http://wptavern.com/wp-content/uploads/2013/08/482-500x373.jpg" width="500" height="373" /></a><p class="wp-caption-text">WCSF Contributor Day</p></div>
<p>Near the end of the meeting, a number of people shared their stories of how they contributed to WordPress for the first time. Some people used the contributor day at WordCamp San Francisco to create their first patch or ticket while another did the same at WordCamp Orlando. When <a title="http://wptavern.com/my-first-ever-wordcamp-san-francisco-experience" href="http://wptavern.com/my-first-ever-wordcamp-san-francisco-experience">I attended the WordCamp San Francisco contributor day</a> 2013, I was able to create a ticket for a longstanding issue I&#8217;ve had with the WordPress Media Library. Without the help of Mika Epstein as a mentor, I wouldn&#8217;t have been comfortable enough to <a title="http://core.trac.wordpress.org/ticket/24859" href="http://core.trac.wordpress.org/ticket/24859">create the ticket</a>.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/TracIntimidation.jpg" rel="prettyphoto[14791]"><img class="aligncenter size-large wp-image-14815" alt="Trac Intimidation" src="http://wptavern.com/wp-content/uploads/2014/01/TracIntimidation-500x265.jpg" width="500" height="265" /></a></p>
<h3>The Intimidation Factor</h3>
<p>I was asked by Andrew Nacin why I felt <a title="https://core.trac.wordpress.org/" href="https://core.trac.wordpress.org/">trac</a> was intimidating. I consider trac to be a place where all the magic happens. It&#8217;s where you need to know diff files, ticket numbers, code, etc. It&#8217;s not something a common end-user would be comfortable in navigating. To me, trac is an entirely new world that I&#8217;ve always been too nervous to enter. I don&#8217;t think I&#8217;m alone in fearing trac or being intimated by it and thus, not contributing to WordPress in that way.</p>
<div id="attachment_14816" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/01/GoodFirstBug.jpg" rel="prettyphoto[14791]"><img class="size-large wp-image-14816" alt="Good First Bug" src="http://wptavern.com/wp-content/uploads/2014/01/GoodFirstBug-500x315.jpg" width="500" height="315" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/guitavares/1703252007/">gui.tavares</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a></p></div>
<p>This is why I think the <em>&#8220;good-first-bug&#8221;</em> tag is so important. When someone new to trac picks those tickets to work on as their first, the expectation is for mistakes to happen. If a new contributor screws up a diff file or does something else wrong, it will be ok because it&#8217;s expected behavior. It takes a lot of stress off of the new contributor and creates a learning environment without the fear of screwing things up for everyone else.</p>
<h3>They&#8217;re Not Angry, I Just Think They Might Be</h3>
<p>I was then asked where the line of thinking comes from that results in me thinking that a developer might be “angry”? Are people giving off that impression? I don&#8217;t think it&#8217;s the impression those participating on trac are giving off but rather, an unnecessary fear I have. The fear in trac is doing something wrong, angering a developer, wasting their time, and making mistakes. I&#8217;ve never seen a public trac discussion where developers are yelling at newcomers for making dumb mistakes. Just the possibility of making established contributors angry is enough to prevent me from participating in that community. It&#8217;s an unnecessary tension that I think a lot of people feel.</p>
<h3>Plenty Of People To Guide Me</h3>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/GuideMe.jpg" rel="prettyphoto[14791]"><img class="aligncenter size-large wp-image-14820" alt="Guide Me Compass" src="http://wptavern.com/wp-content/uploads/2014/01/GuideMe-500x269.jpg" width="500" height="269" /></a></p>
<p>Thankfully, I was reassured from multiple people that I don&#8217;t need to feel the way I do and that there are plenty of people willing to stop what they&#8217;re doing to help guide me in the right direction. One of them was Andrew Nacin, one of the lead developers for WordPress.</p>
<blockquote><p>Please never worry about angering a developer or doing something wrong or wasting someone&#8217;s time. I get angry at developers who get angry with contributors and if you ever do get the impression you&#8217;ve annoyed someone or are doing something wrong, anyone is always welcome to ping me privately and I&#8217;m happy to A) talk to you about it and walk you through it, and B) privately talk to any contributors who *are* causing problems.</p></blockquote>
<p>What Andrew states is a sentiment that most in the WordPress Development IRC channel share. The fears that I have of screwing up are a large reason why I&#8217;m a huge fan of one-to-one mentorship. An individual who can help me through the ticket/patch process without fear of looking like a fool in front of established contributors. While there is an initiative to get a list of mentors put together, it will be awhile before something official is put in place.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/WPMentorFeaturedImage1.jpg" rel="prettyphoto[14791]"><img class="aligncenter size-large wp-image-14106" alt="WPMentor Featured Image" src="http://wptavern.com/wp-content/uploads/2014/01/WPMentorFeaturedImage1-500x207.jpg" width="500" height="207" /></a></p>
<p>What I&#8217;ve seen at contributor days at WordCamps proves to me that a WordPress mentorship program would substantially increase the amount of first time contributors. It&#8217;s not about having my hand-held as I go through the process but rather, helping to build my confidence level to a point where I&#8217;m comfortable enough to go through the process on my own. Helen brought up a great point in the conversation. If you don&#8217;t have access to commit code to the core of WordPress that millions of people will use, then there should be no reason to fear the actions of creating tickets or submitting patches.</p>
<h3>Contributing To WordPress For The First Time</h3>
<p>When I <a title="http://wptavern.com/i-contributed-to-the-core-of-wordpress-and-you-can-too" href="http://wptavern.com/i-contributed-to-the-core-of-wordpress-and-you-can-too">contributed a patch to WordPress for the first time</a>, it was an exhilarating experience. Talk about an adrenaline rush! After I saw my name in the credits portion to help make WordPress 3.8 a reality, I wanted to learn everything there was to know about PHP and contribute to WordPress full-time. Of course, reality soon sunk in but it was an awesome experience. My hope is that the tickets labeled with the tag <em>&#8220;good-first-bug&#8221;</em> are blessed so when a person uses them to get their first patch into core, they will experience the same adrenaline rush I did and consider becoming a regular patch contributor to WordPress.</p>
<h3>You&#8217;ll Need Thick Skin</h3>
<div id="attachment_14821" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/01/ThickSkin.jpg" rel="prettyphoto[14791]"><img class="size-large wp-image-14821" alt="You\'ll Need Thick Skin" src="http://wptavern.com/wp-content/uploads/2014/01/ThickSkin-500x332.jpg" width="500" height="332" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/uberzombie/1029296894/">uberzombie</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a></p></div>
<p>Not every patch makes it to core. Some of them are discarded and when it comes to using trac to contribute, you&#8217;ll need a thick skin and be able to accept defeat. However, those experiences build character and just because a patch is denied, doesn&#8217;t mean it&#8217;s game over. It&#8217;s important to note that while most of this article is dedicated to contributing to WordPress through trac, there are many other ways to contribute. As Helen noted in the conversation:</p>
<blockquote><p>There are things beyond patches that are extremely valuable, and in some cases even more valuable. Great bug reports, reproducing elusive bugs, testing patches, refreshing patches, commenting on tickets so people don&#8217;t feel like they&#8217;re left hanging, etc.</p></blockquote>
<p>So far, the best guide I&#8217;ve seen on the topic of contributing to WordPress was <a title="http://wp.smashingmagazine.com/2013/05/10/contributing-to-wordpress/" href="http://wp.smashingmagazine.com/2013/05/10/contributing-to-wordpress/">published by Siobhan McKeown</a>. While it&#8217;s from May of 2013, it does an excellent job of showcasing all of the different parts of the project that people can contribute to.</p>
<h3>Conclusion:</h3>
<p>My main take away from the WordPress developers chat is that my fear of navigating trac and contributing to WordPress through code is unwarranted. There are plenty of people willing to stop on a dime and help me through the process. All I need to do is ask. I also learned that getting new people to contribute through trac has become one of the top priorities for WordPress core developers.</p>
<p>So far, trac has undergone a number of changes that reflect that train of thought and there are more to come. Thanks to improvements like the addition of the <em>&#8220;good-first-bug&#8221;</em>, trac doesn&#8217;t have to be such an intimidating place to begin contributing to WordPress through code. Trac is not a fraternity, it&#8217;s not a place where only the elite of WordPress programmers reside. Trac is just a tool to help improve WordPress, nothing more. <a title="http://wptavern.com/i-contributed-to-the-core-of-wordpress-and-you-can-too" href="http://wptavern.com/i-contributed-to-the-core-of-wordpress-and-you-can-too">I contributed to the core of WordPress and you can too!</a></p>
<p><em>Credit for the title of this post goes to <strong><a title="http://profiles.wordpress.org/shelob9" href="http://profiles.wordpress.org/shelob9">shelob9</a></strong> also known as Josh Pollock from the WordPress development chat.</em></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jan 2014 17:21:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: Aesop Storytelling Engine Launches Crowdfunding Campaign";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14827";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:176:"http://wptavern.com/aesop-storytelling-engine-launches-crowdfunding-campaign?utm_source=rss&utm_medium=rss&utm_campaign=aesop-storytelling-engine-launches-crowdfunding-campaign";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2820:"<p>Last week Nick Haskins introduced his <a href="http://wptavern.com/aesop-story-engine-an-open-source-wordpress-plugin-for-storytelling" target="_blank">open source storytelling plugin</a> for WordPress. The proof of concept allows publishers to create big, visual posts with multimedia storytelling tools built right into the WordPress post editor. The New York Times showcased this trend in its feature <a href="http://www.nytimes.com/newsgraphics/2013/12/30/year-in-interactive-storytelling/" target="_blank">2013: The Year in Interactive Storytelling</a>. The trouble is, before Aesop arrived on the scene, creating posts in story format required quite a bit of custom work in order to make it easy for publishers.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/story.png" rel="prettyphoto[14827]"><img src="http://wptavern.com/wp-content/uploads/2014/01/story.png" alt="story" width="1600" height="993" class="aligncenter size-full wp-image-14014" /></a></p>
<p>Haskins has now launched a crowdfunding campaign to help him take the fully working beta and make it a reality for more people to use. He believes that Aesop is an important project that can fundamentally change how publishers build stories: </p>
<blockquote><p>We have entered an age where publishers are seeking new methods of keeping readers engaged. We are already witnessing story, after story, after story, after story being released that really push the boundaries of what the web can do. And, we are reading that it takes 16 people 6 months to create these things. Not with Aesop. The engine can be used by anybody, without any code, and you can build stories by yourself, within minutes. All for free, fully GPL, within WordPress.</p></blockquote>
<p>The $15,000 he&#8217;s raising will go towards forming a business, finishing the <a href="http://aesopstories.com/" target="_blank">hosted version of Aesop</a>, hiring another developer to help improve the plugin, and a few other odds and ends required for getting it officially launched. </p>
<p>If Aesop reaches its stretch goal of $20,000, Haskins plans to run a &#8220;Theme Bounty,&#8221; to offer monetary rewards for themes that incorporate Aesop Story Engine. He also plans to establish an Aesop Marketplace for themes built just for Aesop.</p>
<p>Check out Haskin&#8217;s <a href="http://playground.aesopstories.com/" target="_blank">live demos</a> if you want to see what he&#8217;s created, or <a href="https://github.com/bearded-avenger/aesop-core" target="_blank">download the plugin</a> for yourself to take it for a test drive. If you&#8217;d like to see the Aesop plugin improved and believe in this new publishing tool, head on over to the <a href="https://aesop.crowdhoster.com/storytelling-engine" target="_blank">Aesop Crowdhoster</a> page and donate.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jan 2014 16:43:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WP iPhone: Upgrade to 3.8.6 for Reader Bug Fix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://wpiphone.wordpress.com/?p=1516";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://ios.wordpress.org/2013/12/30/upgrade-to-3-8-6-for-reader-bug-fix/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1713:"<p>WordPress for iOS 3.8.6 is out and now available to download from the App Store. This release is a hot fix release designed to fix a bug where the Reader would crash when loading a video.</p>
<h3>What’s next?</h3>
<p>We are almost done with the next major version of the app (3.9) which will have quite a few UI and UX changes that we hope will improve your experience with the app. This release (3.8.6) will be the last release to support iOS6 as with 3.9 and beyond we will only support iOS7 to allow us to take advantage of the latest technologies and provide you our users with the best app possible. You can get a sneak peek of what&#8217;s coming <a href="https://github.com/wordpress-mobile/WordPress-iOS/issues?milestone=10&state=open">here</a>.</p>
<p>A huge thanks to the contributors who worked on this release: <a href="http://github.com/koke">@koke</a> and <a href="http://github.com/aerych">@aerych</a>. If you would like to get involved with WordPress for iOS development, drop us a line at <a href="http://make.wordpress.org/mobile">make.wordpress.org/mobile</a> and grab a copy of the code at <a href="http://github.com/wordpress-mobile/WordPress-iOS">github.com/wordpress-mobile/WordPress-iOS</a>.</p>
<p>Have feedback? Leave a comment below or tweet us <a href="https://twitter.com/WordPressiOS">@WordPressiOS</a></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wpiphone.wordpress.com/1516/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wpiphone.wordpress.com/1516/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=ios.wordpress.org&blog=3882653&post=1516&subd=wpiphone&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jan 2014 13:45:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Sendhil";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WP iPhone: Upgrade to 3.8.5 for Various Bug Fixes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://wpiphone.wordpress.com/?p=1512";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://ios.wordpress.org/2013/12/10/upgrade-to-3-8-5-for-various-bug-fixes/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2241:"<p>WordPress for iOS 3.8.5 is out and now available to download from the App Store. This release is primarily a bug fix release.</p>
<p>Some of the fixes included in this version are:</p>
<ul>
<li>Fixed a crash when loading the posts view.</li>
<li>Fixed a crash when opening Reader comments.</li>
<li>Fixed a Jetpack connectivity issue.</li>
</ul>
<p><a href="https://github.com/wordpress-mobile/WordPress-iOS/issues?milestone=9&page=1&state=closed">Full list of changes in version 3.8.5</a></p>
<h3>What’s next?</h3>
<p>We are currently hard at work on the next major version of the app(3.9) which will have quite a few UI and UX changes that we hope will improve your experience with the app. We as a team have also decided to only support iOS7 going forward in order to allow us to take advantage of the latest technologies and provide you our users with the best app possible. If you want a sneak peek of what’s coming take a look <a href="https://github.com/wordpress-mobile/WordPress-iOS/issues?milestone=10&state=open">here</a>.</p>
<p>A huge thanks to the contributors who worked on this release: <a href="https://github.com/astralbodies">@astralbodies</a>, <a href="http://github.com/xtreme-rebecca-putinski">@xtreme-rebecca-putinski</a>, <a href="http://github.com/koke">@koke</a>, <a href="http://github.com/mikejohnstn">@mikejohnstn</a>, <a href="http://github.com/tomwitkin">@tomwitkin</a>, <a href="http://github.com/aerych">@aerych</a>. If you would like to get involved with WordPress for iOS development, drop us a line at <a href="http://make.wordpress.org/mobile">make.wordpress.org/mobile</a> and grab a copy of the code at <a href="http://github.com/wordpress-mobile/WordPress-iOS">github.com/wordpress-mobile/WordPress-iOS</a>.</p>
<p>Have feedback? Leave a comment below or tweet us <a href="https://twitter.com/WordPressiOS">@WordPressiOS</a></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wpiphone.wordpress.com/1512/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wpiphone.wordpress.com/1512/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=ios.wordpress.org&blog=3882653&post=1512&subd=wpiphone&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jan 2014 13:45:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Sendhil";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: Tax Day Release: WordPress 3.9 to Drop on April 15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14778";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:162:"http://wptavern.com/tax-day-release-wordpress-3-9-to-drop-on-april-15?utm_source=rss&utm_medium=rss&utm_campaign=tax-day-release-wordpress-3-9-to-drop-on-april-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2750:"<p>The date for the WordPress 3.9 release has now been set for April 15th, which coincides with <a href="http://en.wikipedia.org/wiki/Tax_day" target="_blank">tax day</a> in the US. American developers may want to do their taxes early, because the 3.9 release schedule will be keeping everyone busy. Tentative <a href="http://wordpress.org/about/roadmap/" target="_blank">dates</a> for the 4.0 and 4.1 releases are mid-August and early December, respectively.</p>
<p>The second order of business during the regularly scheduled WordPress dev meeting this week was to discuss <a href="http://make.wordpress.org/core/features-as-plugins/" target="_blank">feature plugins</a> that might be in the mix for 3.9. </p>
<h3>Possible Feature Plugins for 3.9</h3>
<p>Shaun Andrews mentioned that the Widgets UI Refresh team is working on the <a href="http://wptavern.com/the-future-of-wordpress-widgets-a-better-ui-with-real-time-previews" target="_blank">Widget Customizer</a> and believes it will be ready for 3.9. The <a href="http://wordpress.org/plugins/widget-customizer/" target="_blank">Widget Customizer</a> plugin offers live previews of widgets while you edit them and is available on WordPress.org if you&#8217;d like to help test it.</p>
<p>Shaun Andrews&#8217; <a href="http://wordpress.org/plugins/better-widgets" target="_blank">Better Widgets</a> plugin may also have enough momentum to make it into the 3.9 merge. These two widget-related plugins were the only ones mentioned in the meeting that might be ready for the feature review and merge process in 3.9, which should happen at the end of January into early February. The plugins are not guaranteed to be in 3.9 but they do have strong possibilities.</p>
<h3>Iterative Enhancements for Existing Features</h3>
<p>In addition to feature plugins, Nacin also identified a few areas where WordPress 3.9 could stand to iterate on previous releases: &#8220;<strong>Things like audio/video, even the theme browsing experience to the theme installer, are iterative and could totally take place in 3.9.</strong>&#8221; This is important because we can&#8217;t always focus on building shiny new features without looping back around to improve the ones we already have.</p>
<p>The development meeting concluded with a brainstorming session on how to make it easier for people to contribute to WordPress. All of the <a href="http://wptavern.com/wordpress-adds-per-ticket-notifications-to-trac" target="_blank">recent</a> <a href="http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements" target="_blank">improvements</a> to trac, especially the new reports and keyword designations, should help contributors to isolate and find tickets that they can jump in on.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jan 2014 01:30:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: Push Notifications From WordPress To Mac Via Push Monkey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14526";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:176:"http://wptavern.com/push-notifications-from-wordpress-to-mac-via-push-monkey?utm_source=rss&utm_medium=rss&utm_campaign=push-notifications-from-wordpress-to-mac-via-push-monkey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3985:"<p>When OS X Mavericks was released, one of the new features added to the operating system was <a title="https://developer.apple.com/notifications/safari-push-notifications/" href="https://developer.apple.com/notifications/safari-push-notifications/">Safari Push Notifications</a>. The notifications use the new Apple Push Notifications service to notify users of new events. Since the feature was added to OS X Mavericks, there have been a number of services built around it. <a title="http://wordpress.org/plugins/roost-for-bloggers/" href="http://wordpress.org/plugins/roost-for-bloggers/">Roost For Bloggers</a> is one such service. However, the one I&#8217;m reviewing today is called <a title="http://pushmonkey.launchrock.com/" href="http://pushmonkey.launchrock.com/">Push Monkey</a> by <a title="http://mowowstudios.com/" href="http://mowowstudios.com/">moWOW studios</a>.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/PushMonkeySubscribeNotice.png" rel="prettyphoto[14526]"><img class="aligncenter size-large wp-image-14756" alt="Push Monkey Subscription Notice" src="http://wptavern.com/wp-content/uploads/2014/01/PushMonkeySubscribeNotice-500x184.png" width="500" height="184" /></a></p>
<p>When Push Monkey is activated on the site and the domain is registered within the system, those who are using Mac OS X Mavericks and Safari 7 will see a notice asking if they would like to subscribe. Once subscribed to the site, they will receive new notifications each time a post is published. If the visitor chooses not the subscribe, they won&#8217;t be asked again. Posts that are already published or edited after being published will not generate a notification. Safari is used only for the initial subscription to the site. After that, notifications are received even when Safari is closed.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/PushMonkeySiteNotification.png" rel="prettyphoto[14526]"><img class="aligncenter size-large wp-image-14757" alt="Push Monkey Site Notification" src="http://wptavern.com/wp-content/uploads/2014/01/PushMonkeySiteNotification-500x158.png" width="500" height="158" /></a></p>
<p>Tudor Munteanu, one of the developers behind Push Monkey told me that while Safari is the only way to see the subscription notice, they have plans for more custom integration similar to <a title="http://www.macrumors.com/" href="http://www.macrumors.com/">Macrumors</a>. The reason why it&#8217;s not part of the initial offering is because it&#8217;s heavily dependent on the websites visual identity. Push Monkey is currently in the alpha stage of development with plans to have it finished by the end of this month. When I asked whether Push Monkey would be free to use, Tudor responded:</p>
<blockquote><p>It will most likely be a paid service. We do have some price points in mind, but the final values are not crystal clear. What we do know is that this price point is slightly under what we saw similar services asked for in the past. On top of that, for developers who have contacts to content publishers, we plan to have a very generous affiliate system.</p></blockquote>
<h3>Choices Are Abundant But I Have Questions</h3>
<p>During the time I&#8217;ve reviewed Push Monkey, I&#8217;ve received three other requests to review similar plugins and services. I didn&#8217;t realize there was so much demand for something that caters to a select demographic of website visitors. I don&#8217;t understand what the benefits are to using this notification system versus RSS, or something like <a title="http://code.google.com/p/pubsubhubbub/" href="http://code.google.com/p/pubsubhubbub/">PubHubSubHub</a> combined with the <a title="http://wordpress.org/plugins/pushpress/" href="http://wordpress.org/plugins/pushpress/">PuSHPress</a> plugin. The question I have for website owners is why would you cater to a specific audience instead of focusing on enabling anyone on any device to be able to receive real-time updates?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jan 2014 21:33:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: Official Git Mirror Now Available for WordPress Core Development Repository";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14741";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:214:"http://wptavern.com/official-git-mirror-now-available-for-wordpress-core-development-repository?utm_source=rss&utm_medium=rss&utm_campaign=official-git-mirror-now-available-for-wordpress-core-development-repository";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4560:"<p>Andrew Nacin <a href="http://make.wordpress.org/core/2014/01/15/git-mirrors-for-wordpress/" target="_blank">announced</a> official git mirrors for WordPress this afternoon on the WordPress make/core development blog. These are read-only mirrors that correspond to the WordPress core development SVN repository. Git mirrors are also now available for BuddyPress, bbPress, GlotPress and the old core.svn “build” repository:</p>
<pre>git clone git://develop.git.wordpress.org/
git clone git://buddypress.git.wordpress.org/
git clone git://bbpress.git.wordpress.org/
git clone git://core.git.wordpress.org/
git clone git://glotpress.git.wordpress.org/</pre>
<p>Needless to say, developers who contribute to WordPress and/or its major ancillary projects are thrilled:</p>
<blockquote class="twitter-tweet" lang="en"><p>Official GIt Mirrors for WordPress: <a href="http://t.co/nJUi3yK4EP">http://t.co/nJUi3yK4EP</a> Can I get a Hallelujah?</p>
<p>&mdash; Mike Schinkel (@mikeschinkel) <a href="https://twitter.com/mikeschinkel/statuses/423527837736255488">January 15, 2014</a></p></blockquote>
<p></p>
<blockquote class="twitter-tweet" lang="en"><p>Read make/core post by <a href="https://twitter.com/nacin">@nacin</a>. Wait for stream of praise and love in comments. rinse. repeat.</p>
<p>&mdash; Aaron Jorbin (@aaronjorbin) <a href="https://twitter.com/aaronjorbin/statuses/423528157300260864">January 15, 2014</a></p></blockquote>
<p></p>
<h3>Contributing to WordPress via Git</h3>
<p>When asked what the plan is for accepting pull request directly on Github, Nacin replied, &#8220;I’ve been studying how some other projects do or don’t do this. Something to discuss in a few months, I imagine.&#8221; </p>
<p>The current git contribution process is not quite as direct, but Nacin cites Scribu&#8217;s tutorial on <a href="http://scribu.net/wordpress/contributing-to-wordpress-using-github.html" target="_blank">Contributing To WordPress Using Github</a> as a place to get started.</p>
<h3>Future Mirrors for Plugin and Theme Repositories</h3>
<p>At the end of his announcement post, Nacin hints at the possibility of making git mirrors available for WordPress plugins and themes:</p>
<blockquote><p>There are a lot of other repositories on WordPress.org not yet mirrored. Notably: plugins and themes. These are massive multi-project repositories and will require a bit more investment.</p></blockquote>
<p>An undertaking like this has the potential to please many more developers, as those who contribute to the WordPress core are still a relatively small number compared to those with active extensions on WordPress.org.</p>
<h3>Is WordPress Moving Away From SVN?</h3>
<p>Some of you might be wondering whether the new git mirrors are an indication that WordPress will eventually abandon SVN entirely in favor of git somewhere further down the road. That doesn&#8217;t seem to be the case, as Nacin replied on <a href="http://make.wordpress.org/core/2014/01/15/git-mirrors-for-wordpress/#comment-12428" target="_blank">comments</a> to his post:</p>
<blockquote><p>If you or your tools want to use Git, you should be able to. If you or your tools want to use SVN, you should be able to. You could think of it as a desire to be VCS agnostic.</p></blockquote>
<p>I interviewed Nacin briefly to ask him if the project is committed to keeping both version control options available in the future. He confirmed that SVN is going nowhere anytime soon but rather that the project is committed to letting developers choose:</p>
<blockquote><p>We&#8217;re definitely committed to keeping both options available. Some developers are simply more used to X, or find X simpler, or find X cryptic/convoluted/difficult. I use both daily. With both options available, developers can use what they are most comfortable with or what fits best with their project, client, or company. There&#8217;s no need to force everyone to pick one, and there are a lot of tools and scripts people already use to interact with these SVN repositories, too. It just doesn&#8217;t make sense to not mirror between them for the long term.</p></blockquote>
<p>For the next week it will be in beta, so there may be a few bugs that need to be ironed out. Hopefully, these new git mirrors will open up the doors for contributors to push more enhancements and fixes to the WordPress project. Given the massive popularity of git, we may look back to this time as a pivotal moment. For right now, suffice to say that these new git mirrors just made a ton of WordPress developers very happy.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jan 2014 21:19:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Google Releases Its First Plugin For WordPress Publishers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14707";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/google-releases-its-first-plugin-for-wordpress-publishers?utm_source=rss&utm_medium=rss&utm_campaign=google-releases-its-first-plugin-for-wordpress-publishers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4209:"<p>Google released its first plugin for self-hosted WordPress sites today. <a href="http://wordpress.org/plugins/google-publisher/" target="_blank">Google Publisher</a> is now in beta and available on WordPress.org. The WordPress community is invited to test it out.</p>
<p>So far, the plugin includes two main features:</p>
<ul>
<li>Easily add AdSense ads to your site to make money from advertising.</li>
<li>Verify your site with Webmaster Tools with just one click.</li>
</ul>
<p>I tested the plugin this morning so we could take a tour. Even though they&#8217;re calling this a beta, it seems to work fairly smoothly out of the box.</p>
<h3>Quick Tour of the Google Publisher Plugin</h3>
<p>After installing Google Publisher, I found its options under <strong>Settings >> Google Publisher</strong>. Naturally, you&#8217;re going to need to sign in with Google to use it.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/google-publisher.jpg" rel="prettyphoto[14707]"><img src="http://wptavern.com/wp-content/uploads/2014/01/google-publisher.jpg" alt="google-publisher" width="715" height="322" class="aligncenter size-full wp-image-14713" /></a></p>
<h4>Verify With Google Webmaster Tools in 1 Click</h4>
<p>Perhaps the most appealing feature of this plugin is the ability to get your site verified with Google Webmaster with just one click. For years we&#8217;ve seen tutorials about how to integrate Google AdSense and Webmaster Tools with WordPress. This plugin provides the easiest way I&#8217;ve seen so far to get your site verified by Google Webmaster Tools. There are no codes to add to your site and no lengthy verification process. Google makes it very convenient; simply authenticate and then you&#8217;re verified.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/verified1.jpg" rel="prettyphoto[14707]"><img src="http://wptavern.com/wp-content/uploads/2014/01/verified1.jpg" alt="verified" width="676" height="342" class="aligncenter size-full wp-image-14735" /></a></p>
<p>The &#8216;manage&#8217; button that you see ensures that you are always just one click away from viewing the Google Webmaster Tools dashboard for your site. From there you can easily check on crawl errors, search queries, find out who links to you, submit a sitemap and more.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/webmaster-tools1.jpg" rel="prettyphoto[14707]"><img src="http://wptavern.com/wp-content/uploads/2014/01/webmaster-tools1.jpg" alt="webmaster-tools" width="1002" height="490" class="aligncenter size-full wp-image-14739" /></a></p>
<h4>Click to Place Google AdSense Ads</h4>
<p>Since I don&#8217;t participate in AdSense, I wasn&#8217;t able to test drive that portion. However, the plugin&#8217;s details page gives you a good idea of what this feature includes. Google Publisher provides an interactive way to place ads in your page templates by simply clicking:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/click-to-add-google-adsense.png" rel="prettyphoto[14707]"><img src="http://wptavern.com/wp-content/uploads/2014/01/click-to-add-google-adsense.png" alt="click-to-add-google-adsense" width="1024" height="670" class="aligncenter size-full wp-image-14724" /></a></p>
<p>You can also preview example advertisements alongside your content before placing them there:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/preview.png" rel="prettyphoto[14707]"><img src="http://wptavern.com/wp-content/uploads/2014/01/preview.png" alt="preview" width="1024" height="670" class="aligncenter size-full wp-image-14725" /></a></p>
<p>Please be advised that the plugin is in beta and the Google development team is still fine-tuning it to work with publishers&#8217; needs. It will be interesting to see how well Google supports its first WordPress plugin. Will Google provide support on WordPress.org or will it limit support to the Google help center? Will they pack this plugin full of new features for publishers further down the road? Only time will tell. Download <a href="http://wordpress.org/plugins/google-publisher/" target="_blank">Google Publisher</a> to take it for a test drive and let us know what you think.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jan 2014 18:42:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WPTavern: Blogly: A Free Personal Blogging Theme For WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14680";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:166:"http://wptavern.com/blogly-a-free-personal-blogging-theme-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=blogly-a-free-personal-blogging-theme-for-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3378:"<p>Blogly is a new flat style, responsive WordPress theme designed for personal blogging. The design sports bright colors and a traditional blog layout with a left sidebar. Blogly responds nicely on mobile devices and also includes support for post formats.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/blogly-lite.png" rel="prettyphoto[14680]"><img src="http://wptavern.com/wp-content/uploads/2014/01/blogly-lite.png" alt="blogly-lite" width="613" height="660" class="aligncenter size-full wp-image-14687" /></a></p>
<p>If your new year&#8217;s resolution includes firing up your personal blog again, then Blogly might be a strong option for you. Customization options and feature include:</p>
<ul>
<li>FontAwesome Icons</li>
<li>Widgetized Areas</li>
<li>Upload Custom Background Images</li>
<li>Theme Customizer</li>
<li>Change Site Colors</li>
<li>Upload Custom Header Logo</li>
<li>Upload Custom Footer Logo</li>
<li>Easily Change Footer Text</li>
<li>Built-In Pagination</li>
<li>Fully Localized Theme for Translation</li>
</ul>
<p><a href="http://wordpress.org/themes/blogly-lite" target="_blank">Blogly-Lite</a> is the free version on WordPress.org and a <a href="http://themefurnace.com/blog/portfolio/Blogly/" target="_blank">commercial version</a> is available from ThemeFurnace. For $49 customers will receive additional options such as Google fonts, custom widgets for Dribbble, Social Media, Flickr, Advertising as well as support.</p>
<p>The theme&#8217;s author, Oli Dale, says that Blogly is the first of many themes that will be built in the same way:</p>
<blockquote><p>Blogly is our first in our new generation of WordPress themes which have been re-built from the ground up to be extremely lightweight and easy to use.</p></blockquote>
<p>One by one, WordPress theme authors are starting to apply the art of minimalism to the administration of their themes in the admin panel, creating fewer options that are easier to use.</p>
<h3>All Theme Options Built Into the Customizer</h3>
<p>All the options for the theme can be found in the native WordPress theme customizer. Putting everything in the customizer is a growing trend among WordPress theme developers, although many just provide a handful of basic options. That&#8217;s why I appreciate the fact that Blogly also adds the ability to upload a site logo.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/logo.png" rel="prettyphoto[14680]"><img src="http://wptavern.com/wp-content/uploads/2014/01/logo.png" alt="logo" width="613" height="512" class="aligncenter size-full wp-image-14682" /></a></p>
<p>So far Blogly is one of the most comprehensive themes when it comes to building options into WordPress&#8217; customizer. Dale says he&#8217;s committed to building themes like this in the future:</p>
<blockquote><p>I like the change in approach away from a dedicated options panel, the theme should be a lot easier to customize visually with the theme customizer and I will be doing all my themes this way in future.</p></blockquote>
<p>Check out a <a href="http://themefurnace.com/themes/?theme=Blogly" target="_blank">live demo</a> to see Blogly in action or take it for a spin on your own site. You can download <a href="http://wordpress.org/themes/blogly-lite" target="_blank">Blogly Lite</a> for free from WordPress.org via your WordPress admin themes panel. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jan 2014 13:37:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: WordPress Managed Host NodeKi Goes Bust: No Refunds For Lifetime Customers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=14655";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:210:"http://wptavern.com/wordpress-managed-host-nodeki-goes-bust-no-refunds-for-lifetime-customers?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-managed-host-nodeki-goes-bust-no-refunds-for-lifetime-customers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3844:"<p>As of February 1st, 2014, <a href="http://nodeki.com/" target="_blank">NodeKi</a> Managed WordPress hosting company will be shutting down, citing their lifetime plans as a contributing factor. The NodeKi management team sent out an email to all of their customers today to inform them of the situation:</p>
<blockquote><p>Dear Sir/Madam,<br />
As of February 1st, 2014, NodeKi will permanently be going out of business. We want to inform you in advance that the NodeKi lifetime plans and server will cease to exist on Feburary 1st of 2014.</p>
<p>Unfortunately, the “Lifetime” plans were not a sustainable business model. We can’t continue paying for servers, software, bandwidth and support if there’s no incoming money to cover these costs. It’s not remotely possible to provide any product “for life” that has recurring costs associated with it. The Lifetime plans were not something that the existing management implemented, sold, or received money for. Due to this reason and the “no refund” policy at purchase, we are not able to offer refunds. This is not something that is open to debate.</p>
<p>LIMITED support (password resets and MINOR server related issues) will be provided on a best effort basis up until the shut down time. We have provided a two week timeframe so that you can move your domains and websites to a new provider.</p>
<p>Thank you for your support in the previous years.</p>
<p>Respectfully,<br />
NodeKi Management</p></blockquote>
<p>Last year after NodeKi launched its new plans, it was <a href="https://twitter.com/danbutcher/status/324504968201641984" target="_blank">bought out</a> by <a href="https://twitter.com/IQCorp" target="_blank">InterQuad corporation</a>, a holding company for other brands, leaving some to wonder if this was planned from the outset. Prior to that NodeKi had launched with Lifetime WordPress Hosting packages starting at just $39.00 USD, which were offered as an early bird discount. Customers who originally purchased NodeKi&#8217;s Lifetime Plan are <a href="http://premium.wpmudev.org/blog/never-buy-hosting-again-nodeki-offers-lifetime-wordpress-hosting-plans/#comment-147361" target="_blank">furious</a>. They were promised that they would never have to buy WordPress hosting again and paid the extra cost for lifetime service. </p>
<p>Using the Internet Archive, I was able to find an <a href="https://web.archive.org/web/20120331214929/http://my.nodeki.com/cart.php?gid=1" target="_blank">archived page</a> of their original <a href="http://my.nodeki.com/cart.php?gid=1" target="_blank">Lifetime plan pricing structure</a>.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/01/lifetime-plans.jpg" rel="prettyphoto[14655]"><img src="http://wptavern.com/wp-content/uploads/2014/01/lifetime-plans.jpg" alt="lifetime-plans" width="746" height="642" class="aligncenter size-full wp-image-14661" /></a></p>
<h3>What Went Wrong at NodeKi?</h3>
<p>There&#8217;s no shortage of demand for managed WordPress hosting in the WordPress ecosystem. GoDaddy will be launching a managed WordPress product this week and managed WordPress host <a href="http://wpengine.com/2014/01/14/wp-engine-raises-15-million-accelerate-growth-innovation/" target="_blank">WP Engine just scooped up $15 million dollars</a> in venture capital today to help fund the company&#8217;s rapid growth. </p>
<p>What caused NodeKi to shut down? The email hints at a major problem with its pricing structure. If NodeKi collapsed under the weight of its profitless lifetime hosting plans, that seems to indicate that there wasn&#8217;t a huge demand for the recurring plans that were subsequently released. Monetarily, it&#8217;s not a huge loss for a customer, but it is a major disappointment and inconvenience for those who put their faith in the company&#8217;s long term vision. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Jan 2014 23:46:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 26 Jan 2014 14:23:55 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"220726";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Sun, 26 Jan 2014 14:00:14 GMT";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (494, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1390789436', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (495, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1390746236', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (496, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1390789436', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (497, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 26 Jan 2014 14:15:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your Wordpress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Wordfence Security is a free enterprise class security plugin that includes a firewall, virus scanning, real-time traffic with geolocation and more.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-PageNavi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wp-pagenavi/#post-363";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 23:17:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"363@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:49:"Adds a more advanced paging navigation interface.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Lester Chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:122:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 7.5 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Better WP Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:107:"The easiest, most effective way to secure WordPress. Improve the security of any WordPress site in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"50539@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:111:"Google Analytics Dashboard for WP will display Google Analytics data and statistics inside your WordPress Blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Captcha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/captcha/#post-26129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Apr 2011 05:53:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26129@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"This plugin allows you to implement super security captcha form into web forms.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 26 Jan 2014 14:23:56 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 01 Jan 2009 20:34:44 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (498, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1390789436', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (499, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1390746236', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (500, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1390789436', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (501, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/01/wordpress-3-8-1/\' title=\'After six weeks and more than 9.3 million downloads of WordPress 3.8, we’re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query […]\'>WordPress 3.8.1 Maintenance Release</a> <span class="rss-date">January 23, 2014</span><div class=\'rssSummary\'>After six weeks and more than 9.3 million downloads of WordPress 3.8, we’re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query […]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/01/25/david-lockie-10-ways-that-wordpressers-can-make-the-world-a-better-place/\' title=\'    \'>WordPress.tv: David Lockie: 10 Ways That WordPressers Can Make The World A Better Place</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/01/25/hristo-pandjarov-need-for-speed-gear-up-your-wordpress/\' title=\'    \'>WordPress.tv: Hristo Pandjarov: Need For Speed: Gear Up Your WordPress</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/wpweekly-episode-135-podcasting-with-wordpress?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wpweekly-episode-135-podcasting-with-wordpress\' title=\'In this episode of WordPress Weekly, I was joined by Marcus Couch and Matt Medeiros of Mattreport.com and founder of Slocumstudio.com. I threw out the show notes for this episode and instead, tapped into the collective knowledge of my guests to discuss the world of podcasting with WordPress. The first part of the conversation covers equipment, audio quality, and audience while the second half focuses on WordPress. One thing immediately became clear. We’re all fans of the Blubrry Powerpress plugin. If you’re thinking about starting a show and using WordPress to publish it, you’ll want to listen to this episode! Stories Discussed: WordPress Developers Take Note: TinyMCE 4.0 Merged Into Core Interview With Jason Schuller Founder Of Press75.com Tickets On Sale For WordCamp Dayton, Ohio WordPress 3.8.1 Released: Fixes Twitter oEmbed Issues Plugins Picked By Marcus: Google Drive WP Media allows direct access to your Google Drive, enabling you to manage your files remotely from your WordPress blog. Upload and share your files directly from your WordPress blog to Google Drive and back again. Skype Mobile Switcher uses a shortcode to switch between presenting a Skype call link and a phone number that can be clicked to call.  Dynamic Home Length adjusts the number of posts per page of the front page based on the total amount of text in all recent posts so that its height will automatically be in proportional with the height of your widget column. WPWeekly Meta: Next Episode: Friday, January 31st 3 P.M. Eastern Subscribe To WPWeekly Via Itunes: Click here to subscribe Subscribe To WPWeekly Via RSS: Click here to subscribe Subscribe To WPWeekly Via Stitcher Radio: Click here to subscribe Listen To Episode #135: \'>WPTavern: WPWeekly Episode 135 – Podcasting With WordPress</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/wordfence/\' class=\'dashboard-news-plugin-link\'>Wordfence Security</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=wordfence&amp;_wpnonce=054a3925a5&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Wordfence Security\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (502, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1390757045', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (503, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (511, 'hmbkp_default_path', '/Applications/MAMP/htdocs/allisongrayce.com/wp-content/backupwordpress-49a9ca7ed6-backups', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (512, 'hmbkp_path', '/Applications/MAMP/htdocs/allisongrayce.com/wp-content/backupwordpress-49a9ca7ed6-backups', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (514, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (515, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (516, 'hmbkp_plugin_version', '2.4.1', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (517, '_transient_timeout_hmbkp_plugin_data', '1390833773', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (518, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":19:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:5:"2.4.1";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:37:"http://profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:39:"http://profiles.wordpress.org/humanmade";s:7:"willmot";s:37:"http://profiles.wordpress.org/willmot";s:13:"pauldewouters";s:43:"http://profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:38:"http://profiles.wordpress.org/joehoyle";s:7:"mattheu";s:37:"http://profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:39:"http://profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.3.3";s:6:"tested";s:5:"3.8.1";s:13:"compatibility";a:30:{s:5:"2.8.5";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:3:"2.9";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"2.9.1";a:1:{s:5:"0.4.5";a:3:{i:0;i:67;i:1;i:6;i:2;i:4;}}s:5:"2.9.2";a:1:{s:5:"0.4.5";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}}s:3:"3.0";a:2:{s:5:"0.4.5";a:3:{i:0;i:80;i:1;i:5;i:2;i:4;}s:5:"1.1.4";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:5:"3.0.1";a:1:{s:5:"0.4.5";a:3:{i:0;i:56;i:1;i:9;i:2;i:5;}}s:5:"3.0.2";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.3";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.4";a:2:{s:5:"0.4.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.1.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.5";a:1:{s:5:"0.4.5";a:3:{i:0;i:33;i:1;i:3;i:2;i:1;}}s:3:"3.1";a:9:{s:5:"0.4.5";a:3:{i:0;i:57;i:1;i:7;i:2;i:4;}s:5:"1.0.3";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.0.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.0.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:3:"1.1";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.1.1";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.1.2";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.1.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.1.4";a:3:{i:0;i:50;i:1;i:4;i:2;i:2;}}s:5:"3.1.1";a:1:{s:5:"1.1.4";a:3:{i:0;i:90;i:1;i:10;i:2;i:9;}}s:5:"3.1.2";a:3:{s:5:"1.1.4";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:3:"1.2";a:3:{i:0;i:100;i:1;i:5;i:2;i:5;}s:3:"1.3";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}}s:5:"3.1.3";a:2:{s:3:"1.3";a:3:{i:0;i:67;i:1;i:6;i:2;i:4;}s:5:"1.3.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}}s:3:"3.2";a:3:{s:5:"0.1.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.3.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"1.6.2";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:5:"3.2.1";a:15:{s:5:"1.3.1";a:3:{i:0;i:67;i:1;i:9;i:2;i:6;}s:5:"1.3.2";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:8:"1.4 beta";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.4.1";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}s:3:"1.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.5.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:3:"1.6";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.4";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.1.3";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"2.2.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.2.4";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:3:"3.3";a:6:{s:3:"1.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.5.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.3.1";a:7:{s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:80;i:1;i:5;i:2;i:4;}s:5:"1.6.4";a:3:{i:0;i:100;i:1;i:9;i:2;i:9;}s:5:"1.6.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.6.6";a:3:{i:0;i:63;i:1;i:19;i:2;i:12;}s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:8;i:2;i:8;}}s:5:"3.3.2";a:3:{s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:5;i:2;i:5;}s:5:"1.6.8";a:3:{i:0;i:92;i:1;i:12;i:2;i:11;}s:5:"2.1.3";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:3:"3.4";a:1:{s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:5:"3.4.1";a:2:{s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:12;i:2;i:12;}s:5:"1.6.9";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:5:"3.4.2";a:9:{s:5:"1.6.9";a:3:{i:0;i:83;i:1;i:6;i:2;i:5;}s:8:"2.0 RC 1";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"2.0.1";a:3:{i:0;i:45;i:1;i:22;i:2;i:10;}s:5:"2.0.3";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"2.0.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.0.6";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:3:"2.1";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.1.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"2.1.3";a:3:{i:0;i:83;i:1;i:6;i:2;i:5;}}s:3:"3.5";a:1:{s:5:"2.1.3";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}}s:5:"3.5.1";a:5:{s:5:"2.1.3";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:3:"2.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.2.1";a:3:{i:0;i:100;i:1;i:10;i:2;i:10;}s:5:"2.2.4";a:3:{i:0;i:94;i:1;i:16;i:2;i:15;}s:3:"2.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.5.2";a:3:{s:5:"2.2.4";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:3:"2.3";a:3:{i:0;i:57;i:1;i:14;i:2;i:8;}s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}}s:3:"3.6";a:2:{s:3:"2.3";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"2.3.3";a:3:{i:0;i:50;i:1;i:6;i:2;i:3;}}s:5:"3.6.1";a:1:{s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}}s:3:"3.7";a:2:{s:5:"2.3.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.7.1";a:1:{s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:3:"3.8";a:3:{s:5:"2.3.3";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:3:"2.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.4.1";a:3:{i:0;i:75;i:1;i:4;i:2;i:3;}}}s:6:"rating";d:91.19999999999998863131622783839702606201171875;s:11:"num_ratings";i:594;s:10:"downloaded";i:806389;s:12:"last_updated";s:10:"2014-01-15";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:30:"http://hmn.md/backupwordpress/";s:8:"sections";a:5:{s:11:"description";s:1284:"<p>BackUpWordPress will back up your entire site including your database and all your files on a schedule that suits you.</p>

<h4>Features</h4>

<ul>
<li>Manage multiple schedules.</li>
<li>Super simple to use, no setup required.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster back ups if they are available.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your back ups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:705:"<ol>
	<li>
		<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=834447\' alt=\'backupwordpress screenshot 1\' />
		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=834447\' alt=\'backupwordpress screenshot 2\' />
		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=834447\' alt=\'backupwordpress screenshot 3\' />
		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:28468:"<h4>2.4.1</h4>

<ul>
<li>Add missing colorbox images</li>
</ul>

<h4>2.4</h4>

<ul>
<li>Support for new premium extensions for storing backups in a variety of online services.</li>
<li>Exclude the WP DB Manager backups and WP Super Cache cache directories by default.</li>
<li>We now use Intercom to offer support directly from within the plugin, opt-in of course.</li>
<li>More i18n fixes / improvements.</li>
<li>We no longer show download links if your backups directory isn\'t web accessible.</li>
<li>Fix a bug that caused the plugin activation and deactivation hooks from firing.</li>
<li>Correctly handle <code>MYSQL TIMESTAMP</code> columns in database dumps.</li>
<li><code>mysqldump</code> and <code>zip</code> are now correctly recognised on SmartOS.</li>
<li>Schedule names are now translatable.</li>
<li>Avoid having to re-calculate the filesize when a schedules type is set.</li>
<li>Compatibility with WordPress 3.8</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number.</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error.</li>
<li>Save and close as separate buttons.</li>
<li>Fix bug that caused multiple notification emails.</li>
<li>Fixes typo in database option name.</li>
<li>Updated translations.</li>
<li>Improve PHP docblocks.</li>
<li>Make schedules class a singleton.</li>
<li>Exclude popular backup plugin folders by default.</li>
<li>Exclude version control folders by default.</li>
<li>Fix broken localisation.</li>
<li>Use <code>wp_safe_redirect</code> instead of <code>wp_redirect</code> for internal form submissions</li>
<li></li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4053:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.4.1.zip";s:4:"tags";a:10:{s:7:"archive";s:7:"archive";s:7:"back-up";s:7:"back up";s:6:"backup";s:6:"backup";s:7:"backups";s:7:"backups";s:8:"database";s:8:"database";s:2:"db";s:2:"db";s:5:"files";s:5:"files";s:9:"humanmade";s:9:"humanmade";s:6:"wp-cli";s:6:"wp-cli";s:3:"zip";s:3:"zip";}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (519, '_transient_timeout_hmbkp_schedule_support_complete_filesize', '2781581148', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (520, '_transient_hmbkp_schedule_support_complete_filesize', '44160787', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (521, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2781581148', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (522, '_transient_hmbkp_schedule_default-1_database_filesize', '1277952', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (525, '_transient_timeout_settings_errors', '1390750039', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (526, '_transient_settings_errors', 'a:1:{i:0;a:4:{s:7:"setting";s:7:"general";s:4:"code";s:16:"settings_updated";s:7:"message";s:15:"Settings saved.";s:4:"type";s:7:"updated";}}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (530, 'wpseo', 'a:6:{s:20:"disableadvanced_meta";s:2:"on";s:7:"version";s:6:"1.4.24";s:11:"theme_check";a:1:{s:11:"description";b:1;}s:14:"tracking_popup";s:4:"done";s:14:"yoast_tracking";s:2:"on";s:11:"ignore_tour";s:6:"ignore";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (531, 'wpseo_titles', 'a:15:{s:10:"title-home";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:12:"title-author";s:42:"%%name%%, Author at %%sitename%% %%page%% ";s:13:"title-archive";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:12:"title-search";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:9:"title-404";s:35:"Page Not Found %%sep%% %%sitename%%";s:15:"noindex-archive";s:2:"on";s:19:"noindex-post_format";s:2:"on";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:10:"title-work";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:18:"title-testimonials";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:14:"title-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:14:"title-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:17:"title-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (532, 'wpseo_xml', 'a:2:{s:16:"enablexmlsitemap";s:2:"on";s:36:"post_types-attachment-not_in_sitemap";b:1;}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (533, 'wpseo_social', 'a:1:{s:9:"opengraph";s:2:"on";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (534, 'wpseo_rss', 'a:1:{s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (535, 'wpseo_permalinks', 'a:1:{s:10:"cleanslugs";s:2:"on";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (536, 'rewrite_rules', 'a:96:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:32:"work/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"work/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"work/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"work/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"work/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:25:"work/([^/]+)/trackback/?$";s:31:"index.php?work=$matches[1]&tb=1";s:33:"work/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?work=$matches[1]&paged=$matches[2]";s:40:"work/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?work=$matches[1]&cpage=$matches[2]";s:25:"work/([^/]+)(/[0-9]+)?/?$";s:43:"index.php?work=$matches[1]&page=$matches[2]";s:21:"work/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"work/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"work/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"work/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"work/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"testimonials/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"testimonials/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"testimonials/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"testimonials/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"testimonials/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"testimonials/([^/]+)/trackback/?$";s:39:"index.php?testimonials=$matches[1]&tb=1";s:41:"testimonials/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?testimonials=$matches[1]&paged=$matches[2]";s:48:"testimonials/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?testimonials=$matches[1]&cpage=$matches[2]";s:33:"testimonials/([^/]+)(/[0-9]+)?/?$";s:51:"index.php?testimonials=$matches[1]&page=$matches[2]";s:29:"testimonials/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"testimonials/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"testimonials/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"testimonials/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"testimonials/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (539, 'agca_role_allbutadmin', 'true', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (540, 'agca_screen_options_menu', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (541, 'agca_help_menu', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (542, 'agca_logout', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (543, 'agca_remove_your_profile', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (544, 'agca_logout_only', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (545, 'agca_options_menu', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (546, 'agca_custom_title', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (547, 'agca_howdy', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (548, 'agca_header', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (549, 'agca_header_show_logout', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (550, 'agca_footer', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (551, 'agca_privacy_options', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (552, 'agca_header_logo', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (553, 'agca_header_logo_custom', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (554, 'agca_wp_logo_custom', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (555, 'agca_remove_site_link', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (556, 'agca_wp_logo_custom_link', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (557, 'agca_site_heading', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (558, 'agca_custom_site_heading', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (559, 'agca_update_bar', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (560, 'agca_footer_left', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (561, 'agca_footer_left_hide', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (562, 'agca_footer_right', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (563, 'agca_footer_right_hide', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (564, 'agca_login_banner', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (565, 'agca_login_banner_text', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (566, 'agca_login_photo_remove', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (567, 'agca_login_photo_url', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (568, 'agca_login_photo_href', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (569, 'agca_login_round_box', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (570, 'agca_login_round_box_size', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (571, 'agca_dashboard_icon', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (572, 'agca_dashboard_text', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (573, 'agca_dashboard_text_paragraph', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (574, 'agca_dashboard_widget_welcome', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (575, 'agca_dashboard_widget_activity', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (576, 'agca_dashboard_widget_il', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (577, 'agca_dashboard_widget_plugins', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (578, 'agca_dashboard_widget_qp', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (579, 'agca_dashboard_widget_rn', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (580, 'agca_dashboard_widget_rd', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (581, 'agca_dashboard_widget_primary', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (582, 'agca_dashboard_widget_secondary', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (583, 'agca_admin_bar_comments', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (584, 'agca_admin_bar_new_content', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (585, 'agca_admin_bar_new_content_post', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (586, 'agca_admin_bar_new_content_link', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (587, 'agca_admin_bar_new_content_page', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (588, 'agca_admin_bar_new_content_user', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (589, 'agca_admin_bar_new_content_media', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (590, 'agca_admin_bar_update_notifications', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (591, 'agca_remove_top_bar_dropdowns', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (592, 'agca_admin_bar_frontend', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (593, 'agca_admin_bar_frontend_hide', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (594, 'agca_login_register_remove', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (595, 'agca_login_register_href', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (596, 'agca_login_lostpassword_remove', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (597, 'agca_admin_capability', 'edit_dashboard', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (598, 'agca_disablewarning', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (599, 'agca_admin_menu_turnonoff', 'off', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (600, 'agca_admin_menu_agca_button_only', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (601, 'agca_admin_menu_separator_first', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (602, 'agca_admin_menu_separator_second', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (603, 'agca_admin_menu_icons', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (604, 'agca_admin_menu_collapse_button', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (605, 'agca_admin_menu_arrow', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (606, 'agca_admin_menu_submenu_round', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (607, 'agca_admin_menu_submenu_round_size', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (608, 'agca_admin_menu_brand', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (609, 'agca_admin_menu_brand_link', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (610, 'agca_admin_menu_autofold', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (611, 'ag_edit_adminmenu_json', '{"<-TOP->menu-dashboard" : "undefined", "Home" : "undefined", "Updates" : "undefined", "<-TOP->menu-posts" : "undefined", "All Posts" : "undefined", "Add New" : "undefined", "Categories" : "undefined", "Tags" : "undefined", "<-TOP->menu-media" : "checked", "Library" : "undefined", "Add New" : "undefined", "<-TOP->menu-pages" : "undefined", "All Pages" : "undefined", "Add New" : "undefined", "<-TOP->menu-comments" : "undefined", "<-TOP->menu-posts-work" : "undefined", "Work" : "undefined", "Add Project" : "undefined", "<-TOP->menu-posts-testimonials" : "undefined", "Testimonials" : "undefined", "Add Testimonial" : "undefined", "<-TOP->menu-appearance" : "checked", "Themes" : "undefined", "Customize" : "undefined", "Widgets" : "undefined", "Menus" : "undefined", "Editor" : "undefined", "<-TOP->menu-plugins" : "checked", "Installed Plugins" : "undefined", "Add New" : "undefined", "Editor" : "undefined", "<-TOP->menu-users" : "checked", "All Users" : "undefined", "Add New" : "undefined", "Your Profile" : "undefined", "<-TOP->menu-tools" : "checked", "Available Tools" : "undefined", "Import" : "undefined", "Export" : "undefined", "AG Custom Admin" : "undefined", "Backups" : "undefined", "<-TOP->menu-settings" : "checked", "General" : "undefined", "Writing" : "undefined", "Reading" : "undefined", "Discussion" : "undefined", "Media" : "undefined", "Permalinks" : "undefined", "Treehouse Badges" : "undefined", "Twiget Settings" : "undefined", "<-TOP->toplevel_page_edit-post_type-acf" : "checked", "Custom Fields" : "undefined", "Export" : "undefined", "Add-ons" : "undefined", "Upgrade" : "undefined", "<-TOP->toplevel_page_wpseo_dashboard" : "checked", "Dashboard" : "undefined", "Titles & Metas" : "undefined", "Social" : "undefined", "XML Sitemaps" : "undefined", "Permalinks" : "undefined", "Internal Links" : "undefined", "RSS" : "undefined", "Import & Export" : "undefined", "Edit Files" : "undefined", "<-TOP->toplevel_page_cpt_main_menu" : "checked", "CPT UI" : "undefined", "Add New" : "undefined", "Manage Post Types" : "undefined", "Manage Taxonomies" : "undefined"}|{"<-TOP->menu-dashboard" : "Dashboard", "Home" : "Home", "Updates" : "Updates ", "<-TOP->menu-posts" : "Posts", "All Posts" : "All Posts", "Add New" : "Add New", "Categories" : "Categories", "Tags" : "Tags", "<-TOP->menu-media" : "Media", "Library" : "Library", "Add New" : "Add New", "<-TOP->menu-pages" : "Pages", "All Pages" : "All Pages", "Add New" : "Add New", "<-TOP->menu-comments" : "Comments ", "<-TOP->menu-posts-work" : "Work", "Work" : "Work", "Add Project" : "Add Project", "<-TOP->menu-posts-testimonials" : "Testimonials", "Testimonials" : "Testimonials", "Add Testimonial" : "Add Testimonial", "<-TOP->menu-appearance" : "Appearance", "Themes" : "Themes", "Customize" : "Customize", "Widgets" : "Widgets", "Menus" : "Menus", "Editor" : "Editor", "<-TOP->menu-plugins" : "Plugins ", "Installed Plugins" : "Installed Plugins", "Add New" : "Add New", "Editor" : "Editor", "<-TOP->menu-users" : "Users", "All Users" : "All Users", "Add New" : "Add New", "Your Profile" : "Your Profile", "<-TOP->menu-tools" : "Tools", "Available Tools" : "Available Tools", "Import" : "Import", "Export" : "Export", "AG Custom Admin" : "AG Custom Admin", "Backups" : "Backups", "<-TOP->menu-settings" : "Settings", "General" : "General", "Writing" : "Writing", "Reading" : "Reading", "Discussion" : "Discussion", "Media" : "Media", "Permalinks" : "Permalinks", "Treehouse Badges" : "Treehouse Badges", "Twiget Settings" : "Twiget Settings", "<-TOP->toplevel_page_edit-post_type-acf" : "Custom Fields", "Custom Fields" : "Custom Fields", "Export" : "Export", "Add-ons" : "Add-ons", "Upgrade" : "Upgrade", "<-TOP->toplevel_page_wpseo_dashboard" : "SEO", "Dashboard" : "Dashboard", "Titles & Metas" : "Titles &amp; Metas", "Social" : "Social", "XML Sitemaps" : "XML Sitemaps", "Permalinks" : "Permalinks", "Internal Links" : "Internal Links", "RSS" : "RSS", "Import & Export" : "Import &amp; Export", "Edit Files" : "Edit Files", "<-TOP->toplevel_page_cpt_main_menu" : "CPT UI", "CPT UI" : "CPT UI", "Add New" : "Add New", "Manage Post Types" : "Manage Post Types", "Manage Taxonomies" : "Manage Taxonomies"}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (612, 'ag_add_adminmenu_json', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (613, 'ag_colorizer_json', '{"color_background" : "", "login_color_background" : "", "color_header" : "", "color_admin_menu_top_button_background" : "", "color_admin_menu_font" : "", "color_admin_menu_top_button_current_background" : "", "color_admin_menu_top_button_hover_background" : "", "color_admin_menu_submenu_border_top" : "", "color_admin_menu_submenu_border_bottom" : "", "color_admin_menu_submenu_background" : "", "color_admin_menu_submenu_background_hover" : "", "color_admin_submenu_font" : "", "color_admin_menu_behind_background" : "", "color_admin_menu_behind_border" : "", "color_font_content" : "", "color_font_header" : "", "color_font_footer" : "", "color_widget_bar" : "", "color_widget_background" : ""}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (614, 'agca_colorizer_turnonoff', 'off', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (615, 'agca_custom_js', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (616, 'agca_custom_css', '', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (619, '_transient_doing_cron', '1393525654.6099131107330322265625', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (626, '_site_transient_timeout_theme_roots', '1393527456', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (627, '_site_transient_theme_roots', 'a:4:{s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";s:11:"wpportfolio";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wpWPP_options` VALUES (628, '_transient_timeout_feed_4ab971b92254aae7e30a99c8056b68cb', '1393568856', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (629, '_transient_feed_4ab971b92254aae7e30a99c8056b68cb', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"
  
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:278:"
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Dribbble / Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:33:"http://dribbble.com/allisongrayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:35:"Dribbble - What are you working on?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-us";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:2:"Gr";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:350:"
        <a height="150" href="http://dribbble.com/shots/1319622-Gr" width="200"><img alt="Gr" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1319622/gr.jpg" width="400" /></a><p>Putting some finishing touches on my latest project... one I am very, very excited to launch here in the next couple of weeks! :)</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Nov 2013 00:55:44 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:36:"http://dribbble.com/shots/1319622-Gr";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:47:"http://dribbble.com/shots/1319622-Gr?1385013344";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Internal Dashboard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:328:"
        <a height="150" href="http://dribbble.com/shots/1239571-Internal-Dashboard" width="200"><img alt="Internal Dashboard" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1239571/internal_dashboard_2.jpg" width="400" /></a><p>Another shot from the internal dashboard I\'m working on! </p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Sep 2013 18:36:42 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://dribbble.com/shots/1239571-Internal-Dashboard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:63:"http://dribbble.com/shots/1239571-Internal-Dashboard?1379457402";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Internal Dashboard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:374:"
        <a height="150" href="http://dribbble.com/shots/1227642-Internal-Dashboard" width="200"><img alt="Internal Dashboard" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1227642/company-metrics.jpg" width="400" /></a><p>Working on an internal dashboard for a very fun client that\'s displays company wide projects and metrics :) </p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 08 Sep 2013 22:33:03 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://dribbble.com/shots/1227642-Internal-Dashboard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:63:"http://dribbble.com/shots/1227642-Internal-Dashboard?1378693983";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Polygonal Chair";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:343:"
        <a height="150" href="http://dribbble.com/shots/1156733-Polygonal-Chair" width="200"><img alt="Polygonal Chair" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1156733/abstract.jpg" width="400" /></a><p>Enjoying the simplicity of this latest project. Abstract shapes... bright colors... flat. </p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 15 Jul 2013 19:02:16 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://dribbble.com/shots/1156733-Polygonal-Chair";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:60:"http://dribbble.com/shots/1156733-Polygonal-Chair?1373929336";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Register or Log In";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:283:"
        <a height="150" href="http://dribbble.com/shots/1156724-Register-or-Log-In" width="200"><img alt="Register or Log In" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1156724/login.jpg" width="400" /></a><p>Just a little form action. </p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 15 Jul 2013 18:55:09 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://dribbble.com/shots/1156724-Register-or-Log-In";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:63:"http://dribbble.com/shots/1156724-Register-or-Log-In?1373928909";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Shopping Bag";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:316:"
        <a height="150" href="http://dribbble.com/shots/1140233-Shopping-Bag" width="200"><img alt="Shopping Bag" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1140233/shopping.jpg" width="400" /></a><p>Shopping bag mockup for a project I loveeeeed that wasn\'t developed. </p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 02 Jul 2013 16:24:47 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://dribbble.com/shots/1140233-Shopping-Bag";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:57:"http://dribbble.com/shots/1140233-Shopping-Bag?1372796687";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"The Anatomy of the Perfect Bag";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:439:"
        <a height="150" href="http://dribbble.com/shots/1140204-The-Anatomy-of-the-Perfect-Bag" width="200"><img alt="The Anatomy of the Perfect Bag" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1140204/perfect.jpg" width="400" /></a><p>A mockup of a "featured article" that never saw the light of day. Boo. Loved mixing the messy handwritten/brush type with elegant, simple type &amp; colors. </p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 02 Jul 2013 16:06:52 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://dribbble.com/shots/1140204-The-Anatomy-of-the-Perfect-Bag";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:75:"http://dribbble.com/shots/1140204-The-Anatomy-of-the-Perfect-Bag?1372795612";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Italian Favorites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:328:"
        <a height="150" href="http://dribbble.com/shots/1138657-Italian-Favorites" width="200"><img alt="Italian Favorites" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1138657/italianfavs.jpg" width="400" /></a><p>A peek of something fun I\'m working on with some really cool people!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 01 Jul 2013 19:10:25 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://dribbble.com/shots/1138657-Italian-Favorites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:62:"http://dribbble.com/shots/1138657-Italian-Favorites?1372720225";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Mixed Dough";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:315:"
        <a height="150" href="http://dribbble.com/shots/1138587-Mixed-Dough" width="200"><img alt="Mixed Dough" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1138587/untitled-2.jpg" width="400" /></a><p>A peek of something fun I\'m working on with some really cool people!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 01 Jul 2013 17:49:59 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://dribbble.com/shots/1138587-Mixed-Dough";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:56:"http://dribbble.com/shots/1138587-Mixed-Dough?1372715399";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"red rocks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:288:"
        <a height="150" href="http://dribbble.com/shots/1105772-red-rocks" width="200"><img alt="red rocks" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/1105772/redrock.jpg" width="400" /></a><p>Working on a fun new project. More details soon!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 07 Jun 2013 20:47:49 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:43:"http://dribbble.com/shots/1105772-red-rocks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:54:"http://dribbble.com/shots/1105772-red-rocks?1370652469";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Watercolored Workspace";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:526:"
        <a height="150" href="http://dribbble.com/shots/648778-Watercolored-Workspace" width="200"><img alt="Watercolored Workspace" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/648778/laptop.jpg" width="400" /></a><p>Working on a series of illustrations for a personal project. They all have this similar line drawn, watercolor wash type of style. </p>

<p>As you can see, I have some serious trouble staying inside the lines. And in my world I have way less tools in my toolbar. </p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Jul 2012 00:56:47 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://dribbble.com/shots/648778-Watercolored-Workspace";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:66:"http://dribbble.com/shots/648778-Watercolored-Workspace?1342501007";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Bakin&#039; a Website";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:361:"
        <a height="150" href="http://dribbble.com/shots/538647-Bakin-a-Website" width="200"><img alt="Bakin&#x27; a Website" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/538647/smellz.jpg" width="400" /></a><p>Designing a very simple website for Smells Like Bakin\' that <a>Treehouse</a> users will learn how to code.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 30 Apr 2012 14:43:19 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://dribbble.com/shots/538647-Bakin-a-Website";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:59:"http://dribbble.com/shots/538647-Bakin-a-Website?1335811399";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"You Bake Me Blush";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:323:"
        <a height="150" href="http://dribbble.com/shots/531870-You-Bake-Me-Blush" width="200"><img alt="You Bake Me Blush" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/531870/youbakemeblush.jpg" width="400" /></a><p>Having way too much fun with these puns for Smells Like Bakin\'</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 Apr 2012 14:38:34 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://dribbble.com/shots/531870-You-Bake-Me-Blush";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:61:"http://dribbble.com/shots/531870-You-Bake-Me-Blush?1335379114";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Smells Like Bakin&#039;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:342:"
        <a height="150" href="http://dribbble.com/shots/530320-Smells-Like-Bakin" width="200"><img alt="Smells Like Bakin&#x27;" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/530320/smellslikebacon.jpg" width="400" /></a><p>Creating a fictitious company for a project I\'m working on at Treehouse :D</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Apr 2012 17:02:32 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://dribbble.com/shots/530320-Smells-Like-Bakin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:61:"http://dribbble.com/shots/530320-Smells-Like-Bakin?1335301352";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"Yummicons";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:383:"
        <a height="150" href="http://dribbble.com/shots/521305-Yummicons" width="200"><img alt="Yummicons" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/521305/food-icons.jpg" width="400" /></a><p>Designed a few icons and recorded my process for one of my videos at <a href="http://www.teamtreehouse.com">Treehouse</a> on iconography. Yum!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Apr 2012 14:11:10 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://dribbble.com/shots/521305-Yummicons";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:53:"http://dribbble.com/shots/521305-Yummicons?1334772670";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"Code Racer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:515:"
        <a height="150" href="http://dribbble.com/shots/380445-Code-Racer" width="200"><img alt="Code Racer" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/380445/idea_week.png" width="400" /></a><p>It\'s Idea Week at Treehouse and we\'re designing and developing "Code Racer," a live-coding game that lets you compete against others to built a simple website. Along the way, "weapons" are unlocked that interrupt your enemies progress! Just finished designing the homepage.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Jan 2012 19:11:52 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:43:"http://dribbble.com/shots/380445-Code-Racer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:54:"http://dribbble.com/shots/380445-Code-Racer?1326240712";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Treehouse Badges";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:365:"
        <a height="150" href="http://dribbble.com/shots/302725-Treehouse-Badges" width="200"><img alt="Treehouse Badges" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/302725/badges.png" width="400" /></a><p>Sneak peek of some of the treehouse badges I\'ve been working on :) Kudos to Mike Kus for the awesome color scheme!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 26 Oct 2011 12:36:08 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://dribbble.com/shots/302725-Treehouse-Badges";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:60:"http://dribbble.com/shots/302725-Treehouse-Badges?1319646968";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Mobile Template";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:366:"
        <a height="150" href="http://dribbble.com/shots/272113-Mobile-Template" width="200"><img alt="Mobile Template" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/272113/mobile-hotel-mockup-dribbble.jpg" width="400" /></a><p>Designing a mobile template to be used mostly for hotels, while custom solution is in progress.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 20 Sep 2011 18:50:03 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://dribbble.com/shots/272113-Mobile-Template";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:59:"http://dribbble.com/shots/272113-Mobile-Template?1316559003";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Fashion Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:330:"
        <a height="150" href="http://dribbble.com/shots/267809-Fashion-Blog" width="200"><img alt="Fashion Blog" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/267809/iof.png" width="400" /></a><p>Working on a fashion blog that curates posts from all over the world. Way too much fun :)
</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 15 Sep 2011 20:36:46 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://dribbble.com/shots/267809-Fashion-Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:56:"http://dribbble.com/shots/267809-Fashion-Blog?1316133406";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"And They&#039;re Off!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:520:"
        <a height="150" href="http://dribbble.com/shots/236639-And-They-re-Off" width="200"><img alt="And They&#x27;re Off!" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/236639/wedding-invites.jpg" width="400" /></a><p>OK Last one for the invitations – I promise :) It\'s just been all that I\'m working on lately!</p>

<p>These are all the different pieces that are packaged together in the invitation. Now, time to stuff \'em, stamp \'em and send \'em out! Whew. FINALLY done!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 13 Aug 2011 14:01:27 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://dribbble.com/shots/236639-And-They-re-Off";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:59:"http://dribbble.com/shots/236639-And-They-re-Off?1313258487";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Firestarter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:382:"
        <a height="150" href="http://dribbble.com/shots/200156-Firestarter" width="200"><img alt="Firestarter" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/200156/bf-dribbble.jpg" width="400" /></a><p>Working on a Facebook application. Currently designing the dashboard UI which will have settings, alerts, stats, graphs, etc. Fun stuff!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 27 Jun 2011 10:42:04 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://dribbble.com/shots/200156-Firestarter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:55:"http://dribbble.com/shots/200156-Firestarter?1309185724";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Flockin&#039; Squish Test";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:446:"
        <a height="150" href="http://dribbble.com/shots/189718-Flockin-Squish-Test" width="200"><img alt="Flockin&#x27; Squish Test" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/189718/flockin.png" width="400" /></a><p>Designing a Facebook landing page for a restaurant client. Wish I could participate in the contest! Winner gets an all-inclusive stay in Cancun. That sounds amazing right about now. </p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Jun 2011 15:26:13 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://dribbble.com/shots/189718-Flockin-Squish-Test";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:63:"http://dribbble.com/shots/189718-Flockin-Squish-Test?1307733973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Throwbbback";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:882:"
        <a height="150" href="http://dribbble.com/shots/188363-Throwbbback" width="200"><img alt="Throwbbback" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/188363/throwbbback.jpg" width="400" /></a><p>These collages are from 2002, when I was sportin\' Photoshop 7.0 and my 15" (what I thought was a) flat screen monitor. I was 14 going on 15. </p>

<p>These were the days before clients, bosses and professors. The days where I spent hours looking for new brushes and textures and cool pictures to create digital collages with. Sometimes it felt more like art then. </p>

<p>Every so often I like to look back on my work from that time and re-inspire myself. </p>

<p>I\'d love to see where you all came from! Whether you look back on the work to get inspired, or look back to see how far you\'ve come. </p>

<p>Throwback Thursday, why not?</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Jun 2011 23:29:19 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://dribbble.com/shots/188363-Throwbbback";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:55:"http://dribbble.com/shots/188363-Throwbbback?1307590159";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Joseph and Allison";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:428:"
        <a height="150" href="http://dribbble.com/shots/185565-Joseph-and-Allison" width="200"><img alt="Joseph and Allison" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/185565/joseph-allison.jpg" width="400" /></a><p>Finally feeling confident about the way our names look! Any thoughts/tips/suggestions before it\'s printed?</p>

<p>PS: Sorry for all the wedding related stuff.... :)</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 05 Jun 2011 02:25:49 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://dribbble.com/shots/185565-Joseph-and-Allison";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:62:"http://dribbble.com/shots/185565-Joseph-and-Allison?1307255149";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"November 5th";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:396:"
        <a height="150" href="http://dribbble.com/shots/178898-November-5th" width="200"><img alt="November 5th" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/178898/nov5.jpg" width="400" /></a><p>Yay! Got some custom stamps made to use on my invitations and other collateral for the big day :) <a href="http://simonstamp.com/">www.SimonStamp.com</a>. </p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 May 2011 21:21:09 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://dribbble.com/shots/178898-November-5th";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:56:"http://dribbble.com/shots/178898-November-5th?1306372869";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"Our Story";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:530:"
        <a height="150" href="http://dribbble.com/shots/176309-Our-Story" width="200"><img alt="Our Story" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/176309/dribble.jpg" width="400" /></a><p>Along with the invitation, there will be a fun little typographic/illustrative piece that tells "our story." I\'ve attached the full size image just in case you want to read it :)</p>

<p>PS: This gorgeous kraft paper is from <a href="http://www.paperpresentation.com/">Paper Presentation.</a></p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 22 May 2011 23:31:17 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://dribbble.com/shots/176309-Our-Story";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:53:"http://dribbble.com/shots/176309-Our-Story?1306121477";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"&quot;I Do!&quot; Printed.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:454:"
        <a height="150" href="http://dribbble.com/shots/176218--I-Do-Printed" width="200"><img alt="&quot;I Do!&quot; Printed." height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/176218/dribbble.jpg" width="400" /></a><p>Printed out the invitations and playing around with different ways to assemble the pieces together :) </p>

<p>Still not 100% sold on the type for our names. Arggggg.</p>

<p>Full size attached.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 22 May 2011 18:47:43 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://dribbble.com/shots/176218--I-Do-Printed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:57:"http://dribbble.com/shots/176218--I-Do-Printed?1306104463";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"&quot;I Do!&quot;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:497:"
        <a height="150" href="http://dribbble.com/shots/170662--I-Do" width="200"><img alt="&quot;I Do!&quot;" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/170662/wedding-invite.jpg" width="400" /></a><p>Finally locked myself in my office today and began my wedding invitation designs. Still working on our names at the top, but so far pretty satisfied with the body of the invite.</p>

<p>PS: Four o\' clock is a placeholder, I know it\'s not evening :P</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 15 May 2011 01:47:14 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://dribbble.com/shots/170662--I-Do";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:49:"http://dribbble.com/shots/170662--I-Do?1305438434";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Bull &amp; Beard Squish Test";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:332:"
        <a height="150" href="http://dribbble.com/shots/156565-Bull-Beard-Squish-Test" width="200"><img alt="Bull &amp; Beard Squish Test" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/156565/bullandbeard.jpg" width="400" /></a><p>Early comp for a web design project for Bull &amp; Beard!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 28 Apr 2011 00:07:27 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://dribbble.com/shots/156565-Bull-Beard-Squish-Test";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:66:"http://dribbble.com/shots/156565-Bull-Beard-Squish-Test?1303963647";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Paca-livia-lo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:420:"
        <a height="150" href="http://dribbble.com/shots/149396-Paca-livia-lo" width="200"><img alt="Paca-livia-lo" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/149396/paca.jpg" width="400" /></a><p>Having fun with some engraved images &amp; type treatments. These will eventually be main CTAs for an eCommerce site in development. :)</p>

<p>That alpaca is just so darn cute!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Apr 2011 14:07:45 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://dribbble.com/shots/149396-Paca-livia-lo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:57:"http://dribbble.com/shots/149396-Paca-livia-lo?1302890865";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:8:"Paradise";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:471:"
        <a height="150" href="http://dribbble.com/shots/133270-Paradise" width="200"><img alt="Paradise" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/133270/shot_1300478287.jpg" width="400" /></a><p>A more environmental approach than the previous comp – this version makes you feel like you\'re literally sitting on the beach drinking a margarita. Yummm. </p>

<p>(PS: This is going to take all of my skills to code. Eeekkkk)</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Mar 2011 15:58:07 -0400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://dribbble.com/shots/133270-Paradise";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:52:"http://dribbble.com/shots/133270-Paradise?1300478287";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Loyal Cheeseburger Squish Test";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:474:"
        <a height="150" href="http://dribbble.com/shots/117176-Loyal-Cheeseburger-Squish-Test" width="200"><img alt="Loyal Cheeseburger Squish Test" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/117176/shot_1298061624.jpg" width="400" /></a><p>After lots of sweat &amp; tears, broken mice and corrupted files  - I\'ve finally completed the design. </p>

<p>Organized chaos. </p>

<p>Now I would like a margarita, please :)</p>

<p></p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Feb 2011 15:40:25 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://dribbble.com/shots/117176-Loyal-Cheeseburger-Squish-Test";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:74:"http://dribbble.com/shots/117176-Loyal-Cheeseburger-Squish-Test?1298061625";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Loyal Cheeseburger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:402:"
        <a height="150" href="http://dribbble.com/shots/116800-Loyal-Cheeseburger" width="200"><img alt="Loyal Cheeseburger" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/116800/shot_1297990941.jpg" width="400" /></a><p>Working on a secret something. :)</p>

<p>The wood texture is from Ryan Putnam\'s February crate at http://vectormill.com/. Thanks Ryan! :)</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Feb 2011 20:02:21 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://dribbble.com/shots/116800-Loyal-Cheeseburger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:62:"http://dribbble.com/shots/116800-Loyal-Cheeseburger?1297990941";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"And it begins!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:636:"
        <a height="150" href="http://dribbble.com/shots/113002-And-it-begins" width="200"><img alt="And it begins!" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/113002/shot_1297314946.jpg" width="400" /></a><p>Began exploring type treatments for my wedding invitations.....This is going to be funnnnnn (and oh-so-difficult to commit to)!</p>

<p>Expect to see this change about 50 times.</p>

<p>PS: Please ignore copyrighting at this point in time. (and NO these are NOT my wedding colors. ew.) Gracias.</p>

<p><a href="http://forrst.com/posts/4z1/original">View a larger version here!</a></p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Feb 2011 00:15:46 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://dribbble.com/shots/113002-And-it-begins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:57:"http://dribbble.com/shots/113002-And-it-begins?1297314946";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Pushin&#039; Pixels";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:284:"
        <a height="150" href="http://dribbble.com/shots/107691-Pushin-Pixels" width="200"><img alt="Pushin&#x27; Pixels" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/107691/shot_1296444967.jpg" width="400" /></a><p>Sunday Typography FunDay</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 30 Jan 2011 22:36:07 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://dribbble.com/shots/107691-Pushin-Pixels";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:57:"http://dribbble.com/shots/107691-Pushin-Pixels?1296444967";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Eclyptix Bcards";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:330:"
        <a height="150" href="http://dribbble.com/shots/105380-Eclyptix-Bcards" width="200"><img alt="Eclyptix Bcards" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/105380/shot_1296009086.jpg" width="400" /></a><p>Creating a stationary for Eclyptix... Billy Joe Nobody, he\'s a good guy.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 25 Jan 2011 21:31:26 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://dribbble.com/shots/105380-Eclyptix-Bcards";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:59:"http://dribbble.com/shots/105380-Eclyptix-Bcards?1296009086";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"Roger That";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:271:"
        <a height="150" href="http://dribbble.com/shots/103089-Roger-That" width="200"><img alt="Roger That" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/103089/shot_1295579742.jpg" width="400" /></a><p>Doodling in illustrator</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 22:15:42 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:43:"http://dribbble.com/shots/103089-Roger-That";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:54:"http://dribbble.com/shots/103089-Roger-That?1295579742";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Eclyptix Subpage";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:303:"
        <a height="150" href="http://dribbble.com/shots/99639-Eclyptix-Subpage" width="200"><img alt="Eclyptix Subpage" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/99639/shot_1295031169.jpg" width="400" /></a><p>Working on the portfolio section of Eclyptix.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Jan 2011 13:52:49 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://dribbble.com/shots/99639-Eclyptix-Subpage";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:59:"http://dribbble.com/shots/99639-Eclyptix-Subpage?1295031169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Suzabu Landing Page ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:366:"
        <a height="150" href="http://dribbble.com/shots/97798-Suzabu-Landing-Page" width="200"><img alt="Suzabu Landing Page " height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/97798/shot_1294716169.jpg" width="400" /></a><p>Continuing work on a promotional landing page for an application I am also designing called "Suzabu."</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 10 Jan 2011 22:22:49 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://dribbble.com/shots/97798-Suzabu-Landing-Page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:62:"http://dribbble.com/shots/97798-Suzabu-Landing-Page?1294716169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Eclyptix Squish Test";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:339:"
        <a height="150" href="http://dribbble.com/shots/97378-Eclyptix-Squish-Test" width="200"><img alt="Eclyptix Squish Test" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/97378/shot_1294618088.jpg" width="400" /></a><p>Wrapping up the UI for an  LA based web design &amp; development company.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 09 Jan 2011 19:08:08 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://dribbble.com/shots/97378-Eclyptix-Squish-Test";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:63:"http://dribbble.com/shots/97378-Eclyptix-Squish-Test?1294618088";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Attack of the Cyclopes!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:347:"
        <a height="150" href="http://dribbble.com/shots/96214-Attack-of-the-Cyclopes" width="200"><img alt="Attack of the Cyclopes!" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/96214/shot_1294291838.jpg" width="400" /></a><p>Had some spare time and wanted to experiment with repeating patterns. Wahoo!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 06 Jan 2011 00:30:38 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://dribbble.com/shots/96214-Attack-of-the-Cyclopes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:65:"http://dribbble.com/shots/96214-Attack-of-the-Cyclopes?1294291838";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Suzabu Landing Page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:357:"
        <a height="150" href="http://dribbble.com/shots/95787-Suzabu-Landing-Page" width="200"><img alt="Suzabu Landing Page" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/95787/shot_1294203930.jpg" width="400" /></a><p>Working on a promotional landing page for an application I am also designing called "Suzabu."</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 05 Jan 2011 00:05:30 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://dribbble.com/shots/95787-Suzabu-Landing-Page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:62:"http://dribbble.com/shots/95787-Suzabu-Landing-Page?1294203930";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"Eclyptix ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:319:"
        <a height="150" href="http://dribbble.com/shots/94631-Eclyptix" width="200"><img alt="Eclyptix " height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/94631/shot_1293826260.jpg" width="400" /></a><p>Rebranding and redesigning an LA based web design &amp; development company.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 31 Dec 2010 15:11:00 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://dribbble.com/shots/94631-Eclyptix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:51:"http://dribbble.com/shots/94631-Eclyptix?1293826260";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Lookie! I&#039;m a Commendable Kid!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:441:"
        <a height="150" href="http://dribbble.com/shots/87404-Lookie-I-m-a-Commendable-Kid" width="200"><img alt="Lookie! I&#x27;m a Commendable Kid!" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/87404/shot_1291779158.jpg" width="400" /></a><p>Helping the awesome guys over at Commendable Kids with some updates to the site. They\'re in need of a sticker, and I\'m in need of your feedback! Thanks!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 07 Dec 2010 22:32:38 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://dribbble.com/shots/87404-Lookie-I-m-a-Commendable-Kid";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:71:"http://dribbble.com/shots/87404-Lookie-I-m-a-Commendable-Kid?1291779158";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Super Sweet Specials ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"
        <a height="150" href="http://dribbble.com/shots/86473-Super-Sweet-Specials" width="200"><img alt="Super Sweet Specials " height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/86473/shot_1291598222.jpg" width="400" /></a><p>Screenshot of the specials section of a grocery store app that won\'t be going into development. *sad face*</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 05 Dec 2010 20:17:02 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://dribbble.com/shots/86473-Super-Sweet-Specials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:63:"http://dribbble.com/shots/86473-Super-Sweet-Specials?1291598222";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Yumm-ography";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:369:"
        <a height="150" href="http://dribbble.com/shots/83947-Yumm-ography" width="200"><img alt="Yumm-ography" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/83947/shot_1291007805.gif" width="400" /></a><p>This is how I spent my Sunday! (Let\'s all say it together... *dork*) Anyone feel like taking a stab at the ingredients?</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Nov 2010 00:16:45 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://dribbble.com/shots/83947-Yumm-ography";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:55:"http://dribbble.com/shots/83947-Yumm-ography?1291007805";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"Doodddling";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:538:"
        <a height="150" href="http://dribbble.com/shots/82426-Doodddling" width="200"><img alt="Doodddling" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/82426/shot_1290527899.jpg" width="400" /></a><p>At SPARK, we doodle on all of our <a href="http://sparkbrand.com/our_team.php">employee photos</a> to add personality. I\'m currently working on the Interactive team\'s! See full size <a href="http://cl.ly/2726400V1u0a44300k1d">here</a> and <a href="http://cl.ly/2I0P2Q072u3E3e2n1w2P">here</a>.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Nov 2010 10:58:19 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://dribbble.com/shots/82426-Doodddling";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:53:"http://dribbble.com/shots/82426-Doodddling?1290527899";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Gettin&#039; Hitched";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:383:"
        <a height="150" href="http://dribbble.com/shots/81849-Gettin-Hitched" width="200"><img alt="Gettin&#x27; Hitched" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/81849/shot_1290395084.jpg" width="400" /></a><p>Working on an invitation for my engagement party! The (second) best part about getting married: designing the collateral :)</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 21 Nov 2010 22:04:44 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://dribbble.com/shots/81849-Gettin-Hitched";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:57:"http://dribbble.com/shots/81849-Gettin-Hitched?1290395084";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Hello! Happy Friday!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:299:"
        <a height="150" href="http://dribbble.com/shots/81317-Hello-Happy-Friday" width="200"><img alt="Hello! Happy Friday!" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/81317/shot_1290200840.jpg" width="400" /></a><p>A little Friday afternoon exercise!</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 19 Nov 2010 16:07:20 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://dribbble.com/shots/81317-Hello-Happy-Friday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:61:"http://dribbble.com/shots/81317-Hello-Happy-Friday?1290200840";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Stars &amp; Fetta Cabobs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:488:"
        <a height="150" href="http://dribbble.com/shots/80389-Stars-Fetta-Cabobs" width="200"><img alt="Stars &amp; Fetta Cabobs" height="300" src="http://d13yacurqjgara.cloudfront.net/users/3005/screenshots/80389/shot_1290050830.jpg" width="400" /></a><p>Brightened up the interface a bit with a background pattern that the user will have the option to personalize. Brought the *mystery grocery stores* brand into the app with the "guiding stars" that measure overall health.</p>
      ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:6:"author";a:1:{i:0;a:5:{s:4:"data";s:14:"Allison Grayce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 17 Nov 2010 22:27:10 -0500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://dribbble.com/shots/80389-Stars-Fetta-Cabobs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:61:"http://dribbble.com/shots/80389-Stars-Fetta-Cabobs?1290050830";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:43:"http://dribbble.com/allisongrayce/shots.rss";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:12:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 27 Feb 2014 18:27:36 GMT";s:12:"content-type";s:34:"application/rss+xml; charset=utf-8";s:10:"connection";s:5:"close";s:6:"status";s:6:"200 OK";s:15:"x-ua-compatible";s:16:"IE=Edge,chrome=1";s:4:"etag";s:34:""6aba545bf6e4970879cdfe03f4d75c32"";s:13:"cache-control";s:35:"max-age=0, private, must-revalidate";s:12:"x-request-id";s:32:"c08fa4bc610198c491267e3585140ed3";s:9:"x-runtime";s:8:"0.094967";s:12:"x-rack-cache";s:4:"miss";s:15:"x-frame-options";s:10:"SAMEORIGIN";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (630, '_transient_timeout_feed_mod_4ab971b92254aae7e30a99c8056b68cb', '1393568856', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (631, '_transient_feed_mod_4ab971b92254aae7e30a99c8056b68cb', '1393525656', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (633, '_transient_timeout_tweets-twiget-widget-2', '1393525663', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (634, '_transient_tweets-twiget-widget-2', '{"errors":[{"message":"Bad Authentication data","code":215}]}', 'no') ; 
INSERT INTO `wpWPP_options` VALUES (635, '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1393525658;s:8:"response";a:4:{s:26:"ag-custom-admin/plugin.php";O:8:"stdClass":6:{s:2:"id";s:5:"22039";s:4:"slug";s:15:"ag-custom-admin";s:11:"new_version";s:5:"1.3.4";s:14:"upgrade_notice";s:33:"Bug fixes. Better error handling.";s:3:"url";s:46:"https://wordpress.org/plugins/ag-custom-admin/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/ag-custom-admin.1.3.4.zip";}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":5:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:11:"new_version";s:3:"2.5";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/backupwordpress.2.5.zip";}s:71:"official-treehouse-badges-widgets-and-shortcodes/wptreehouse-badges.php";O:8:"stdClass":6:{s:2:"id";s:5:"43666";s:4:"slug";s:48:"official-treehouse-badges-widgets-and-shortcodes";s:11:"new_version";s:3:"1.3";s:14:"upgrade_notice";s:62:"Added ability to display random badges, added affiliate widget";s:3:"url";s:79:"https://wordpress.org/plugins/official-treehouse-badges-widgets-and-shortcodes/";s:7:"package";s:91:"https://downloads.wordpress.org/plugin/official-treehouse-badges-widgets-and-shortcodes.zip";}s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":5:{s:2:"id";s:4:"5899";s:4:"slug";s:13:"wordpress-seo";s:11:"new_version";s:6:"1.4.25";s:3:"url";s:44:"https://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/wordpress-seo.1.4.25.zip";}}s:12:"translations";a:0:{}}', 'yes') ;
#
# End of data contents of table wpWPP_options
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_postmeta`
#

DROP TABLE IF EXISTS `wpWPP_postmeta`;


#
# Table structure of table `wpWPP_postmeta`
#

CREATE TABLE `wpWPP_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_postmeta (192 records)
#
 
INSERT INTO `wpWPP_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wpWPP_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (3, 4, '_wp_page_template', 'default') ; 
INSERT INTO `wpWPP_postmeta` VALUES (4, 4, '_edit_lock', '1389974686:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (5, 6, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (6, 6, '_wp_page_template', 'default') ; 
INSERT INTO `wpWPP_postmeta` VALUES (7, 6, '_edit_lock', '1390231797:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (8, 8, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (9, 8, '_wp_page_template', 'default') ; 
INSERT INTO `wpWPP_postmeta` VALUES (10, 8, '_edit_lock', '1389794201:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (11, 10, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (12, 10, '_wp_page_template', 'work.php') ; 
INSERT INTO `wpWPP_postmeta` VALUES (13, 10, '_edit_lock', '1389975492:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (14, 12, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (15, 12, '_wp_page_template', 'default') ; 
INSERT INTO `wpWPP_postmeta` VALUES (16, 12, '_edit_lock', '1390746318:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (17, 14, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (18, 14, '_edit_lock', '1390233529:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (20, 16, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (22, 16, '_edit_lock', '1390233517:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (23, 18, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (25, 18, '_edit_lock', '1390663795:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (28, 20, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (29, 20, 'field_52d69746ae24a', 'a:14:{s:3:"key";s:19:"field_52d69746ae24a";s:5:"label";s:15:"URL to Web Site";s:4:"name";s:3:"url";s:4:"type";s:4:"text";s:12:"instructions";s:33:"Enter in the url for the project.";s:8:"required";s:1:"1";s:13:"default_value";s:7:"http://";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (30, 20, 'field_52d69780ae24b', 'a:12:{s:3:"key";s:19:"field_52d69780ae24b";s:5:"label";s:11:"Description";s:4:"name";s:11:"description";s:4:"type";s:8:"textarea";s:12:"instructions";s:37:"Enter in a descroption of the project";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:10:"formatting";s:4:"none";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (31, 20, 'field_52d6979cae24c', 'a:11:{s:3:"key";s:19:"field_52d6979cae24c";s:5:"label";s:26:"Display on Homepage Slider";s:4:"name";s:19:"display_on_homepage";s:4:"type";s:8:"checkbox";s:12:"instructions";s:58:"Check if you would this project to appear on the homepage.";s:8:"required";s:1:"0";s:7:"choices";a:1:{s:3:"Yes";s:3:"Yes";}s:13:"default_value";s:0:"";s:6:"layout";s:8:"vertical";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (32, 20, 'field_52d697daae24d', 'a:11:{s:3:"key";s:19:"field_52d697daae24d";s:5:"label";s:21:"Homepage Slider Image";s:4:"name";s:21:"homepage_slider_image";s:4:"type";s:5:"image";s:12:"instructions";s:66:"Upload the image to appear for this project on the homepage slider";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_52d6979cae24c";s:8:"operator";s:2:"==";s:5:"value";s:3:"Yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (33, 20, 'field_52d69800ae24e', 'a:9:{s:3:"key";s:19:"field_52d69800ae24e";s:5:"label";s:16:"Background Color";s:4:"name";s:16:"background_color";s:4:"type";s:12:"color_picker";s:12:"instructions";s:68:"Select the color to appear as the background color for this project.";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_52d6979cae24c";s:8:"operator";s:2:"==";s:5:"value";s:3:"Yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (34, 20, 'field_52d69825ae24f', 'a:9:{s:3:"key";s:19:"field_52d69825ae24f";s:5:"label";s:12:"Button Color";s:4:"name";s:12:"button_color";s:4:"type";s:12:"color_picker";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_52d6979cae24c";s:8:"operator";s:2:"==";s:5:"value";s:3:"Yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (35, 20, 'field_52d69837ae250', 'a:14:{s:3:"key";s:19:"field_52d69837ae250";s:5:"label";s:20:"Related Testimonials";s:4:"name";s:20:"related_testimonials";s:4:"type";s:12:"relationship";s:12:"instructions";s:31:"Select any related testimonials";s:8:"required";s:1:"0";s:13:"return_format";s:6:"object";s:9:"post_type";a:1:{i:0;s:12:"testimonials";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_52d6979cae24c";s:8:"operator";s:2:"==";s:5:"value";s:3:"Yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:6;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (37, 20, 'position', 'normal') ; 
INSERT INTO `wpWPP_postmeta` VALUES (38, 20, 'layout', 'no_box') ; 
INSERT INTO `wpWPP_postmeta` VALUES (39, 20, 'hide_on_screen', 'a:14:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:13:"custom_fields";i:4;s:10:"discussion";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:4:"slug";i:8;s:6:"author";i:9;s:6:"format";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:4:"tags";i:13;s:15:"send-trackbacks";}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (40, 20, '_edit_lock', '1390399832:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (44, 21, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (45, 21, 'field_52d698bbaeed6', 'a:14:{s:3:"key";s:19:"field_52d698bbaeed6";s:5:"label";s:4:"Name";s:4:"name";s:4:"name";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (46, 21, 'field_52d698cdaeed7', 'a:12:{s:3:"key";s:19:"field_52d698cdaeed7";s:5:"label";s:12:"Testimonials";s:4:"name";s:12:"testimonials";s:4:"type";s:8:"textarea";s:12:"instructions";s:38:"Enter in the testimonial of the person";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (48, 21, 'position', 'normal') ; 
INSERT INTO `wpWPP_postmeta` VALUES (49, 21, 'layout', 'no_box') ; 
INSERT INTO `wpWPP_postmeta` VALUES (50, 21, 'hide_on_screen', 'a:14:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:13:"custom_fields";i:4;s:10:"discussion";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:4:"slug";i:8;s:6:"author";i:9;s:6:"format";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:4:"tags";i:13;s:15:"send-trackbacks";}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (51, 21, '_edit_lock', '1390401550:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (63, 28, '_menu_item_type', 'post_type') ; 
INSERT INTO `wpWPP_postmeta` VALUES (64, 28, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wpWPP_postmeta` VALUES (65, 28, '_menu_item_object_id', '6') ; 
INSERT INTO `wpWPP_postmeta` VALUES (66, 28, '_menu_item_object', 'page') ; 
INSERT INTO `wpWPP_postmeta` VALUES (67, 28, '_menu_item_target', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (68, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (69, 28, '_menu_item_xfn', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (70, 28, '_menu_item_url', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (72, 29, '_menu_item_type', 'post_type') ; 
INSERT INTO `wpWPP_postmeta` VALUES (73, 29, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wpWPP_postmeta` VALUES (74, 29, '_menu_item_object_id', '8') ; 
INSERT INTO `wpWPP_postmeta` VALUES (75, 29, '_menu_item_object', 'page') ; 
INSERT INTO `wpWPP_postmeta` VALUES (76, 29, '_menu_item_target', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (77, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (78, 29, '_menu_item_xfn', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (79, 29, '_menu_item_url', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (81, 30, '_menu_item_type', 'post_type') ; 
INSERT INTO `wpWPP_postmeta` VALUES (82, 30, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wpWPP_postmeta` VALUES (83, 30, '_menu_item_object_id', '12') ; 
INSERT INTO `wpWPP_postmeta` VALUES (84, 30, '_menu_item_object', 'page') ; 
INSERT INTO `wpWPP_postmeta` VALUES (85, 30, '_menu_item_target', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (86, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (87, 30, '_menu_item_xfn', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (88, 30, '_menu_item_url', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (90, 31, '_menu_item_type', 'post_type') ; 
INSERT INTO `wpWPP_postmeta` VALUES (91, 31, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wpWPP_postmeta` VALUES (92, 31, '_menu_item_object_id', '10') ; 
INSERT INTO `wpWPP_postmeta` VALUES (93, 31, '_menu_item_object', 'page') ; 
INSERT INTO `wpWPP_postmeta` VALUES (94, 31, '_menu_item_target', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (95, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (96, 31, '_menu_item_xfn', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (97, 31, '_menu_item_url', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (99, 32, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (100, 32, '_edit_lock', '1390745260:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (101, 33, 'url', 'http://skittles.gUNIT') ; 
INSERT INTO `wpWPP_postmeta` VALUES (102, 33, '_url', 'field_52d69746ae24a') ; 
INSERT INTO `wpWPP_postmeta` VALUES (103, 33, 'description', 'Skillets stuff goes here mang. ') ; 
INSERT INTO `wpWPP_postmeta` VALUES (104, 33, '_description', 'field_52d69780ae24b') ; 
INSERT INTO `wpWPP_postmeta` VALUES (105, 33, 'display_on_homepage', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (106, 33, '_display_on_homepage', 'field_52d6979cae24c') ; 
INSERT INTO `wpWPP_postmeta` VALUES (107, 33, 'homepage_slider_image', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (108, 33, '_homepage_slider_image', 'field_52d697daae24d') ; 
INSERT INTO `wpWPP_postmeta` VALUES (109, 33, 'background_color', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (110, 33, '_background_color', 'field_52d69800ae24e') ; 
INSERT INTO `wpWPP_postmeta` VALUES (111, 33, 'button_color', '#1d20c6') ; 
INSERT INTO `wpWPP_postmeta` VALUES (112, 33, '_button_color', 'field_52d69825ae24f') ; 
INSERT INTO `wpWPP_postmeta` VALUES (113, 33, 'related_testimonials', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (114, 33, '_related_testimonials', 'field_52d69837ae250') ; 
INSERT INTO `wpWPP_postmeta` VALUES (115, 32, 'url', 'http://skittles.gUNIT') ; 
INSERT INTO `wpWPP_postmeta` VALUES (116, 32, '_url', 'field_52d69746ae24a') ; 
INSERT INTO `wpWPP_postmeta` VALUES (117, 32, 'description', 'Skillets stuff goes here mang. ') ; 
INSERT INTO `wpWPP_postmeta` VALUES (118, 32, '_description', 'field_52d69780ae24b') ; 
INSERT INTO `wpWPP_postmeta` VALUES (119, 32, 'display_on_homepage', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (120, 32, '_display_on_homepage', 'field_52d6979cae24c') ; 
INSERT INTO `wpWPP_postmeta` VALUES (121, 32, 'homepage_slider_image', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (122, 32, '_homepage_slider_image', 'field_52d697daae24d') ; 
INSERT INTO `wpWPP_postmeta` VALUES (123, 32, 'background_color', '#dd3333') ; 
INSERT INTO `wpWPP_postmeta` VALUES (124, 32, '_background_color', 'field_52d69800ae24e') ; 
INSERT INTO `wpWPP_postmeta` VALUES (125, 32, 'button_color', '#1d20c6') ; 
INSERT INTO `wpWPP_postmeta` VALUES (126, 32, '_button_color', 'field_52d69825ae24f') ; 
INSERT INTO `wpWPP_postmeta` VALUES (127, 32, 'related_testimonials', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (128, 32, '_related_testimonials', 'field_52d69837ae250') ; 
INSERT INTO `wpWPP_postmeta` VALUES (129, 34, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (130, 34, '_edit_lock', '1390745224:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (131, 35, 'url', 'http://') ; 
INSERT INTO `wpWPP_postmeta` VALUES (132, 35, '_url', 'field_52d69746ae24a') ; 
INSERT INTO `wpWPP_postmeta` VALUES (133, 35, 'description', 'COLORFUL CHOCOLATE MANG. ') ; 
INSERT INTO `wpWPP_postmeta` VALUES (134, 35, '_description', 'field_52d69780ae24b') ; 
INSERT INTO `wpWPP_postmeta` VALUES (135, 35, 'display_on_homepage', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (136, 35, '_display_on_homepage', 'field_52d6979cae24c') ; 
INSERT INTO `wpWPP_postmeta` VALUES (137, 35, 'homepage_slider_image', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (138, 35, '_homepage_slider_image', 'field_52d697daae24d') ; 
INSERT INTO `wpWPP_postmeta` VALUES (139, 35, 'background_color', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (140, 35, '_background_color', 'field_52d69800ae24e') ; 
INSERT INTO `wpWPP_postmeta` VALUES (141, 35, 'button_color', '#dd3333') ; 
INSERT INTO `wpWPP_postmeta` VALUES (142, 35, '_button_color', 'field_52d69825ae24f') ; 
INSERT INTO `wpWPP_postmeta` VALUES (143, 35, 'related_testimonials', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (144, 35, '_related_testimonials', 'field_52d69837ae250') ; 
INSERT INTO `wpWPP_postmeta` VALUES (145, 34, 'url', 'http://') ; 
INSERT INTO `wpWPP_postmeta` VALUES (146, 34, '_url', 'field_52d69746ae24a') ; 
INSERT INTO `wpWPP_postmeta` VALUES (147, 34, 'description', 'COLORFUL CHOCOLATE MANG. ') ; 
INSERT INTO `wpWPP_postmeta` VALUES (148, 34, '_description', 'field_52d69780ae24b') ; 
INSERT INTO `wpWPP_postmeta` VALUES (149, 34, 'display_on_homepage', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (150, 34, '_display_on_homepage', 'field_52d6979cae24c') ; 
INSERT INTO `wpWPP_postmeta` VALUES (151, 34, 'homepage_slider_image', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (152, 34, '_homepage_slider_image', 'field_52d697daae24d') ; 
INSERT INTO `wpWPP_postmeta` VALUES (153, 34, 'background_color', '#81d742') ; 
INSERT INTO `wpWPP_postmeta` VALUES (154, 34, '_background_color', 'field_52d69800ae24e') ; 
INSERT INTO `wpWPP_postmeta` VALUES (155, 34, 'button_color', '#dd3333') ; 
INSERT INTO `wpWPP_postmeta` VALUES (156, 34, '_button_color', 'field_52d69825ae24f') ; 
INSERT INTO `wpWPP_postmeta` VALUES (157, 34, 'related_testimonials', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (158, 34, '_related_testimonials', 'field_52d69837ae250') ; 
INSERT INTO `wpWPP_postmeta` VALUES (159, 36, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (160, 36, '_edit_lock', '1390745252:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (161, 37, 'url', 'http://') ; 
INSERT INTO `wpWPP_postmeta` VALUES (162, 37, '_url', 'field_52d69746ae24a') ; 
INSERT INTO `wpWPP_postmeta` VALUES (163, 37, 'description', 'Yep Gonna be 15 4eva ') ; 
INSERT INTO `wpWPP_postmeta` VALUES (164, 37, '_description', 'field_52d69780ae24b') ; 
INSERT INTO `wpWPP_postmeta` VALUES (165, 37, 'display_on_homepage', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (166, 37, '_display_on_homepage', 'field_52d6979cae24c') ; 
INSERT INTO `wpWPP_postmeta` VALUES (167, 37, 'homepage_slider_image', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (168, 37, '_homepage_slider_image', 'field_52d697daae24d') ; 
INSERT INTO `wpWPP_postmeta` VALUES (169, 37, 'background_color', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (170, 37, '_background_color', 'field_52d69800ae24e') ; 
INSERT INTO `wpWPP_postmeta` VALUES (171, 37, 'button_color', '#42d651') ; 
INSERT INTO `wpWPP_postmeta` VALUES (172, 37, '_button_color', 'field_52d69825ae24f') ; 
INSERT INTO `wpWPP_postmeta` VALUES (173, 37, 'related_testimonials', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (174, 37, '_related_testimonials', 'field_52d69837ae250') ; 
INSERT INTO `wpWPP_postmeta` VALUES (175, 36, 'url', 'http://') ; 
INSERT INTO `wpWPP_postmeta` VALUES (176, 36, '_url', 'field_52d69746ae24a') ; 
INSERT INTO `wpWPP_postmeta` VALUES (177, 36, 'description', 'Yep Gonna be 15 4eva ') ; 
INSERT INTO `wpWPP_postmeta` VALUES (178, 36, '_description', 'field_52d69780ae24b') ; 
INSERT INTO `wpWPP_postmeta` VALUES (179, 36, 'display_on_homepage', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (180, 36, '_display_on_homepage', 'field_52d6979cae24c') ; 
INSERT INTO `wpWPP_postmeta` VALUES (181, 36, 'homepage_slider_image', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (182, 36, '_homepage_slider_image', 'field_52d697daae24d') ; 
INSERT INTO `wpWPP_postmeta` VALUES (183, 36, 'background_color', '#1e73be') ; 
INSERT INTO `wpWPP_postmeta` VALUES (184, 36, '_background_color', 'field_52d69800ae24e') ; 
INSERT INTO `wpWPP_postmeta` VALUES (185, 36, 'button_color', '#42d651') ; 
INSERT INTO `wpWPP_postmeta` VALUES (186, 36, '_button_color', 'field_52d69825ae24f') ; 
INSERT INTO `wpWPP_postmeta` VALUES (187, 36, 'related_testimonials', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (188, 36, '_related_testimonials', 'field_52d69837ae250') ; 
INSERT INTO `wpWPP_postmeta` VALUES (195, 20, 'field_52dfcfa34531c', 'a:11:{s:3:"key";s:19:"field_52dfcfa34531c";s:5:"label";s:14:"Project Images";s:4:"name";s:14:"project_images";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:35:"Add the images to the project below";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:5:"basic";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_52d6979cae24c";s:8:"operator";s:2:"==";s:5:"value";s:3:"Yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:7;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (197, 20, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"work";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (198, 46, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (199, 46, '_edit_lock', '1390401154:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (200, 47, 'name', 'Nick R.') ; 
INSERT INTO `wpWPP_postmeta` VALUES (201, 47, '_name', 'field_52d698bbaeed6') ; 
INSERT INTO `wpWPP_postmeta` VALUES (202, 47, 'testimonials', 'Nick\'s work is incredible. Should be in the magazines along with all the pros. Probably won\'t get there, though, because he\'s too busy killin\' it as an entrepreneur.') ; 
INSERT INTO `wpWPP_postmeta` VALUES (203, 47, '_testimonials', 'field_52d698cdaeed7') ; 
INSERT INTO `wpWPP_postmeta` VALUES (204, 46, 'name', 'Nick R.') ; 
INSERT INTO `wpWPP_postmeta` VALUES (205, 46, '_name', 'field_52d698bbaeed6') ; 
INSERT INTO `wpWPP_postmeta` VALUES (206, 46, 'testimonials', 'Nick\'s work is incredible. Should be in the magazines along with all the pros. Probably won\'t get there, though, because he\'s too busy killin\' it as an entrepreneur.') ; 
INSERT INTO `wpWPP_postmeta` VALUES (207, 46, '_testimonials', 'field_52d698cdaeed7') ; 
INSERT INTO `wpWPP_postmeta` VALUES (208, 48, '_edit_last', '1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (209, 48, '_edit_lock', '1390401424:1') ; 
INSERT INTO `wpWPP_postmeta` VALUES (210, 49, 'name', 'Dr. Watzz') ; 
INSERT INTO `wpWPP_postmeta` VALUES (211, 49, '_name', 'field_52d698bbaeed6') ; 
INSERT INTO `wpWPP_postmeta` VALUES (212, 49, 'testimonials', 'This is amazing. This blog will be here for at least 10 years mang. Thanks.') ; 
INSERT INTO `wpWPP_postmeta` VALUES (213, 49, '_testimonials', 'field_52d698cdaeed7') ; 
INSERT INTO `wpWPP_postmeta` VALUES (214, 48, 'name', 'Dr. Watzz') ; 
INSERT INTO `wpWPP_postmeta` VALUES (215, 48, '_name', 'field_52d698bbaeed6') ; 
INSERT INTO `wpWPP_postmeta` VALUES (216, 48, 'testimonials', 'This is amazing. This blog will be here for at least 10 years mang. Thanks.') ; 
INSERT INTO `wpWPP_postmeta` VALUES (217, 48, '_testimonials', 'field_52d698cdaeed7') ; 
INSERT INTO `wpWPP_postmeta` VALUES (218, 21, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:12:"testimonials";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wpWPP_postmeta` VALUES (222, 34, 'project_images', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (223, 34, '_project_images', 'field_52dfcfa34531c') ; 
INSERT INTO `wpWPP_postmeta` VALUES (224, 36, 'project_images', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (225, 36, '_project_images', 'field_52dfcfa34531c') ; 
INSERT INTO `wpWPP_postmeta` VALUES (226, 32, 'project_images', '') ; 
INSERT INTO `wpWPP_postmeta` VALUES (227, 32, '_project_images', 'field_52dfcfa34531c') ;
#
# End of data contents of table wpWPP_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_posts`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_posts`
#

DROP TABLE IF EXISTS `wpWPP_posts`;


#
# Table structure of table `wpWPP_posts`
#

CREATE TABLE `wpWPP_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_posts (46 records)
#
 
INSERT INTO `wpWPP_posts` VALUES (1, 1, '2014-01-14 15:53:51', '2014-01-14 15:53:51', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-01-14 15:53:51', '2014-01-14 15:53:51', '', 0, 'http://localhost:8888/allisongrayce.com/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wpWPP_posts` VALUES (2, 1, '2014-01-14 15:53:51', '2014-01-14 15:53:51', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/allisongrayce.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-01-14 15:53:51', '2014-01-14 15:53:51', '', 0, 'http://localhost:8888/allisongrayce.com/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (4, 1, '2014-01-15 13:56:27', '2014-01-15 13:56:27', 'Welcome to my site!', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-01-17 16:04:46', '2014-01-17 16:04:46', '', 0, 'http://localhost:8888/allisongrayce.com/?page_id=4', 0, 'page', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (5, 1, '2014-01-15 13:56:27', '2014-01-15 13:56:27', '', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-01-15 13:56:27', '2014-01-15 13:56:27', '', 4, 'http://localhost:8888/allisongrayce.com/?p=5', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (6, 1, '2014-01-15 13:56:36', '2014-01-15 13:56:36', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2014-01-20 15:29:48', '2014-01-20 15:29:48', '', 0, 'http://localhost:8888/allisongrayce.com/?page_id=6', 0, 'page', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (7, 1, '2014-01-15 13:56:36', '2014-01-15 13:56:36', '', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-01-15 13:56:36', '2014-01-15 13:56:36', '', 6, 'http://localhost:8888/allisongrayce.com/?p=7', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (8, 1, '2014-01-15 13:56:41', '2014-01-15 13:56:41', '', 'Blog', '', 'publish', 'open', 'open', '', 'blog', '', '', '2014-01-15 13:56:41', '2014-01-15 13:56:41', '', 0, 'http://localhost:8888/allisongrayce.com/?page_id=8', 0, 'page', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (9, 1, '2014-01-15 13:56:41', '2014-01-15 13:56:41', '', 'Blog', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-01-15 13:56:41', '2014-01-15 13:56:41', '', 8, 'http://localhost:8888/allisongrayce.com/?p=9', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (10, 1, '2014-01-15 13:56:51', '2014-01-15 13:56:51', '', 'Work', '', 'publish', 'open', 'open', '', 'work', '', '', '2014-01-17 16:18:11', '2014-01-17 16:18:11', '', 0, 'http://localhost:8888/allisongrayce.com/?page_id=10', 0, 'page', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (11, 1, '2014-01-15 13:56:51', '2014-01-15 13:56:51', '', 'Work', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-01-15 13:56:51', '2014-01-15 13:56:51', '', 10, 'http://localhost:8888/allisongrayce.com/?p=11', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (12, 1, '2014-01-15 13:57:02', '2014-01-15 13:57:02', '[contact]', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2014-01-26 14:25:18', '2014-01-26 14:25:18', '', 0, 'http://localhost:8888/allisongrayce.com/?page_id=12', 0, 'page', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (13, 1, '2014-01-15 13:57:02', '2014-01-15 13:57:02', '', 'Contact', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2014-01-15 13:57:02', '2014-01-15 13:57:02', '', 12, 'http://localhost:8888/allisongrayce.com/?p=13', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (14, 1, '2014-01-15 13:58:00', '2014-01-15 13:58:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.', 'First Blog Post', '', 'publish', 'open', 'open', '', 'first-blog-post', '', '', '2014-01-20 16:00:41', '2014-01-20 16:00:41', '', 0, 'http://localhost:8888/allisongrayce.com/?p=14', 0, 'post', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (15, 1, '2014-01-15 13:58:00', '2014-01-15 13:58:00', '', 'First Blog Post', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2014-01-15 13:58:00', '2014-01-15 13:58:00', '', 14, 'http://localhost:8888/allisongrayce.com/?p=15', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (16, 1, '2014-01-15 13:58:10', '2014-01-15 13:58:10', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper', 'Second Blog Post', '', 'publish', 'open', 'open', '', 'second-blog-post', '', '', '2014-01-20 16:00:30', '2014-01-20 16:00:30', '', 0, 'http://localhost:8888/allisongrayce.com/?p=16', 0, 'post', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (17, 1, '2014-01-15 13:58:10', '2014-01-15 13:58:10', '', 'Second Blog Post', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2014-01-15 13:58:10', '2014-01-15 13:58:10', '', 16, 'http://localhost:8888/allisongrayce.com/?p=17', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (18, 1, '2014-01-15 13:58:16', '2014-01-15 13:58:16', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.', 'Third Blog Post', '', 'publish', 'open', 'open', '', 'third-blog-post', '', '', '2014-01-25 15:29:55', '2014-01-25 15:29:55', '', 0, 'http://localhost:8888/allisongrayce.com/?p=18', 0, 'post', '', 1) ; 
INSERT INTO `wpWPP_posts` VALUES (19, 1, '2014-01-15 13:58:16', '2014-01-15 13:58:16', '', 'Third Blog Post', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2014-01-15 13:58:16', '2014-01-15 13:58:16', '', 18, 'http://localhost:8888/allisongrayce.com/?p=19', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (20, 1, '2014-01-15 14:16:34', '2014-01-15 14:16:34', '', 'Work', '', 'publish', 'closed', 'closed', '', 'acf_work', '', '', '2014-01-22 14:10:32', '2014-01-22 14:10:32', '', 0, 'http://localhost:8888/allisongrayce.com/?post_type=acf&#038;p=20', 0, 'acf', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (21, 1, '2014-01-15 14:19:41', '2014-01-15 14:19:41', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'acf_testimonials', '', '', '2014-01-22 14:39:10', '2014-01-22 14:39:10', '', 0, 'http://localhost:8888/allisongrayce.com/?post_type=acf&#038;p=21', 0, 'acf', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (24, 1, '2014-01-17 16:04:29', '2014-01-17 16:04:29', 'Welcome to my site!', 'Home', '', 'inherit', 'open', 'open', '', '4-autosave-v1', '', '', '2014-01-17 16:04:29', '2014-01-17 16:04:29', '', 4, 'http://localhost:8888/allisongrayce.com/?p=24', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (25, 1, '2014-01-17 16:04:19', '2014-01-17 16:04:19', 'Welcome!', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-01-17 16:04:19', '2014-01-17 16:04:19', '', 4, 'http://localhost:8888/allisongrayce.com/?p=25', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (26, 1, '2014-01-17 16:04:46', '2014-01-17 16:04:46', 'Welcome to my site!', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-01-17 16:04:46', '2014-01-17 16:04:46', '', 4, 'http://localhost:8888/allisongrayce.com/?p=26', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (28, 1, '2014-01-17 16:11:48', '2014-01-17 16:11:48', ' ', '', '', 'publish', 'open', 'open', '', '28', '', '', '2014-01-20 15:32:01', '2014-01-20 15:32:01', '', 0, 'http://localhost:8888/allisongrayce.com/?p=28', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (29, 1, '2014-01-17 16:11:48', '2014-01-17 16:11:48', ' ', '', '', 'publish', 'open', 'open', '', '29', '', '', '2014-01-20 15:32:01', '2014-01-20 15:32:01', '', 0, 'http://localhost:8888/allisongrayce.com/?p=29', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (30, 1, '2014-01-17 16:11:48', '2014-01-17 16:11:48', ' ', '', '', 'publish', 'open', 'open', '', '30', '', '', '2014-01-20 15:32:01', '2014-01-20 15:32:01', '', 0, 'http://localhost:8888/allisongrayce.com/?p=30', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (31, 1, '2014-01-17 16:11:48', '2014-01-17 16:11:48', ' ', '', '', 'publish', 'open', 'open', '', '31', '', '', '2014-01-20 15:32:01', '2014-01-20 15:32:01', '', 0, 'http://localhost:8888/allisongrayce.com/?p=31', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (32, 1, '2014-01-17 16:23:45', '2014-01-17 16:23:45', '', 'SKittles', '', 'publish', 'open', 'open', '', 'skittles', '', '', '2014-01-26 14:07:40', '2014-01-26 14:07:40', '', 0, 'http://localhost:8888/allisongrayce.com/?post_type=work&#038;p=32', 0, 'work', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (33, 1, '2014-01-17 16:23:45', '2014-01-17 16:23:45', '', 'SKittles', '', 'inherit', 'open', 'open', '', '32-revision-v1', '', '', '2014-01-17 16:23:45', '2014-01-17 16:23:45', '', 32, 'http://localhost:8888/allisongrayce.com/32-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (34, 1, '2014-01-17 16:24:11', '2014-01-17 16:24:11', '', 'M&M\'s', '', 'publish', 'open', 'open', '', 'mms', '', '', '2014-01-26 14:07:04', '2014-01-26 14:07:04', '', 0, 'http://localhost:8888/allisongrayce.com/?post_type=work&#038;p=34', 0, 'work', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (35, 1, '2014-01-17 16:24:11', '2014-01-17 16:24:11', '', 'M&M\'s', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-01-17 16:24:11', '2014-01-17 16:24:11', '', 34, 'http://localhost:8888/allisongrayce.com/34-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (36, 1, '2014-01-17 16:24:50', '2014-01-17 16:24:50', '', '15.4Eva', '', 'publish', 'open', 'open', '', '15-4eva', '', '', '2014-01-26 14:07:32', '2014-01-26 14:07:32', '', 0, 'http://localhost:8888/allisongrayce.com/?post_type=work&#038;p=36', 0, 'work', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (37, 1, '2014-01-17 16:24:50', '2014-01-17 16:24:50', '', '15.4Eva', '', 'inherit', 'open', 'open', '', '36-revision-v1', '', '', '2014-01-17 16:24:50', '2014-01-17 16:24:50', '', 36, 'http://localhost:8888/allisongrayce.com/36-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (38, 1, '2014-01-20 15:29:48', '2014-01-20 15:29:48', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-01-20 15:29:48', '2014-01-20 15:29:48', '', 6, 'http://localhost:8888/allisongrayce.com/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (39, 1, '2014-01-20 15:46:12', '2014-01-20 15:46:12', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.&lt;/p&gt;', 'First Blog Post', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2014-01-20 15:46:12', '2014-01-20 15:46:12', '', 14, 'http://localhost:8888/allisongrayce.com/14-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (40, 1, '2014-01-20 15:46:19', '2014-01-20 15:46:19', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.&lt;/p&gt;', 'Second Blog Post', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2014-01-20 15:46:19', '2014-01-20 15:46:19', '', 16, 'http://localhost:8888/allisongrayce.com/16-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (41, 1, '2014-01-20 15:46:27', '2014-01-20 15:46:27', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.&lt;/p&gt;

&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.&lt;/p&gt;', 'Third Blog Post', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2014-01-20 15:46:27', '2014-01-20 15:46:27', '', 18, 'http://localhost:8888/allisongrayce.com/18-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (42, 1, '2014-01-20 16:00:09', '2014-01-20 16:00:09', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.', 'Third Blog Post', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2014-01-20 16:00:09', '2014-01-20 16:00:09', '', 18, 'http://localhost:8888/allisongrayce.com/18-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (43, 1, '2014-01-20 16:00:30', '2014-01-20 16:00:30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper', 'Second Blog Post', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2014-01-20 16:00:30', '2014-01-20 16:00:30', '', 16, 'http://localhost:8888/allisongrayce.com/16-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (44, 1, '2014-01-20 16:00:41', '2014-01-20 16:00:41', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sollicitudin faucibus urna, eget eleifend felis suscipit vel. Sed vel ligula orci, hendrerit dapibus orci. Sed feugiat, lectus in consequat semper, diam diam sollicitudin ante, sed egestas lorem quam vel leo. In a quam non diam tristique mollis. Suspendisse ultricies dignissim molestie. Morbi a blandit turpis.', 'First Blog Post', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2014-01-20 16:00:41', '2014-01-20 16:00:41', '', 14, 'http://localhost:8888/allisongrayce.com/14-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (45, 1, '2014-01-22 14:02:57', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-01-22 14:02:57', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/allisongrayce.com/?p=45', 0, 'post', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (46, 1, '2014-01-22 14:32:38', '2014-01-22 14:32:38', '', 'Incredible. ', '', 'publish', 'open', 'open', '', 'incredible', '', '', '2014-01-22 14:32:38', '2014-01-22 14:32:38', '', 0, 'http://localhost:8888/allisongrayce.com/?post_type=testimonials&#038;p=46', 0, 'testimonials', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (47, 1, '2014-01-22 14:32:38', '2014-01-22 14:32:38', '', 'Incredible. ', '', 'inherit', 'open', 'open', '', '46-revision-v1', '', '', '2014-01-22 14:32:38', '2014-01-22 14:32:38', '', 46, 'http://localhost:8888/allisongrayce.com/46-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (48, 1, '2014-01-22 14:37:04', '2014-01-22 14:37:04', '', 'Dr. Wattz', '', 'publish', 'open', 'open', '', 'dr-wattz', '', '', '2014-01-22 14:37:04', '2014-01-22 14:37:04', '', 0, 'http://localhost:8888/allisongrayce.com/?post_type=testimonials&#038;p=48', 0, 'testimonials', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (49, 1, '2014-01-22 14:37:04', '2014-01-22 14:37:04', '', 'Dr. Wattz', '', 'inherit', 'open', 'open', '', '48-revision-v1', '', '', '2014-01-22 14:37:04', '2014-01-22 14:37:04', '', 48, 'http://localhost:8888/allisongrayce.com/48-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpWPP_posts` VALUES (51, 1, '2014-01-26 14:25:18', '2014-01-26 14:25:18', '[contact]', 'Contact', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2014-01-26 14:25:18', '2014-01-26 14:25:18', '', 12, 'http://localhost:8888/allisongrayce.com/12-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wpWPP_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_term_relationships`
#

DROP TABLE IF EXISTS `wpWPP_term_relationships`;


#
# Table structure of table `wpWPP_term_relationships`
#

CREATE TABLE `wpWPP_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_term_relationships (8 records)
#
 
INSERT INTO `wpWPP_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wpWPP_term_relationships` VALUES (14, 3, 0) ; 
INSERT INTO `wpWPP_term_relationships` VALUES (16, 1, 0) ; 
INSERT INTO `wpWPP_term_relationships` VALUES (18, 5, 0) ; 
INSERT INTO `wpWPP_term_relationships` VALUES (28, 4, 0) ; 
INSERT INTO `wpWPP_term_relationships` VALUES (29, 4, 0) ; 
INSERT INTO `wpWPP_term_relationships` VALUES (30, 4, 0) ; 
INSERT INTO `wpWPP_term_relationships` VALUES (31, 4, 0) ;
#
# End of data contents of table wpWPP_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_term_taxonomy`
#

DROP TABLE IF EXISTS `wpWPP_term_taxonomy`;


#
# Table structure of table `wpWPP_term_taxonomy`
#

CREATE TABLE `wpWPP_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_term_taxonomy (5 records)
#
 
INSERT INTO `wpWPP_term_taxonomy` VALUES (1, 1, 'category', '', 0, 2) ; 
INSERT INTO `wpWPP_term_taxonomy` VALUES (2, 2, 'post_tag', '', 0, 0) ; 
INSERT INTO `wpWPP_term_taxonomy` VALUES (3, 3, 'category', '', 0, 1) ; 
INSERT INTO `wpWPP_term_taxonomy` VALUES (4, 4, 'nav_menu', '', 0, 4) ; 
INSERT INTO `wpWPP_term_taxonomy` VALUES (5, 5, 'category', '', 0, 1) ;
#
# End of data contents of table wpWPP_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_terms`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_terms`
#

DROP TABLE IF EXISTS `wpWPP_terms`;


#
# Table structure of table `wpWPP_terms`
#

CREATE TABLE `wpWPP_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_terms (5 records)
#
 
INSERT INTO `wpWPP_terms` VALUES (1, 'Opinions', 'opinions', 0) ; 
INSERT INTO `wpWPP_terms` VALUES (2, 'design', 'design', 0) ; 
INSERT INTO `wpWPP_terms` VALUES (3, 'Design', 'design-2', 0) ; 
INSERT INTO `wpWPP_terms` VALUES (4, 'Main Menu', 'main-menu', 0) ; 
INSERT INTO `wpWPP_terms` VALUES (5, 'Featured', 'featured', 0) ;
#
# End of data contents of table wpWPP_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_usermeta`
#

DROP TABLE IF EXISTS `wpWPP_usermeta`;


#
# Table structure of table `wpWPP_usermeta`
#

CREATE TABLE `wpWPP_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_usermeta (31 records)
#
 
INSERT INTO `wpWPP_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wpWPP_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wpWPP_usermeta` VALUES (3, 1, 'nickname', 'nick') ; 
INSERT INTO `wpWPP_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wpWPP_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wpWPP_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wpWPP_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wpWPP_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wpWPP_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wpWPP_usermeta` VALUES (10, 1, 'wpWPP_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wpWPP_usermeta` VALUES (11, 1, 'wpWPP_user_level', '10') ; 
INSERT INTO `wpWPP_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wpWPP_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wpWPP_usermeta` VALUES (14, 1, 'wpWPP_user-settings', 'imgsize=full&editor=tinymce') ; 
INSERT INTO `wpWPP_usermeta` VALUES (15, 1, 'wpWPP_user-settings-time', '1390231783') ; 
INSERT INTO `wpWPP_usermeta` VALUES (16, 1, 'wpWPP_dashboard_quick_press_last_post_id', '45') ; 
INSERT INTO `wpWPP_usermeta` VALUES (17, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wpWPP_usermeta` VALUES (18, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:8:"add-post";i:1;s:8:"add-work";i:2;s:16:"add-testimonials";i:3;s:12:"add-post_tag";}') ; 
INSERT INTO `wpWPP_usermeta` VALUES (19, 1, 'nav_menu_recently_edited', '4') ; 
INSERT INTO `wpWPP_usermeta` VALUES (20, 2, 'first_name', 'test') ; 
INSERT INTO `wpWPP_usermeta` VALUES (21, 2, 'last_name', 'user') ; 
INSERT INTO `wpWPP_usermeta` VALUES (22, 2, 'nickname', 'test user') ; 
INSERT INTO `wpWPP_usermeta` VALUES (23, 2, 'description', '') ; 
INSERT INTO `wpWPP_usermeta` VALUES (24, 2, 'rich_editing', 'true') ; 
INSERT INTO `wpWPP_usermeta` VALUES (25, 2, 'comment_shortcuts', 'false') ; 
INSERT INTO `wpWPP_usermeta` VALUES (26, 2, 'admin_color', 'fresh') ; 
INSERT INTO `wpWPP_usermeta` VALUES (27, 2, 'use_ssl', '0') ; 
INSERT INTO `wpWPP_usermeta` VALUES (28, 2, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wpWPP_usermeta` VALUES (29, 2, 'wpWPP_capabilities', 'a:1:{s:6:"editor";b:1;}') ; 
INSERT INTO `wpWPP_usermeta` VALUES (30, 2, 'wpWPP_user_level', '7') ; 
INSERT INTO `wpWPP_usermeta` VALUES (31, 2, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ;
#
# End of data contents of table wpWPP_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/allisongrayce.com MySQL database backup
#
# Generated: Thursday 27. February 2014 18:27 UTC
# Hostname: localhost
# Database: `wp_portfolio`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpWPP_users`
# --------------------------------------------------------


#
# Delete any existing table `wpWPP_users`
#

DROP TABLE IF EXISTS `wpWPP_users`;


#
# Table structure of table `wpWPP_users`
#

CREATE TABLE `wpWPP_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpWPP_users (2 records)
#
 
INSERT INTO `wpWPP_users` VALUES (1, 'nick', '$P$B/ZcTvoaKRqtefvDF0tHt9iZqIo9td/', 'nick', 'adiakritos@gmail.com', '', '2014-01-14 15:53:51', '', 0, 'nick') ; 
INSERT INTO `wpWPP_users` VALUES (2, 'test user', '$P$BOuT2qsH0OTEuk6rMMCwBjxLc/Xjo0/', 'test-user', 'foo@gmail.com', '', '2014-01-26 15:28:27', '', 0, 'test user') ;
#
# End of data contents of table wpWPP_users
# --------------------------------------------------------

